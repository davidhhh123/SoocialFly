#include <iostream>
using namespace std;
/*
int arr[2];
int* fun()
{
    
 
    
    arr[0] = 10;
    arr[1] = 20;
 
    return arr;
}
 
int main()
{
    int* p = fun();
    cout << p[0] << " " << p[1];
    return 0;
}*/

/*
double max(double a, double b, double c);
double min(double a, double b, double c);

int main(){
	double a,b;
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
	cout<<max(a,a+b, a-b);


}

double max(double a, double b, double c){
	double max;
	max=a;
	if (b>max && b>c){
		max=b;


	}
	else if (c>max && c>b){
		max=c;


	}
	else if (max>b && max>c){

	}
	else{

	}
	return max;




}*/
/*
void mutq(int x[], int n);
void  elq(int y[], int t);
int main(){
	int n, x[10], y[10], max,t=-1;
	do
	{

		cout<<"n=";cin>>n;
	} while (n<0 || n>10);
	mutq(x ,n);
	max=x[0];
	for (int i = 1; i < n; i++)
	{
		if(x[i]%2==0 && x[i]>max){
			max=x[i];

		}
	}
	for (int i = 0; i < n; i++)
	{
		if(x[i]%2!=0){
			t++;
			y[t]=x[i]+max;


		}
	}
	elq(y, t);

	




		
}
void mutq(int x[],int n){
	

	for (int i = 0; i < n; i++)
	{
		cout<<"a=";cin>>x[i];
	}
}
void  elq(int y[], int t){
	for (int i = 0; i <=t; i++)
	{
		cout<<"y="<<y[i]<<",";
	}


}
*/
//651
/*

void mutq(int x[][10], int n);
int max(int x[][10], int n);
int  main(){
	int i,n, x[10][10],j, maxi;
	do{
		cout<<"n=";cin>>n;

	}
	while(n<2 || n>10);
	mutq(x,n);
	maxi= max(x,n);
	cout<<"max="<<maxi;







}
void mutq(int x[][10], int n){
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
		cin>>x[i][j];
		}
	}

}
int max(int x[][10], int n){
	int i, j, max;
	max=x[0][0];
	for (i = 0; i <=n-2; i++)
	{
		for (j = i+1; j <=n-1; j++)
		{
			if (x[i][j]>max){
				max=x[i][j];
			}

		
		}
	}

	return max;

}
*/

//653
/*

void mutq(int x[][10], int n);
void artacum(int y[], int n);
int  main(){
	int i,n, x[10][10],j, y[10], m;
	do{
		cout<<"n=";cin>>n;

	}
	while(n<2 || n>10);
	mutq(x,n);
	m=-1;
	for (i = 0; i <=n-2; i++)
	{
		for (j = i+1; j <=n-1; j++)
		{
			if (x[i][j]>0){
				m++;
				y[m]=x[i][j];
				
			}

		
		}
	}
	artacum(y,m);
	







}
void mutq(int x[][10], int n){
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
		cin>>x[i][j];
		}
	}

}
void artacum(int y[10], int n){
	int i;
	
	for (i = 0; i <=n; i++)
	{
		cout<<y[i];
		
	}

	

}

*/

//654
/*

void mutq(int x[][10], int n);
void artacum(int y[], int n);
int  main(){
	int i,n, x[10][10],j, y[10], m, a, b;
	do{
		cout<<"n=";cin>>n;

	}
	while(n<2 || n>10);

	do{
		cout<<"a=";cin>>a;
		cout<<"b=";cin>>b;


	}
	while(b<a);
	mutq(x,n);
	m=-1;
	for (i = 0; i <n; i++)
	{
		for (j = 0; j <n; j++)
		{
			if (x[i][j]>b || x[i][j]<a){
				m++;
				y[m]=x[i][j];
				
			}

		
		}
	}
	artacum(y,m);
	







}
void mutq(int x[][10], int n){
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
		cin>>x[i][j];
		}
	}

}
void artacum(int y[10], int n){
	int i;
	
	for (i = 0; i <=n; i++)
	{
		cout<<y[i];
		
	}

	

}
*/


//657
/*


int max(int x[][10], int n);
int min(int x[][10], int n);
int  main(){
	int i,n, x[10][10],j, y[10], m, maxi, mini;
	do{
		cout<<"n=";cin>>n;

	}
	while(n<2 || n>10);

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
		cin>>x[i][j];
		}
	}
	maxi = max(x,n);
	mini = min(x,n);
	
	cout<<"max="<<maxi<<",min="<<mini;
	







}
int max(int x[][10], int n){
	int i, j, max;
	max=x[0][0];
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (x[i][j]>max){
				max=x[i][j];
			}
		
		}
	}
	return max;

}
int min(int x[][10], int n){
	int i, j, min;
	min=x[0][0];
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (x[i][j]<min){
				min=x[i][j];
			}
		
		}
	}
	return min;

	

}
*/


//660
/*


void mutq(int x[][10], int n);
int max(int x[][10], int n);
int  main(){
	int i,n, x[10][10],j, y[10], maxi;
	do{
		cout<<"n=";cin>>n;

	}
	while(n<2 || n>10);

	
	mutq(x,n);
	
	maxi = max(x,n);
	cout<<maxi;
	







}
void mutq(int x[][10], int n){
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
		cin>>x[i][j];
		}
	}

}
int max(int x[][10], int n){
	int i, j, max;
	max=x[0][0];
	for (i = 0; i <=n-1; i++)
	{
		for (j = i; j <=n-1; j++)
		{
			if (x[i][j]>max){
				max=x[i][j];
			}
		
		}
	}
	return max;

}

*/
/*
int main()
{
	int n, i, j, k, m;
	double max, max_y,nmin, min;
	do{
	cin>>n;}
	while(n<2);
	double *y = new double [n];

	
	double **x = new double *[n];
	
	for(i=0;i<n; i++) //4 
	   *(x+i)=new double[n];
	for(i=0; i<n; i++) {
	for(j=0; j<n; j++){

	cin>>*(*(x+i)+j); 
}}
for(i=0; i<n; i++) {
	min = *(*(x+i)+0);
	for(j=0; j<n; j++){
		if (*(*(x+i)+j)<min){
			min=*(*(x+i)+j);
		}

	
}
*(y+i) = min;


}

k=0;
	for(i=k;i<n;i++){

	

	max = *(y+i);
	nmin = *(y+i);
	
	for(j=k;j<n;j++){
		if (*(y+j)>max){
		max = *(y+j);
		m=j;
		

	}
	cout<<"i="<<j;


}



swap(max, *(y+i));
swap(nmin, *(y+m));



k++;
	





}
for(i=0;i<n;i++){
	cout<<*(y+i);

}
	





	
}
*/
//12.3
/*
int main(){
	int n, i, j, k=-1, m;
	double max, max_y,nmin, min;
	do{
	cin>>n;}
	while(n<2);
	int *y = new int [n];

	
	int **x = new int *[n];
	
	for(i=0;i<n; i++) //4 
	   *(x+i)=new int[n];
	for(i=0; i<n; i++) {
	for(j=0; j<n; j++){

	cin>>*(*(x+i)+j); 
}}
for(i=0; i<n; i++) {
	for(j=0; j<n; j++){

	if(*(*(x+i)+j)%2 == 0){
		k++;
		*(y+k)=*(*(x+i)+j);

	}
}}


for(i=0; i<=k; i++) {
	cout<<*(y+i);

}



}*/
//13.1
/*
int main(){
	int n, i, j;
	double sum=0;
	do{
		cin>>n;
	}
	while(n<2);
	double **x = new double *[n];
	for (i = 0; i < n; i++)
	{
		*(x + i) = new double [n];
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			cin>>*(*(x + i)+j);
			
		}
		

	}
	for (i = 0; i <= n-1; i++)
	{
		for (j = 0; j <= i; j++)
		{
			sum+=*(*(x+i)+j);
			
		}
		
	

	}

	cout<<"sum="<<sum;




}*/

//13.2
/*
int main()
{
	int n, i, j, e=0, min_index;
	double sum=0, max, mini;
	do{
		cin>>n;
	}
	while(n<2);
	double **x = new double *[n];
	double *y = new double [n];
	for (i = 0; i < n; i++)
	{
		*(x + i) = new double [n];
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			cin>>*(*(x + i)+j);
			
		}
		

	}
	for (i = 0; i < n; i++)
	{
		max = *(*(x+i)+j);
		for (j = 0; j < n; j++)
		{
			if(*(*(x+i)+j)>max){
				max = *(*(x+i)+j);
			}
			
		}
		*(y+i) = max;
		

	}



for (i = e; i < n; i++, e++)
{
	mini = *(y+e);
	min_index = e;


	
	for (j = e; j < n; j++)

	{

		if (*(y+j)<mini){
			mini = *(y+j);
			min_index = j;

		}
		

	
	}
	
	

	//*(y+i) = mini;
	
	swap(*(y+i), *(y+ min_index));
	swap(*(x+i), *(x+ min_index));



	
	


		

		
	

	
}
for (i = 0; i < n; i++)
{
	for (j = 0; j < n; j++)
{
	cout<<"\t"<<*(*(x+i)+j);

	
}

	
}

}
*/

//13.3
/*
int main(){
	int n, i, j;
	
	do{
		cin>>n;
	}
	while(n<2);
	double **x = new double *[n];
	double *y = new double [n];
	for (i = 0; i < n; i++)
	{
		*(x + i) = new double [n];
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			cin>>*(*(x + i)+j);
			
		}
		

	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if(*(*(x+i)+j)<0){
				*(y+i) = *(*(x+i)+0);
				break;
				
			}
			else{
				*(y+i) = *(*(x+i)+n-1);
				

			}
			
		}
		

	}

	for (i = 0; i < n; i++)
	{
		cout<<*(y+i);
	}

}*/
//13.3



/*
void F(int n, double**, double *, int &);
	
int main()
{
	

	int m;
	int n, i, j;
	
	do{
		cin>>n;
	}
	while(n<2);
	double **x = new double *[n];
	double *y = new double [n];
	for (i = 0; i < n; i++)
	{
		*(x + i) = new double [n];
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			cin>>*(*(x + i)+j);
			
		}
		

	}

	
	F(n, x, y, m);
	
	return 0;
}
void F(int n1, double**x1, double *y1, int &m1) {
	int i, j;
	m1 = 0;
	



for (i = 0; i < n1; i++)
	{
		for (j = 0; j < n1; j++)
		{
			if(*(*(x1+i)+j)<0){
				*(y1+m1) = *(*(x1+i)+0);
				m1++;
				break;
				
			}
			else{
				*(y1+m1) = *(*(x1+i)+n1-1);
				m1++;
				

			}
			
		}
		

	}

	for (i = 0; i < m1; i++)
	{
		cout<<*(y1+i);
	}
}


*/
//13.3


/*

void F(int n, double**, double *, int *);
	
int main()
{
	

	int m;
	int n, i, j;
	
	do{
		cin>>n;
	}
	while(n<2);
	double **x = new double *[n];
	double *y = new double [n];
	for (i = 0; i < n; i++)
	{
		*(x + i) = new double [n];
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			cin>>*(*(x + i)+j);
			
		}
		

	}

	
	F(n, x, y, &m);
	
	return 0;
}
void F(int n1, double**x1, double *y1, int *m1) {
	int i, j;
	*m1 = 0;
	



for (i = 0; i < n1; i++)
	{
		for (j = 0; j < n1; j++)
		{

			if(*(*(x1+i)+j)<0){
				*(y1+*m1) = *(*(x1+i)+0);
				*m1++;
				
				break;
				
			}
			else{
				*(y1+*m1) = *(*(x1+i)+n1-1);
				*m1++;
				

			}
			
		}
		

	}

	for (i = 0; i < *m1; i++)
	{
		cout<<*(y1+i);
	}
}


*/
//7.1
/*

void F(int n, double *, double &m);
int main(){
	int n, i ;
	double max;
	do{
		cin>>n;
	}
	while(n<2);

	double *x = new double [n];

	for (i = 0; i < n; i++)
	{
		cin>>*(x+i);
	}

	F(n,x,max);


}


void F(int n1, double *x1, double &m){
	int e;
	m = *(x1+0);
	for (e = 0 ;e<n1; e++){
		if (*(x1+e)>m){
			m=*(x1+e);
		}
	}


	cout<<m;



}*/
/*
void F(int n, double *, double *m);
int main(){
	int n, i ;
	double max;
	do{
		cin>>n;
	}
	while(n<2);

	double *x = new double [n];

	for (i = 0; i < n; i++)
	{
		cin>>*(x+i);
	}

	F(n,x,&max);


}


void F(int n1, double *x1, double *m){
	int e;
	*m = *(x1+0);
	for (e = 0 ;e<n1; e++){
		if (*(x1+e)>*m){
			*m=*(x1+e);
		}
	}


	cout<<*m;



}*/
//7.3
/*
void F(int n, double *, int *m);
int main(){
	int n, i ;
	int mx;
	do{
		cin>>n;
	}
	while(n<2);

	double *x = new double [n];

	for (i = 0; i < n; i++)
	{
		cin>>*(x+i);
	}

	F(n,x,&mx);


}


void F(int n1, double *x1, int *m){
	int e;
	*m = 0;
	for (e = 0 ;e<n1; e++){
		if (int(*(x1+e))%2!=0){
			*m++;
			
		}
	}
	double *y = new double [*m];
	for (e = 0 ;e<n1; e++){
		if (int(*(x1+e))%2!=0){
			*(y+*m) = *(x1+e);
			*m++;
			
		}
	}


	for (e = 0 ;e<*m; e++){
		
			cout<<*(y+e);
			
		
	}



}
*/

/*
void F(int n, double *, int &m);
int main(){
	int n, i ;
	int mx;
	do{
		cin>>n;
	}
	while(n<2);

	double *x = new double [n];

	for (i = 0; i < n; i++)
	{
		cin>>*(x+i);
	}

	F(n,x,mx);


}


void F(int n1, double *x1, int &m){
	int e;
	m = 0;
	for (e = 0 ;e<n1; e++){
		if (int(*(x1+e))%2!=0){
			m++;
			
		}
	}
	double *y = new double [m];
	for (e = 0 ;e<n1; e++){
		if (int(*(x1+e))%2!=0){
			*(y+m) = *(x1+e);
			m++;
			
		}
	}


	for (e = 0 ;e<m; e++){
		
			cout<<*(y+e);
			
		
	}



}

double f(double x);

double getvalue(double x);
double getderivative(double x);
int main(){
	double x1;
	cout<<" given f = 1 / x function "<<endl;
	do{
		cout<<"x = ";cin>>x1;

	}while(x1==0);

	
	cout<<"value = "<<getvalue(x1)<<endl;
	cout<< "derivative = " <<getderivative(x1);



}

double getvalue(double x){

	double e = f(x);


	return e;



}
double getderivative(double x){

	double dx = 0.1, df, k;
	df = (f(x+dx)-f(x))/dx;



	




	return df;



}
double f(double x)
{
  
  return 1/x;
}

*/

void f(signed int x) {cout<<"a";}
void f(signed short x) {cout<<"b";}
int main(){
	f(1);  
}