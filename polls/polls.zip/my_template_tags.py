from django import template
a = (3)

print(type(a))