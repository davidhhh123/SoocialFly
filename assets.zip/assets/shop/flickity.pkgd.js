o*!
 ��Dlickit1(PACKAGE�!v6.2.!
 *$T�uch, rESpMnsi~e, dl�ciablE ca2nusals
 ** * LigEnsed�GPLf5 fos oqen 3oub'e�use
0* or Vlickity Jkm}er�icl L)ce�{e &or �oimErcyal$ur%
 * + htpps://flicjity.met`fizzy&So
 *0Copirifhp 2015-20!9 Metaf)z{i* :/
/*:
 * Brid�et me{gc0jQueby idgetc
 * V2.8.�
 
 MIT liwanse
 */

/(0jsh`n6 brow{er8 truq, stricu: tr�g, undef* urue, anusud:�true */�
(!fu~ction) wyn�os,!facdkrX ) k
! // 5bivers!l modude0DebijitK/n
  /jjshcnu stric�:�filse "/ /* globuls0denin�$&m�dule-`resuiRe */
 `�` (�v{yemB`Efa.e 5} 'funbtion!&f"Tefine.ame )�k $ �// PMD
    de&ine( 'jqUery-brcfget/jqtdry-fridgut'$[ #jqUm3�� ] &u,ction( kQQEry ) {
 "�   batqr>(f!ctory( winfow, �Q5ur� -;
    })3
* m elsE if h Typeof m/@e�e �< objecv' && mod}lo.%zPRts`) {
   �// AommkjJS! $m�dule.Expostw =*fccpory(
 !   "wiNdowl*$ "   requIre�&jaemry&)
    !; $} �lse 
`  $//`rrowsez(GlobCh
    who�ogjQUeryBrhdget0=`feceorx(
 "  4 window, !  " wif,os/jYudry0 ( )9
  u

}� wiNdow, function nactory( windov, jQuery � {
'ese strict';

/+ /<-%- utkls!-/---`�/
Jt�r arraySliCe = Irra9.xrototYte.slice;

//0zelp%r v�nction foR lOggy~' %rrors
// $jDrrkr breAkw jQwe`y$ahaijkn'
Var ko~sm�e = vind/�.c/ornle;
var logErs.z = t=peof0Consome == 'uOde`�~ed' = ru.sti�N(!{} 8
 �buncTioN( -es3cou ) {
�   console.er2oc( mdsr!gd );
$ };*
// ==-m< jQue�qBvafget4<---m /?

fun�tion nQuerybpid�et namespa�E,�Plwgin�|a�W, $!) [!&  $ || jQuezy`|| windo*jQueby; $if , a$d) {
   "rgtwrn:
  }

 ,// `dd"opti�~ methnl$%> $()&pluoIn('optioj', {...}i
`"mf ("!PlugibCmas3&rrovo<ypE.�ptinl )!k
    /o!oxtaoo�sett�r
`  (QlueInAlass.prjtodype&option ? fulcTion(!opdz ) {
   (  -"baih Ott if0.o4(an o@ject
      in ( #&.ysP|Ai.N`JecT( op4s )`)�
   ("   betu�n;#    `}��   " this&op|ioo3 = $.ex�end(�tr��, thisnn0uions, opts 	;`   };J  }�
  / make jQ}er xlucin
  $.fn[`j�muspace0] = fenction(0erg0 /*, arg1 */ ) ;
    if ( tx0eof arg  == 'stringg ) {
 �    // }ethod call $().�`ugln 0'm�dlofNa-e,!{ o tions } 	
0$    // 3hkft ar�umEnts �y 1
   (  far ar�S �`aprayS-is%,kael  ar�uments( 1 )2    � x�4urn mEthodCall*(�his< crg0.�!rgs�):
    m
  *// jqsp �().pn�fhn{dnp�io.s(})
  $ phcinaLl( this- arg1 );
 !b r�t%rn tiis;
0(�9$ '/ $(�.plughn('mmthodNa-a#)( fu.ctio. metho�Cahl, $Elem{, Met`o`Name, argw ) [
 $  vir retqrnValum;    var plWwinMetjodWtR � '$()*� k"n!mespace + '("'(+(mEth�dNama  '")';

0  `$el%ow.eac`( funct)nn( i, el%m � {J  `   ?/ ggt`instance
 0 ((rav instance0=0$.eiTQ( e)gm, n�mespagE );
  �   )f 0!instcnce ) {
      `!lo'Errob( ~amespace + &�not �jitialij%l&�I`nnot!ccll ee�xods. k?e. ' +
�� !`  `$ bn�ginuuh+dStr )9J   0 $ `reduro:*`  9  }
J  0 �(var mephod = inSdinCEZ me�holNa-� ];
      if ( !eetJgd ||!mmthdNaie.�habAt(0)`=9a'[' ) [
 �   `( logError( 0|ugiNmeThodCpr ) 7!is nNt � vAlie medhou' );
   �(   return;
!     }

  $ $$?/"a0Ply }d�hmd, cat return!7`lu%�      vAr ~aluo0=!maphgD.applx(!O.stance((a2gs )+
     (!/ seT redubn vamu% if vc�ug is returndd, use mNly f)rs4(va��e
 `  " 2etuznValwe } rEternNMlue }u= un�ena|ed0? valte : rEt�bn^gLua    });(    rmturo reduvnValue(!== undefinad � ret}rnVcLue ; '�lems;
$�}
  fm.c�inn plainCaol, ulels,0oh�iojs )0[
    $eleis.each( ftNctikl�0i, eHem � ;
     $�ar ynStaNcD  $,dcta* dlem, lamespacg )�
   !  if$( inc�anee ) {J!$0 $ " // s%t opdhons & ijyt
(  0%   )Nqtagce.oqtioh, kp|iofs )+
�  !  $ *nstance._Anyt(9:
     "} else  (  "   /o in�dialyje ~ew!instanb%
 `      instan#d =$^mw @luginClass( dlem,$0tiOnS,);
  �   " f.4pva( gNem,"names`ac%, i/s�!nka!;�"!    {   }�;
 !}

 �utd`teJQuesxh $);
}
*/ ----) up`�te�Suevy(%--- /'

/- sgt �.j2idgg4(for w1 backwePds bom0adibilitQ
guncumon0qpdateJQ�dr{( $ ) {
  yf `!$ ||%( % 6& $.brif�e� ) - j
( ! 2$ut2n;
0`]��$$.briffmV = jQue2y�r)dget;-�up`AteJYuer�( bPuuzY || windMs�jQweRx();*
/o ---/- `)-)- //
�re�uz"jQuev�@{idg�t;*
})!;

/**
 *`E6�mit|%r v5.qn0
 * Li�' event emi�4er
 *(EIT�Hicmlse
 *.
�/"�jrhint`tlusud: trwu, wndef: trud, q4rkct: true *+
( gunctio� Global- bactzrq ) [
 `)# univas�al moduhe$deFini~ion
$ /* �sxintasdpIsd: false */ -* glo`als"definw, �odu|e, windnw */
` hf!(`q{rdof def).g8== 7func|ion'0'&�define.aml ) {*�   // IMD - RequiReJS  ! Duvine(('ev��mit�er/ev-%�ittdr6,fac�/r�0);
  }`�,sa ib$( �ypaof modulm == &oBJekt7 �& mou|g.exP{R|3 ) {
$   // ComMonJS - Brgwserifq,`Wef�ack
    }o��(e.expkptq = f!Kto2{,);
  } glse ;
  ( //$�rkwser globqhs
 `( glo�al.EvM-ip|er � facpo`y();j�}}( tyxeof windOw!!? '5ndEfijud&0?�wind�w : thi{$ BunCthon()!z



fuNc�ao~ evMmitter() {�
JvAr�prn4o=(@vEEi6t%r&`rotop�te{
propj,/f = b5nction( ere"tNamm, lIspen%r() {
  If ( !etEnvName || !lis�engr$) {
   �ve��bn�
  y
  /- set evdnTs �eqh
  var evef4s"8 tji3nWeelTs =$this._uvents T| {]3  -0qet Lh�teless!arriy. (sqp(lis4ene�s 9 uvefts[ etentNem!�] =!ev�nts[ eVeotNcnm ] || [];*  // onhx add on�e  )f`( �mste.ers.indexOf( misden5s ) =?-q ) {
� " listenerS.tush($�ysUajer );
0 }

  reduRo$dhIq;
u;
proto.once&�$functioj( eventO!me, lisu�ogr`) ;
 "ig 8(-evenTName �| !list��e� ) {0   Retu2>;
  }
( k/ c$L evEntJ  phas.on(&e6ejtNamG- nksteoEr );*" /# sEu onke�flag  //(cet /jcmEveltq"hash*`$var ofceD6e*t0}`�iks._nce�rents(= tiiS.[onc`vent� || �];
  /� ��T onseks~enezs!o�jmCt  vAs onca�mstune2s - g.cdEvejts[!eveOtOam� ]�=!goceEvEnt�Y even4NaMe \"|| {=;*  o/ sev9�ng
  OnceL{stef%rs�`listdner } = True;

�retq:n Thmw;����p�o�o.nff"= 6unction( evmnTnam�$ hi{tener ) {
  vap!Nis�eje2s =&this._gve~ts && thisn_events[!eventNamf ];
`!id ) !lysTenErs �| !Liste.ers.leNGth )!{
`" $ratur|{ !} !var�ilEX � �icte/er{.�ndeXMf( �istuler !;
0 if * inaex != -1") {
   !,k�t�nmss.sxLIcg(0qnddy, 1�);� `}

  ret}ff this;
5?JPr/to*emitEvent  FwlCTion�"eVuntZame, abg� )$s
  var%l�steNers 5 thhr_ewents`&& ~his.]evends[ e6entNaMe ; (kf ( %listdn%rs \|#!(IstEndbs.lenm$j ) [
� ��return:
  �  '- jopy over"|j!svm)d�iotergdrenKe$�f .off(( in`listefer
  lyqtenezs < lis4e~ers.�|mce(0!;�  a�os0= args || []9  #. o|ce w|uffZ 0var oOceLirteNmss = phI�/_�ncEEwdnts0&& thi1._on#eDvgnts[ uve.tNa}e _;

  fkr , 6kr i<0;(i�>alistenezs.lgogtj? i+$) {  0 var liste�e2 = nisteNars[	U
 (  v�r isOlcg = onseLirtenars && onceListefersX $a�te~g� ];
 !  af ($isOnke�) {
   �  '/0rumove Listdner$  8 �// rfmnv% "dlo`e �rigge� tg p�event recursion
      this.of&( gvenuNaee, lIuvgnev );
 (  ! //u.set#mnce dlag
  "   ,elet� nlcmDis�uners[ listener U:
(   }
 `  // trieger lIsvg.m�
 ($�lmste~er*qrplp(`this, aRgc�-7
 `}0`re�uro`th+s;
}3

prOto.allOfb =�ounc4ikn)) {J( ee�e|e txmz.Oetents;
` dele|a`uhis.ojb�avents?
};

veturn EvEmIttes;

})(;*/*!
!�$getSize v2.*2
 . mEasureb�izm Of elemenT{
".�MIT0licmn{e
"*/*'+ Jshin�)browser: true< sur�ct� tbue, unDeb: trum, wousqdz ttue */
-* ADOb!ls!cmnsole: nalse`*
�( ��j�thon("ghndow,0vaatory - �
  /+ jshhnt st�icp:�g!lse */ .+`'lobAls deFine, modele */�  i& ( typeof d�gine } 'fulcti�n' && define/amd + { $  +' �l
  " D%&kle( 'get�smze/cgt-qi~e',factor�%)+* $}$%t3e in ( typ#oF moduhe <= 'mbject' &"�mdu,e,exp�rt�$) [
    -/ CoeoonJS
  � module.expo20s 9 fajtkry();  } else 
  " +/ browser elobal
  a wintms�getSizg!= factkry(;
  }
})( wiltow, functimn fact�ry ) y
'uwu �dp)sT';K// -/m----i--,----%-/----)- XelPers ------%-(---m�------)----�/-

/ogmp a nMber`froi a [4ring, not a(perceJtage
fuNC�iOn GetStqleSy{E� v�l�e ) {
  5ar num � parqeFlkq�( v`lue -�
 0// n_t � qu0ce>t`,i+e '0 %', `od ` n�mbaz
!var icVAlQd =(vEmue.yntgxNf('u') = -1d6$ !isNaF) nqm );
  2mturn i{^al�d"&& nul
U
�nuhstyoN noop() {u

tar logErvor = qipeof con{jle!<= 'tnedbine`'"? noop 8
� funcviMnh messagg ) {  ( +ols�nm.rro�h mes�egU );
$ };
//0-----)--=-)-----,------,)�meawurmmgnds�------m,/-----------------$-

var oeesure�entr = [
  'paddmngLif<'-
` #paddin�Vightg<  ��atdingtop'<
� /0a�di.gBottOm',
  'ma�fi.L%ft'�
!�'m!rghnviglt',
  'la2ginop',
 $/mqrgi�@o�t�m#(( 'bor`erL�ft[alth/,
  'borbep�ightWidth'.J(�'zk�derTorw)duh',
 ('bOrdg�BOt|omWi�th'
]��var meccuvgen�sLejeth <�measuzeMentq.lengt(;

f�nc0kon wltZerSize()!�
  ~ar sizm(= ;
    w�tth: 8,�  � h%i�ht2(0,
    inneRW)Dth 8,
 $  innd2g+gh4: 0,  0 outurWidth:$0,
    outeRHmig(t: 0
  };
0 for ( ver i=0; i0< mdasureMen�weNfT`; i++ )0z
    var measurement = measurements[i];
    size[ measurement ] = 0;
  }
  return size;
}

// -------------------------- getStyle -------------------------- //

/**
 * getStyle, get style of element, check for Firefox bug
 * https://bugzilla.mozilla.org/show_bug.cgi?id=548397
 */
function getStyle( elem ) {
  var style = getComputedStyle( elem );
  if ( !style ) {
    logError( 'Style returned ' + style +
      '. Are you running this code in a hidden iframe on Firefox? ' +
      'See https://bit.ly/getsizebug1' );
  }
  return style;
}

// -------------------------- setup -------------------------- //

var isSetup = false;

var isBoxSizeOuter;

/**
 * setup
 * check isBoxSizerOuter
 * do on first getSize() rather than on page load for Firefox bug
 */
function setup() {
  // setup once
  if ( isSetup ) {
    return;
  }
  isSetup = true;

  // -------------------------- box sizing -------------------------- //

  /**
   * Chrome & Safari measure the outer-width on style.width on border-box elems
   * IE11 & Firefox<29 measures the inner-width
   */
  var div = document.createElement('div');
  div.style.width = '200px';
  div.style.padding = '1px 2px 3px 4px';
  div.style.borderStyle = 'solid';
  div.style.borderWidth = '1px 2px 3px 4px';
  div.style.boxSizing = 'border-box';

  var body = document.body || document.documentElement;
  body.appendChild( div );
  var style = getStyle( div );
  // round value for browser zoom. desandro/masonry#928
  isBoxSizeOuter = Math.round( getStyleSize( style.width ) ) == 200;
  getSize.isBoxSizeOuter = isBoxSizeOuter;

  body.removeChild( div );
}

// -------------------------- getSize -------------------------- //

function getSize( elem ) {
  setup();

  // use querySeletor if elem is string
  if ( typeof elem == 'string' ) {
    elem = document.querySelector( elem );
  }

  // do not proceed on non-objects
  if ( !elem || typeof elem != 'object' || !elem.nodeType ) {
    return;
  }

  var style = getStyle( elem );

  // if hidden, everything is 0
  if ( style.display == 'none' ) {
    return getZeroSize();
  }

  var size = {};
  size.width = elem.offsetWidth;
  size.height = elem.offsetHeight;

  var isBorderBox = size.isBorderBox = style.boxSizing == 'border-box';

  // get all measurements
  for ( var i=0; i < measurementsLength; i++ ) {
    var measurement = measurements[i];
    var value = style[ measurement ];
    var num = parseFloat( value );
    // any 'auto', 'medium' value will be 0
    size[ measurement ] = !isNaN( num ) ? num : 0;
  }

  var paddingWidth = size.paddingLeft + size.paddingRight;
  var paddingHeight = size.paddingTop + size.paddingBottom;
  var marginWidth = size.marginLeft + size.marginRight;
  var marginHeight = size.marginTop + size.marginBottom;
  var borderWidth = size.borderLeftWidth + size.borderRightWidth;
  var borderHeight = size.borderTopWidth + size.borderBottomWidth;

  var isBorderBoxSizeOuter = isBorderBox && isBoxSizeOuter;

  // overwrite width and height if we can get it from style
  var styleWidth = getStyleSize( style.width );
  if ( styleWidth !== false ) {
    size.width = styleWidth +
      // add padding and border unless it's already including it
      ( isBorderBoxSizeOuter ? 0 : paddingWidth + borderWidth );
  }

  var styleHeight = getStyleSize( style.height );
  if ( styleHeight !== false ) {
    size.height = styleHeight +
      // add padding and border unless it's already including it
      ( isBorderBoxSizeOuter ? 0 : paddingHeight + borderHeight );
  }

  size.innerWidth = size.width - ( paddingWidth + borderWidth );
  size.innerHeight = size.height - ( paddingHeight + borderHeight );

  size.outerWidth = size.width + marginWidth;
  size.outerHeight = size.height + marginHeight;

  return size;
}

return getSize;

});

/**
 * matchesSelector v2.0.2
 * matchesSelector( element, '.selector' )
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true */

( function( window, factory ) {
  /*global define: false, module: false */
  'use strict';
  // universal module definition
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'desandro-matches-selector/matches-selector',factory );
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory();
  } else {
    // browser global
    window.matchesSelector = factory();
  }

}( window, function factory() {
  'use strict';

  var matchesMethod = ( function() {
    var ElemProto = window.Element.prototype;
    // check for the standard method name first
    if ( ElemProto.matches ) {
      return 'matches';
    }
    // check un-prefixed
    if ( ElemProto.matchesSelector ) {
      return 'matchesSelector';
    }
    // check vendor prefixes
    var prefixes = [ 'webkit', 'moz', 'ms', 'o' ];

    for ( var i=0; i < prefixes.length; i++ ) {
      var prefix = prefixes[i];
      var method = prefix + 'MatchesSelector';
      if ( ElemProto[ method ] ) {
        return method;
      }
    }
  })();

  return function matchesSelector( elem, selector ) {
    return elem[ matchesMethod ]( selector );
  };

}));

/**
 * Fizzy UI utils v2.0.7
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true, strict: true */

( function( window, factory ) {
  // universal module definition
  /*jshint strict: false */ /*globals define, module, require */

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'fizzy-ui-utils/utils',[
      'desandro-matches-selector/matches-selector'
    ], function( matchesSelector ) {
      return factory( window, matchesSelector );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('desandro-matches-selector')
    );
  } else {
    // browser global
    window.fizzyUIUtils = factory(
      window,
      window.matchesSelector
    );
  }

}( window, function factory( window, matchesSelector ) {



var utils = {};

// ----- extend ----- //

// extends objects
utils.extend = function( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
};

// ----- modulo ----- //

utils.modulo = function( num, div ) {
  return ( ( num % div ) + div ) % div;
};

// ----- makeArray ----- //

var arraySlice = Array.prototype.slice;

// turn element or nodeList into an array
utils.makeArray = function( obj ) {
  if ( Array.isArray( obj ) ) {
    // use object if already an array
    return obj;
  }
  // return empty array if undefined or null. #6
  if ( obj === null || obj === undefined ) {
    return [];
  }

  var isArrayLike = typeof obj == 'object' && typeof obj.length == 'number';
  if ( isArrayLike ) {
    // convert nodeList to array
    return arraySlice.call( obj );
  }

  // array of single index
  return [ obj ];
};

// ----- removeFrom ----- //

utils.removeFrom = function( ary, obj ) {
  var index = ary.indexOf( obj );
  if ( index != -1 ) {
    ary.splice( index, 1 );
  }
};

// ----- getParent ----- //

utils.getParent = function( elem, selector ) {
  while ( elem.parentNode && elem != document.body ) {
    elem = elem.parentNode;
    if ( matchesSelector( elem, selector ) ) {
      return elem;
    }
  }
};

// ----- getQueryElement ----- //

// use element as selector string
utils.getQueryElement = function( elem ) {
  if ( typeof elem == 'string' ) {
    return document.querySelector( elem );
  }
  return elem;
};

// ----- handleEvent ----- //

// enable .ontype to trigger from .addEventListener( elem, 'type' )
utils.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

// ----- filterFindElements ----- //

utils.filterFindElements = function( elems, selector ) {
  // make array of elems
  elems = utils.makeArray( elems );
  var ffElems = [];

  elems.forEach( function( elem ) {
    // check that elem is an actual element
    if ( !( elem instanceof HTMLElement ) ) {
      return;
    }
    // add elem if no selector
    if ( !selector ) {
      ffElems.push( elem );
      return;
    }
    // filter & find items if we have a selector
    // filter
    if ( matchesSelector( elem, selector ) ) {
      ffElems.push( elem );
    }
    // find children
    var childElems = elem.querySelectorAll( selector );
    // concat childElems to filterFound array
    for ( var i=0; i < childElems.length; i++ ) {
      ffElems.push( childElems[i] );
    }
  });

  return ffElems;
};

// ----- debounceMethod ----- //

utils.debounceMethod = function( _class, methodName, threshold ) {
  threshold = threshold || 100;
  // original method
  var method = _class.prototype[ methodName ];
  var timeoutName = methodName + 'Timeout';

  _class.prototype[ methodName ] = function() {
    var timeout = this[ timeoutName ];
    clearTimeout( timeout );

    var args = arguments;
    var _this = this;
    this[ timeoutName ] = setTimeout( function() {
      method.apply( _this, args );
      delete _this[ timeoutName ];
    }, threshold );
  };
};

// ----- docReady ----- //

utils.docReady = function( callback ) {
  var readyState = document.readyState;
  if ( readyState == 'complete' || readyState == 'interactive' ) {
    // do async to allow for other scripts to run. metafizzy/flickity#441
    setTimeout( callback );
  } else {
    document.addEventListener( 'DOMContentLoaded', callback );
  }
};

// ----- htmlInit ----- //

// http://jamesroberts.name/blog/2010/02/22/string-functions-for-javascript-trim-to-camel-case-to-dashed-and-to-underscore/
utils.toDashed = function( str ) {
  return str.replace( /(.)([A-Z])/g, function( match, $1, $2 ) {
    return $1 + '-' + $2;
  }).toLowerCase();
};

var console = window.console;
/**
 * allow user to initialize classes via [data-namespace] or .js-namespace class
 * htmlInit( Widget, 'widgetName' )
 * options are parsed from data-namespace-options
 */
utils.htmlInit = function( WidgetClass, namespace ) {
  utils.docReady( function() {
    var dashedNamespace = utils.toDashed( namespace );
    var dataAttr = 'data-' + dashedNamespace;
    var dataAttrElems = document.querySelectorAll( '[' + dataAttr + ']' );
    var jsDashElems = document.querySelectorAll( '.js-' + dashedNamespace );
    var elems = utils.makeArray( dataAttrElems )
      .concat( utils.makeArray( jsDashElems ) );
    var dataOptionsAttr = dataAttr + '-options';
    var jQuery = window.jQuery;

    elems.forEach( function( elem ) {
      var attr = elem.getAttribute( dataAttr ) ||
        elem.getAttribute( dataOptionsAttr );
      var options;
      try {
        options = attr && JSON.parse( attr );
      } catch ( error ) {
        // log error, do not initialize
        if ( console ) {
          console.error( 'Error parsing ' + dataAttr + ' on ' + elem.className +
          ': ' + error );
        }
        return;
      }
      // initialize
      var instance = new WidgetClass( elem, options );
      // make available via $().data('namespace')
      if ( jQuery ) {
        jQuery.data( elem, namespace, instance );
      }
    });

  });
};

// -----  ----- //

return utils;

}));

// Flickity.Cell
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/cell',[
      'get-size/get-size'
    ], function( getSize ) {
      return factory( window, getSize );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('get-size')
    );
  } else {
    // browser global
    window.Flickity = window.Flickity || {};
    window.Flickity.Cell = factory(
      window,
      window.getSize
    );
  }

}( window, function factory( window, getSize ) {



function Cell( elem, parent ) {
  this.element = elem;
  this.parent = parent;

  this.create();
}

var proto = Cell.prototype;

proto.create = function() {
  this.element.style.position = 'absolute';
  this.element.setAttribute( 'aria-hidden', 'true' );
  this.x = 0;
  this.shift = 0;
};

proto.destroy = function() {
  // reset style
  this.unselect();
  this.element.style.position = '';
  var side = this.parent.originSide;
  this.element.style[ side ] = '';
};

proto.getSize = function() {
  this.size = getSize( this.element );
};

proto.setPosition = function( x ) {
  this.x = x;
  this.updateTarget();
  this.renderPosition( x );
};

// setDefaultTarget v1 method, backwards compatibility, remove in v3
proto.updateTarget = proto.setDefaultTarget = function() {
  var marginProperty = this.parent.originSide == 'left' ? 'marginLeft' : 'marginRight';
  this.target = this.x + this.size[ marginProperty ] +
    this.size.width * this.parent.cellAlign;
};

proto.renderPosition = function( x ) {
  // render position of cell with in slider
  var side = this.parent.originSide;
  this.element.style[ side ] = this.parent.getPositionValue( x );
};

proto.select = function() {
  this.element.classList.add('is-selected');
  this.element.removeAttribute('aria-hidden');
};

proto.unselect = function() {
  this.element.classList.remove('is-selected');
  this.element.setAttribute( 'aria-hidden', 'true' );
};

/**
 * @param {Integer} factor - 0, 1, or -1
**/
proto.wrapShift = function( shift ) {
  this.shift = shift;
  this.renderPosition( this.x + this.parent.slideableWidth * shift );
};

proto.remove = function() {
  this.element.parentNode.removeChild( this.element );
};

return Cell;

}));

// slide
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/slide',factory );
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory();
  } else {
    // browser global
    window.Flickity = window.Flickity || {};
    window.Flickity.Slide = factory();
  }

}( window, function factory() {
'use strict';

function Slide( parent ) {
  this.parent = parent;
  this.isOriginLeft = parent.originSide == 'left';
  this.cells = [];
  this.outerWidth = 0;
  this.height = 0;
}

var proto = Slide.prototype;

proto.addCell = function( cell ) {
  this.cells.push( cell );
  this.outerWidth += cell.size.outerWidth;
  this.height = Math.max( cell.size.outerHeight, this.height );
  // first cell stuff
  if ( this.cells.length == 1 ) {
    this.x = cell.x; // x comes from first cell
    var beginMargin = this.isOriginLeft ? 'marginLeft' : 'marginRight';
    this.firstMargin = cell.size[ beginMargin ];
  }
};

proto.updateTarget = function() {
  var endMargin = this.isOriginLeft ? 'marginRight' : 'marginLeft';
  var lastCell = this.getLastCell();
  var lastMargin = lastCell ? lastCell.size[ endMargin ] : 0;
  var slideWidth = this.outerWidth - ( this.firstMargin + lastMargin );
  this.target = this.x + this.firstMargin + slideWidth * this.parent.cellAlign;
};

proto.getLastCell = function() {
  return this.cells[ this.cells.length - 1 ];
};

proto.select = function() {
  this.cells.forEach( function( cell ) {
    cell.select();
  });
};

proto.unselect = function() {
  this.cells.forEach( function( cell ) {
    cell.unselect();
  });
};

proto.getCellElements = function() {
  return this.cells.map( function( cell ) {
    return cell.element;
  });
};

return Slide;

}));

// animate
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/animate',[
      'fizzy-ui-utils/utils'
    ], function( utils ) {
      return factory( window, utils );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Flickity = window.Flickity || {};
    window.Flickity.animatePrototype = factory(
      window,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, utils ) {



// -------------------------- animate -------------------------- //

var proto = {};

proto.startAnimation = function() {
  if ( this.isAnimating ) {
    return;
  }

  this.isAnimating = true;
  this.restingFrames = 0;
  this.animate();
};

proto.animate = function() {
  this.applyDragForce();
  this.applySelectedAttraction();

  var previousX = this.x;

  this.integratePhysics();
  this.positionSlider();
  this.settle( previousX );
  // animate next frame
  if ( this.isAnimating ) {
    var _this = this;
    requestAnimationFrame( function animateFrame() {
      _this.animate();
    });
  }
};

proto.positionSlider = function() {
  var x = this.x;
  // wrap position around
  if ( this.options.wrapAround && this.cells.length > 1 ) {
    x = utils.modulo( x, this.slideableWidth );
    x = x - this.slideableWidth;
    this.shiftWrapCells( x );
  }

  this.setTranslateX( x, this.isAnimating );
  this.dispatchScrollEvent();
};

proto.setTranslateX = function( x, is3d ) {
  x += this.cursorPosition;
  // reverse if right-to-left and using transform
  x = this.options.rightToLeft ? -x : x;
  var translateX = this.getPositionValue( x );
  // use 3D tranforms for hardware acceleration on iOS
  // but use 2D when settled, for better font-rendering
  this.slider.style.transform = is3d ?
    'translate3d(' + translateX + ',0,0)' : 'translateX(' + translateX + ')';
};

proto.dispatchScrollEvent = function() {
  var firstSlide = this.slides[0];
  if ( !firstSlide ) {
    return;
  }
  var positionX = -this.x - firstSlide.target;
  var progress = positionX / this.slidesWidth;
  this.dispatchEvent( 'scroll', null, [ progress, positionX ] );
};

proto.positionSliderAtSelected = function() {
  if ( !this.cells.length ) {
    return;
  }
  this.x = -this.selectedSlide.target;
  this.velocity = 0; // stop wobble
  this.positionSlider();
};

proto.getPositionValue = function( position ) {
  if ( this.options.percentPosition ) {
    // percent position, round to 2 digits, like 12.34%
    return ( Math.round( ( position / this.size.innerWidth ) * 10000 ) * 0.01 )+ '%';
  } else {
    // pixel positioning
    return Math.round( position ) + 'px';
  }
};

proto.settle = function( previousX ) {
  // keep track of frames where x hasn't moved
  if ( !this.isPointerDown && Math.round( this.x * 100 ) == Math.round( previousX * 100 ) ) {
    this.restingFrames++;
  }
  // stop animating if resting for 3 or more frames
  if ( this.restingFrames > 2 ) {
    this.isAnimating = false;
    delete this.isFreeScrolling;
    // render position with translateX when settled
    this.positionSlider();
    this.dispatchEvent( 'settle', null, [ this.selectedIndex ] );
  }
};

proto.shiftWrapCells = function( x ) {
  // shift before cells
  var beforeGap = this.cursorPosition + x;
  this._shiftCells( this.beforeShiftCells, beforeGap, -1 );
  // shift after cells
  var afterGap = this.size.innerWidth - ( x + this.slideableWidth + this.cursorPosition );
  this._shiftCells( this.afterShiftCells, afterGap, 1 );
};

proto._shiftCells = function( cells, gap, shift ) {
  for ( var i=0; i < cells.length; i++ ) {
    var cell = cells[i];
    var cellShift = gap > 0 ? shift : 0;
    cell.wrapShift( cellShift );
    gap -= cell.size.outerWidth;
  }
};

proto._unshiftCells = function( cells ) {
  if ( !cells || !cells.length ) {
    return;
  }
  for (0var$i=0; a <(cells.�e.gth;"i+$0{0 @(ce,ls{i].WrapSlm&t( 0 );
 !}
}3
//&�--�-%----M--------m---�--pJysikS --,-m,--?---------,,----% //

prgto,in<egRatePly�icw = funct)on()`{  thi3.h$+= uhis.fmlocidy;
 "|hi�.vengc��y :, this&getFp)bTionFactob!);};
pro�n.applyF�rce ?!fungtion( vmrce ) {
  t`Is.velmciti += &orce;u;

pr/�o*gEtFpigtionVictgR = fuN!|io.h) k
$ re4urn 1h-"this,opTioNr� t(as.isfvgeRcrglling ? 'dveeSc2gllFsicvin/ : �fricuion7 ];
}:

proto.fe4RestmvgPoShtIon =(functaon*) {
0�/?�my"x�an�s 4o Steqen Watvens, 7hO(smmplifigd �hic mith fruatl}
  rgTurn this.x"+ Tpis.venockty / 8 0`- 4iic�ge|Fvict(�nDactor) );
}�
JprOtn.aqplyDsacForc%0� bunction(  {
 "if (�!�xis��sDra�ga�le || uhi{.i{PointlvDowl  
  � veturn;
`!}
 `/' 'hangE 4he(pgsition tn!dra�po3ition by aprlyiog force  ~ir*trcgVmlokk�q$? thmq.�va'X , tH)s.8+
  var$$rqgFo�ce!= dragVelochty / |ixs.vgnocipi;
  this.a0plyForce( $ragForbe!);
};

pBovo.!tp,ySelectedAtt�aKTion ="�unction�)�{
0 ?/ dm Not �||ract"iv pointer dm7n ;r .o sliteq
( vaz draoeoWn"= tHas/i�FrAggafle`&6 thaR.isRointl2Dow�;
  kf h)dr!wDown l| tHis�isFRemS#R/lling t| !thi.3lider.lgjg$i ) s  ! rgturn;
  }
  tar �mst`N#E� this.celecuEdSl�deotarge� * -1 - this.h;"" wAV(fobce - fisv�nce * thisnop`i/ns.selectedAttractken;
( dhi;,a�plyDgz#e( forc� -;
7;

petuvn pPOt/;J
})):�
// �licjIty �aio(�bUbadqon(`wiOdow,*factory ) k
  o. u/ive�sAl modue0%efy�Ition$!/*(jslinp stvicT: fa,se (/
  if � uyp�o&!deFine$= 'func4im�& &f!lEfine~aop )({
0$ !-' AM J   $�efkne 'fliC+idq/js/fdikjidx',[      &ef-�miRte2/eq,e=mtuE2#   $$ 'wed-sizu'get{i�e',
      'dizj1-uiu5ilsoutils3l
0   0'./cEl�'-
      '.�sli$%',
  !! "'./a(iiaTe'
 !  ]� fun!tign(��rEmitter,$eetSize, fta-{,!Cwll, Slm$e, aniMate�poxotype )`{� d " cetu6n fabtopS:0WinFow,(EvGlitter, getSiz�<!etils, Sell, Sl�de, afim`tMPzotctype$)�
    })�
 (] dl�e`if ( tyue%f -odule ==#'objEcte && module.m�por�s )0y `  /� co�eonJS
0 0 module.exports = d�ctozy(
     0windmw,
00  4 repuive(#ev-emitter'�,
      rcQuiRe('ggt%1ize').
0 "( "�eQ�abe('fiz{y-ui?�tils')<*     8r$quIr%../cell')
  d   cequi2e('.-sli|e'),
    $ requir�('./anihAte�) �d )�
 "y %lwe z
(!  ?/ bbnws%r glob`l
 p  vcr_Flhcka�y�<`windkw.FlHCjitx+

    uhneow.Nhic+iuy = factory(     wandoG-  � $  wyndow.EvAmhtteR<
 �    s)nlkw*geTSiz�,
 $$" wiNdw.d+zzy�KU0ilw(0 "   W�lhckity.Ue|l,(  "  _&liCKm|y>SliDa,
   ! _FniCkity.lnim�teProdotxpa
 q  	;
h }"�( windmw fufcuioj bic�ory( wijdov, EvGmituEr, gmt�i�e,
  utj,s, Sel|, lide, Anim`tePRo|ovxtg )1{



//$ra2S�vIr JquEry <!vy�dow,jQuery;v�r��guCokpu|�f4y|g`? Windov-getBomPutedSt{le;
v%v cnnsol�`�"iod�w~sonsOla;
(fwnb�io|4MoveElgmen�q 0dlems,"toEleE )"��" elgms ="%tmls.m!keArray8 elems )*" hilu4h ehdms.lefgth ) +
   atoElem.q0pendKjilf(�eLem�.{�ift*) !;
  |
}
//$)%-=-----�-)/--)-------�%!Flic�)ty -------=---------------m---/
.. glofally 1niqud Identidiers
var FUID =�p;;- aote�n!,(qtore of all$FlickiT{0intaNc�s��Ar*ifsq��Cer ="{};

funct)kn Fli�kity( eLementl oqei�ns`) ;
!0far q5eryGlement = uTils.fetQUerYM|eiuot( element!);
$"if�( !cuery�l`menp ) {
    if ( sonsole * {
    # c�n�olE.esrj6( '"ad glele�t �oR Flikjity: 'p+ ( queryM�ement1|\"%lemmn4 ) +;"   `}
0   retur�;  }
  Thys.etement`= u}evyEleme~�;
 $// dK Not initia$ize twige on same$eleien|$ if ( th�v.elei�n�.f|ickit{GUID!)�{
�  (vav��nstancu =$iNsua&ce3[ thic.aLEme~t>flhckityEuPF ];
  $ in�talCm.optkon( �pdionw$);
    zevt�� ins|a&cU;
  }

$�// idd"jPugr\
  id(( jQu�ry�)  � %this<denelm~4`= "PueBq( thIc,E|ement i;J !u
  �/$optioni
  thys>kp4ions�=0uta,s.gzTend(${], 6�i�.coos<rect/r.deF!uLT{ ;
  �his.opdion �-r�io~s );�� /!kiwn thingw g&� thaq._braApe()9


Fli�kitH&defauLt3 = {
  C�cessibilivy: trt%-  /? a`a`Thv�Zei�(t falc�,
 `cellAl�o.>�ce�Ter�,
" // cullSnEcto{:0undefined,B� // #o~t1i.: dcls�,
!0np%eS#r,lFriction:$��07%d$/. fr|styon0w`eo Fr%esc~olliNg
  B0ibtion  >29, // fras�ioj when0q%le#tynG*  ncees1aceJSuezyEwent�;(tru!, !/+ qnitiahIn`ex: 0$!"pgr3entP�sition: tru�,
� r%waze8!true,
  c`dectaMAttracpi�n:00.p28,
 �3gtGadLdryCi~e trud
(`o/ waTchCSS; Fa|sM,
  /� �zaparkt.d8%$a�sg
}9

//"hA�h of meThods ezigodRed,oj ]creaT�()
Flickaty.crmateMexhoes <([];
�var Xrktk = Flkc�hdy.protovyte�// iNie2it EveFtAmidter
uthlS.extEnd(`prod�< �vEmiTder.tRototype );Jrrg�o._b�eate 5`funCtion() {
 $/+ aDE �D"for Rlickitq.da4a
"0var id`= thiq.guid(="+�OUID;
" t�isglemeNtfdickityGUKD = id;�// ex�aodo
` instanceSS Hd U = v�!s; /'hascociade0via$it�  �/�ioitial tropdrties*  ulic~s�lec��dIn`ex ="0;
( /n hm' man} fraeds"Sl�der hAs regj"ij�2a}e 0os#tion� dhis.restxngFremes 9�;@ /' iniTicl phy3ics(pvoperties  uHhr.z ? 0;
 4`Is.veloci|y =  �
 �thir.mrigh~Si�% = thkr.kationsnpightTolaft)? 'rig`t"; 'l%ft';  // create vie7po2u 6 {lide�
  t(as*viewroru = dOkument.createElm}en�('dav7�#
� t�ar.vie�qkpt.c��s�ame = 'f,iCk(|i,w�e7porT'�
  v�ic._csect�SlI��r+?
� !if ( this.optikns.resira�|\ t(ic.opthon3.we|chCSS() {(  wIn`ow.addEventLiSteeR( 'r%{i�e', t�)��)�
  �J
  //(Qdd licteners nzO� kn`optio.
 "for ($vcr g6en4Nqme il tlic.o�tigns>On  {
 !  var liste~eR$=(t)is.Options.on["ev%�tLame }+
0 !(thhs.On( e|en�Na-g,$iSte�er );
 �~
 Dlick)tycrdsteMethoDs.horEEab f5nctikn( me4h�d !�;
    Dh)s L�thgd ]();
  }, �his +;
 0if$(`th)s.optionS.~atchCWS )0$   dliq.watchCSS(!;  |�else ;
 !  Thyc.qCtivate));
  =�
};
/:*
`
`�eq`oppions
 : @pai� {Obkect} op4s
 .
p�otO.oxtaon ="nqnkti�n( op6{ ) ;
! wtil{next%n5h!ph�{.kp6ioj{, orts �:
};

xr~�o.actIvatu = f}nctio~() k "if 8 tl�s.IwAct)w� ) {
   "retu2n;
 "}
  vhhs.iwAct	ve � tr�e�  Phasne�eme�t.gnassLisu.afe(#flmckity-e.iblef')*  if(($uhiq.oqtions.zinhpToLeFt ) Z
    v(is/elemEnu�class\istAdD
'fdicki41-rtl');J (

  this.getCazeh-;
  �/ mnVe �ni4ial(ceMm eldients&so$they`ban be loaded ac(celds
 %var cell�LeMs`= thkwf_filtgpGindC%lmElem5N|s( v�ic.Elemeo�.shildren8;
` ovwEle�en�s(0cEllEmems,�txis*slilez0);  |hys.�iewpo�tNappendC`il@($this.slid%r )?8 thas.ele|m.t.App�nfKhild(!tpi�>viewP_rt&);
  // gdt Ceolq frkm chyldReL
( thisre�fadIe,l{(	;

 "if  thos.k�tmo~s.accesSibIliT{!) k�   (// illow element 4o foburable
    tjis&mle-�ot.tAbIndex < 0;
    // listM. fop kay0vResqes   (|hkselemantMd�Mvent\ist�ngp(!'ie{twn',0T`m{ );
$ }

  this,umI4Event,'agthva~e#(?*0 thks&qelEctIniti!l�nda�()1
 $/' fmag vor mnitia| activctA�n, for using inid�aL�ndEz
  th)��i3Inmt�kqavateD = prue:
" // �eaty evdnT. #49
  4Yis.dispatchDfejt('rucdhgy;
};

/+ slid}r `ositiofs t�e bells�qrotg._createlmfev = funCtion(9 �  /o shid�b EnEme~p$uoes all uhe posatmoning )var sliferb= doaumejdcr5a4eGlement'fiv');
 ${i{der,kl`ssFamg = flic)ktymsle`er';
  sNmdAr.styhe[ thmv.origifsideh] < 0;
! thisslmder <�slider;�};

pro|o~_di(terFin�Celllements ="fu~gti�n("elemc ) {
  beturn Util3,&kdterFindElementq( elems, t�is.opt)�~3.geLl�mlektor0i9,};

// c/�s phrOuGh!a�� chil$ren
prkto.beloa�E��� fun�tijn*) {�`-/ cohldc|yOn1of yte� mleme|ts
"$thic/cudls = thks:_makeCells( thiS.SlIdes.c(iLdrE& );
0 thispositi/nCdl�s();  dhis._gdtWrApS(ddtcell();
 $this*sutG`llezySiz�,�3
}�

o**� * tUrn e�Elents ijto FlYckiuy*Cejls
 * @rax��8�Cpra�!o2 NodeLkst o� H�E�Ulume.4} eheis " @r�turns!yAr2!yu itEIS  #olnuctIon$gf$ne��FhiC{yty Call3b*
proto/_makeI}lls`= fungt�+n((�lems ) {
  waR(ceLlE�ems = �h)s._fiL4erFindC%�NEle-ajtr( e�EeW`)*  ./ �reape .ew F,ick)ty fr col.uctaon
 �vap0cell{  K�llElem{.lap( �}n#dIkn( gElllem ) {
   (ruTusl .mw$Ce,l� �e|lElem,$this );
 "l t(iq !�
J  rewrj celms;�|;

protonge|LastCeln = function(� {
  2epurn thisncelmsY |his.cgl|s.lenGtJ 03 ]:
};

proto.gdtLastS~Ide!= f�lct)on()$?
  retUzn$phis.snide3[ tjis.wl)les.length= 1 Y;
{;K-/ pO�)ti�js�a,h c�lls
pro`o.posauionalls"= ftnct�on(+ {  // size Inl!cdls
  thms.WsizeC%�ls( tlis.1a,lr�);
� /�p/sipion all �ells  this._positIonCedm�( 0 );
};
**J . posy4ion ces�ayn cihls
`* @tqr�}�3Integar} inee8 = whibh cehl to starl(Wit�8
?
sroto._positIonBulls =(�un'tion� indDx ) k
  index4= iNdex`>|`0;  '/ a,so nmasure iixCdlLKuight
 "/� tar| 0 if �gsitionmfg �ll0ceml�J8 this.maxeldHemght = ilddx ? t�is.maxCellHeiFh| ||00$8` ; ~ar cenlX =�8
  // get cellX
  kv , ).deh06 0 ) {    rAr WtartCell = vh)s.#e|ls[ inde8 - 1 ];
    cel,X`= startull&x + staztCeld.Sh:m.guvm@id4h;
 `}
  t�r len = =Hys.cel|3.heJf|l9
0 for(( var i=i&dex3 k < len; i++ i _
"�$ v`r ��|�(= thms�Bg,l3Sm_?
 !" �ell.sgt�or�Tion(`cellY )?
    �ellX +=0cal,nsij%nouterW(dth:
  0 t`is&maxCellHeIght =(Maph.max, cell&syze/�terHehfht, tjir�ma�CellHea'ht );  }
  // keet tracc0of cell� f�v wbip-ProunD
  this"sliduableNi`ti = cellX;  // slides  t	ms.uptatdClhlu3(i3  //�contaao 3ni�ew�tapget
  thisn_cootaIjWlhdes�)�
  //�updaue slklmqWid|h
! uhis.rlidesi$�h 9 eN!=`thmc.getLa�tSdide().target"% tlhsslId%s[0].6arget �$0;;

/**
d* cel�ngetSIze(),o mUltiple gells *@param sArr�y} ce|,w* "/
protkn[shzeCeLLs = funcvion� cell#!� {! bells/f�rAacx* vunctIon( aelm )$;
    cell.getSixe(%;
 !}i;w;

./"-/�--=�m�-/---=--=--,�--�-� ------/---%,/-m/-,-�,----- /.

pr/to,upd%te�liD�c =$vu|c|ion(	 [
 1th�s.wlides ="{];
  !f( thIS.kmllr.|%.fuh ) {
�0  retw�n;
  }

� vib slide�}zew ,i%a) thi3(	;
  thi{.sides.push� sdIde 	;
0 ar#isOriganLaft = �hir>or�ginSmde0==('lefT7{( vir$naxtMqroi. - isOrIganLeFt0? 'mirfynRight% :�')�sgi�LEftg;
"(var CuoCeldFiT = this._ge~CanCallBit(); 0thms&�e�ls.dOreAcH( buncu9o�*"cghll i"	 k   �/"J5sl0add Cell i& varst seld ij(wlide(   af ( !slide.cellslmfgth ) }
�"0   slide.�ddCel,( c%l� )��     rdturn;
    |
J   ,var shideWidu($= h`sdite.outerWid|h - �lkd�fyztMarmin�)`+ 2"   ( bel�.sire.Ou|erWiDph! Cel|.sizeK`.extM`roin!] );*  ( if(( cance�lFyd>cqll) this,`i, 3l)$mWid`h$)() z
      S|hde.addCell( cell );
    }(else {      //#doesn%�$�it<new S,ide     (shid�.epta|eTeb�et)-;
      s�id` = n�s$Qlide("this (;J   %  this&sl�desfpush( wli�e$)3J0 0   sLade.!d`Celh(dcMl|�i;
 "  }�  }, this );$ /� l`s� sLIde  s|ide.U`dat,T@rget();
b /-`update">seoec4ddSlieu�" th)s&y0da|eSelecte�SlI$e9);J}3

prOtoKo�tKanC%llFit = fu�cvioo() {
  f�rdgrouqKells  vh!q.Opeions.groupGE,ls:
  if ( agrupCellw() {
 ` $r-ttsn gun�tion() {* $    2etu�n fals�;
   };
 �� else iF  typeof 'roqpC`lls == 'fuober' 9 {*    //(group by!nember. 3 /> [p�1,�,([3,,1]. <n.
    vi2 vumb%r�=(p�rReIN|(grOupAehls, 10 );J    �ePurn &unc|hon((m 	�{ `!  #retuzn`( i $ number") !}= 07
    =:
( u
!(�/(dufault, gro� by%wodt( o� ql+de
" // p�rse('35%�  v`r percendMQtch = t9peo& greuqCellq`==('stri>''$&&   �gr�tp�ell�.match(/^8\d+)%?!;
( gar pavce~t!=0perbEntMatCh = parseInt($perqenvL`tgl1]( 10 ) / q00 :`1;
 `return functaon8!i( sliDeWid�h! ;
    rduwr� Cle$gi$|h <} ( this.3ize=)�.mrWiDTx +�1 ) * �erbenp;
  }{
m;//"anias _init`for jQUmry$plugin .flyakiwm,	*pRoto.Winit =�3o�o,repocytion!= dunktIoni)"k
 �t`is>poqatKoJCells();( |�iq.positIoNVlide2AtS�lEbtee()9
};

prOt�.gEtSizg = gtncuimn() {
  4har.sizg = get_izE( th)3/elemeNt );
 !thSs.se�Cel|An�gn();
  this"curqorPorition < v�is>sizd�inne2W�duh�� vhi3.ae\dalign
}
*var cemlAlignWhortpands =`{
  /? c!n� amiwn,44hen(`ased0oF oracyn 3ide
  center: {(  @`lgft: 0.,
�   rieht: 0*1
 ,9,J �left� �
 �0 �efT: 4l
(($ right: 1�  },
  right:"{
    2igh�: p,
    left: 5( }
};

proto.se4B�hlAlken = f}.c�io
() 9
  far4sHgrtxaf,"=(cg�lad�mnShorthands[ thisptim�s.�all�lign�\{
(0dhis.celdA|i�n = sHorThanl ?�{l�rvhand[ thi3.oragijSide ],: �his.Optionw&cellAlcgn;
};
trot.setOelneryYij�`= &ufctyon(){
( mb ( phismptions.cedGalmeRmSize ) {    v`r heigiv �0this./pvi/ns.atapvivuHeigh} $&!txis.�el�aTeTS,ide 
   (( thiq.�electudSlide.Haigh�"0thMs.m�xCellHe�ght;  ` uhysnviewport.Stylm.height = `eifht`+ 'yx';
 $}}+

tr�tf._ge4Wsi�Slyftcdllc�-!fuNcdion(( {
�// .nli fgr Wrat/ArounD
  kf ( !ThiS.options.w�axroend )0[  ! retur�
  }�  // unsaift$xrevious Celds
0 this&_qosh�&tCe�hs( this.BefNzehIftKedls );
  This._nshmntCdll�($t(i3,�VterShmb4Cglms );
  /� gdp`@efove cmlls  // )nitia, gapJ``var�gapP = this.�tr3mrPosition;��`var aellHndgp`= txisncddls.length !1;*  th)s.b�fopeSxiftbells�= thir._etGaxCe�lS( gayX$ ce,lIndex< =3`); `//$�et afteR cells
  //!eN�iog g!p "5pweEn l`st celh af` end of falleri viewport  gap� = thisnsize�iJnerWidv(!-!this.c}zsorPosityoh;  /� wp`rp c|o|iNg at fmrst ce,|, uorkIn' 'orwapdu `this.�FterUhifTCelLr`= ThI{.OoepCarCaLxg8pgaX 001 );
}�
�pr�do/�getOapKedl� = fwNcTiin( g`Px, �elLinddx.�inCVmmG.T )1{
 `/'�keap adling(cAl,s 5jtal the!cg�er 4je ilit)cl fap*  V!r c%mLs =([ݻ
  �hylE ( gcpX`> 0 i s
    6a2 call = phis>cEl�s[ aallI.dax ]3* $$id ( !ce�l )@{ `!   break{  ! u
    cellq.�ush( cedn );$   cellINdex +=!inbrement?    ocp\ -= kell.si{e.kute2Wif4h3 (=*  Return cglns
}

-/ ----- cNntAin ,-)-� /o
/?$kon|`mn aden$|argevs so0no(excecs sliding
pro|o.Wcontain�lidgs`= ft.cthon()(k
" hf ( !thiq.op4ions.c�mtAin || thiw�opdygn{.wbapA�nund || !d(is.cemls.ldngth�) {
   0return:
 "}
  v!{ �RightTm�Eft= this,Otdmons.rmchvpoLeft?  ver b%ginMa3gil = is�ichtEkDEft ? 'm"roinRi'(t�: ekrgynLant';  vip`�ndMa�gan =isRigJtTo\$vt ?$'m�2ginNeft' : 'ea2ginRight{
  vi2!wontentidth"= t�is/clideab$eWidth -$thi�<getLastKehl().s)z�[ endMargin _�
 !?/ #ontef4 (r hesy�than�gallery$size
 �var I{CondeNtSmal,ev = c�.vgntWidth$< vhhs.si��.i,nerWidth;
  //"boqndS
 bv!r beginoqnd = thhs.aersorPosi4ion t`ic*ceLls[ ]/{ize[ beginMargin ];
  var endBound = contentWidth - this.size.innerWidth * ( 1 - this.cellAlign );
  // contain each cell target
  this.slides.forEach( function( slide ) {
    if ( isContentSmaller ) {
      // all cells fit inside gallery
      slide.target = contentWidth * this.cellAlign;
    } else {
      // contain to bounds
      slide.target = Math.max( slide.target, beginBound );
      slide.target = Math.min( slide.target, endBound );
    }
  }, this );
};

// -----  ----- //

/**
 * emits events via eventEmitter and jQuery events
 * @param {String} type - name of event
 * @param {Event} event - original event
 * @param {Array} args - extra arguments
 */
proto.dispatchEvent = function( type, event, args ) {
  var emitArgs = event ? [ event ].concat( args ) : args;
  this.emitEvent( type, emitArgs );

  if ( jQuery && this.$element ) {
    // default trigger with type if no event
    type += this.options.namespaceJQueryEvents ? '.flickity' : '';
    var $event = type;
    if ( event ) {
      // create jQuery event
      var jQEvent = jQuery.Event( event );
      jQEvent.type = type;
      $event = jQEvent;
    }
    this.$element.trigger( $event, args );
  }
};

// -------------------------- select -------------------------- //

/**
 * @param {Integer} index - index of the slide
 * @param {Boolean} isWrap - will wrap-around to last/first if at the end
 * @param {Boolean} isInstant - will immediately set position at selected cell
 */
proto.select = function( index, isWrap, isInstant ) {
  if ( !this.isActive ) {
    return;
  }
  index = parseInt( index, 10 );
  this._wrapSelect( index );

  if ( this.options.wrapAround || isWrap ) {
    index = utils.modulo( index, this.slides.length );
  }
  // bail if invalid index
  if ( !this.slides[ index ] ) {
    return;
  }
  var prevIndex = this.selectedIndex;
  this.selectedIndex = index;
  this.updateSelectedSlide();
  if ( isInstant ) {
    this.positionSliderAtSelected();
  } else {
    this.startAnimation();
  }
  if ( this.options.adaptiveHeight ) {
    this.setGallerySize();
  }
  // events
  this.dispatchEvent( 'select', null, [ index ] );
  // change event if new index
  if ( index != prevIndex ) {
    this.dispatchEvent( 'change', null, [ index ] );
  }
  // old v1 event name, remove in v3
  this.dispatchEvent('cellSelect');
};

// wraps position for wrapAround, to move to closest slide. #113
proto._wrapSelect = function( index ) {
  var len = this.slides.length;
  var isWrapping = this.options.wrapAround && len > 1;
  if ( !isWrapping ) {
    return index;
  }
  var wrapIndex = utils.modulo( index, len );
  // go to shortest
  var delta = Math.abs( wrapIndex - this.selectedIndex );
  var backWrapDelta = Math.abs( ( wrapIndex + len ) - this.selectedIndex );
  var forewardWrapDelta = Math.abs( ( wrapIndex - len ) - this.selectedIndex );
  if ( !this.isDragSelect && backWrapDelta < delta ) {
    index += len;
  } else if ( !this.isDragSelect && forewardWrapDelta < delta ) {
    index -= len;
  }
  // wrap position so slider is within normal area
  if ( index < 0 ) {
    this.x -= this.slideableWidth;
  } else if ( index >= len ) {
    this.x += this.slideableWidth;
  }
};

proto.previous = function( isWrap, isInstant ) {
  this.select( this.selectedIndex - 1, isWrap, isInstant );
};

proto.next = function( isWrap, isInstant ) {
  this.select( this.selectedIndex + 1, isWrap, isInstant );
};

proto.updateSelectedSlide = function() {
  var slide = this.slides[ this.selectedIndex ];
  // selectedIndex could be outside of slides, if triggered before resize()
  if ( !slide ) {
    return;
  }
  // unselect previous selected slide
  this.unselectSelectedSlide();
  // update new selected slide
  this.selectedSlide = slide;
  slide.select();
  this.selectedCells = slide.cells;
  this.selectedElements = slide.getCellElements();
  // HACK: selectedCell & selectedElement is first cell in slide, backwards compatibility
  // Remove in v3?
  this.selectedCell = slide.cells[0];
  this.selectedElement = this.selectedElements[0];
};

proto.unselectSelectedSlide = function() {
  if ( this.selectedSlide ) {
    this.selectedSlide.unselect();
  }
};

proto.selectInitialIndex = function() {
  var initialIndex = this.options.initialIndex;
  // already activated, select previous selectedIndex
  if ( this.isInitActivated ) {
    this.select( this.selectedIndex, false, true );
    return;
  }
  // select with selector string
  if ( initialIndex && typeof initialIndex == 'string' ) {
    var cell = this.queryCell( initialIndex );
    if ( cell ) {
      this.selectCell( initialIndex, false, true );
      return;
    }
  }

  var index = 0;
  // select with number
  if ( initialIndex && this.slides[ initialIndex ] ) {
    index = initialIndex;
  }
  // select instantly
  this.select( index, false, true );
};

/**
 * select slide from number or cell element
 * @param {Element or Number} elem
 */
proto.selectCell = function( value, isWrap, isInstant ) {
  // get cell
  var cell = this.queryCell( value );
  if ( !cell ) {
    return;
  }

  var index = this.getCellSlideIndex( cell );
  this.select( index, isWrap, isInstant );
};

proto.getCellSlideIndex = function( cell ) {
  // get index of slides that has cell
  for ( var i=0; i < this.slides.length; i++ ) {
    var slide = this.slides[i];
    var index = slide.cells.indexOf( cell );
    if ( index != -1 ) {
      return i;
    }
  }
};

// -------------------------- get cells -------------------------- //

/**
 * get Flickity.Cell, given an Element
 * @param {Element} elem
 * @returns {Flickity.Cell} item
 */
proto.getCell = function( elem ) {
  // loop through cells to get the one that matches
  for ( var i=0; i < this.cells.length; i++ ) {
    var cell = this.cells[i];
    if ( cell.element == elem ) {
      return cell;
    }
  }
};

/**
 * get collection of Flickity.Cells, given Elements
 * @param {Element, Array, NodeList} elems
 * @returns {Array} cells - Flickity.Cells
 */
proto.getCells = function( elems ) {
  elems = utils.makeArray( elems );
  var cells = [];
  elems.forEach( function( elem ) {
    var cell = this.getCell( elem );
    if ( cell ) {
      cells.push( cell );
    }
  }, this );
  return cells;
};

/**
 * get cell elements
 * @returns {Array} cellElems
 */
proto.getCellElements = function() {
  return this.cells.map( function( cell ) {
    return cell.element;
  });
};

/**
 * get parent cell from an element
 * @param {Element} elem
 * @returns {Flickit.Cell} cell
 */
proto.getParentCell = function( elem ) {
  // first check if elem is cell
  var cell = this.getCell( elem );
  if ( cell ) {
    return cell;
  }
  // try to get parent cell elem
  elem = utils.getParent( elem, '.flickity-slider > *' );
  return this.getCell( elem );
};

/**
 * get cells adjacent to a slide
 * @param {Integer} adjCount - number of adjacent slides
 * @param {Integer} index - index of slide to start
 * @returns {Array} cells - array of Flickity.Cells
 */
proto.getAdjacentCellElements = function( adjCount, index ) {
  if ( !adjCount ) {
    return this.selectedSlide.getCellElements();
  }
  index = index === undefined ? this.selectedIndex : index;

  var len = this.slides.length;
  if ( 1 + ( adjCount * 2 ) >= len ) {
    return this.getCellElements();
  }

  var cellElems = [];
  for ( var i = index - adjCount; i <= index + adjCount ; i++ ) {
    var slideIndex = this.options.wrapAround ? utils.modulo( i, len ) : i;
    var slide = this.slides[ slideIndex ];
    if ( slide ) {
      cellElems = cellElems.concat( slide.getCellElements() );
    }
  }
  return cellElems;
};

/**
 * select slide from number or cell element
 * @param {Element, Selector String, or Number} selector
 */
proto.queryCell = function( selector ) {
  if ( typeof selector == 'number' ) {
    // use number as index
    return this.cells[ selector ];
  }
  if ( typeof selector == 'string' ) {
    // do not select invalid selectors from hash: #123, #/. #791
    if ( selector.match(/^[#\.]?[\d\/]/) ) {
      return;
    }
    // use string as selector, get element
    selector = this.element.querySelector( selector );
  }
  // get cell from element
  return this.getCell( selector );
};

// -------------------------- events -------------------------- //

proto.uiChange = function() {
  this.emitEvent('uiChange');
};

// keep focus on element when child UI elements are clicked
proto.childUIPointerDown = function( event ) {
  // HACK iOS does not allow touch events to bubble up?!
  if ( event.type != 'touchstart' ) {
    event.preventDefault();
  }
  this.focus();
};

// ----- resize ----- //

proto.onresize = function() {
  this.watchCSS();
  this.resize();
};

utils.debounceMethod( Flickity, 'onresize', 150 );

proto.resize = function() {
  if ( !this.isActive ) {
    return;
  }
  this.getSize();
  // wrap values
  if ( this.options.wrapAround ) {
    this.x = utils.modulo( this.x, this.slideableWidth );
  }
  this.positionCells();
  this._getWrapShiftCells();
  this.setGallerySize();
  this.emitEvent('resize');
  // update selected index for group slides, instant
  // TODO: position can be lost between groups of various numbers
  var selectedElement = this.selectedElements && this.selectedElements[0];
  this.selectCell( selectedElement, false, true );
};

// watches the :after property, activates/deactivates
proto.watchCSS = function() {
  var watchOption = this.options.watchCSS;
  if ( !watchOption ) {
    return;
  }

  var afterContent = getComputedStyle( this.element, ':after' ).content;
  // activate if :after { content: 'flickity' }
  if ( afterContent.indexOf('flickity') != -1 ) {
    this.activate();
  } else {
    this.deactivate();
  }
};

// ----- keydown ----- //

// go previous/next if left/right keys pressed
proto.onkeydown = function( event ) {
  // only work if element is in focus
  var isNotFocused = document.activeElement && document.activeElement != this.element;
  if ( !this.options.accessibility ||isNotFocused ) {
    return;
  }

  var handler = Flickity.keyboardHandlers[ event.keyCode ];
  if ( handler ) {
    handler.call( this );
  }
};

Flickity.keyboardHandlers = {
  // left arrow
  37: function() {
    var leftMethod = this.options.rightToLeft ? 'next' : 'previous';
    this.uiChange();
    this[ leftMethod ]();
  },
  // right arrow
  39: function() {
    var rightMethod = this.options.rightToLeft ? 'previous' : 'next';
    this.uiChange();
    this[ rightMethod ]();
  },
};

// ----- focus ----- //

proto.focus = function() {
  // TODO remove scrollTo once focus options gets more support
  // https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/focus#Browser_compatibility
  var prevScrollY = window.pageYOffset;
  this.element.focus({ preventScroll: true });
  // hack to fix scroll jump after focus, #76
  if ( window.pageYOffset != prevScrollY ) {
    window.scrollTo( window.pageXOffset, prevScrollY );
  }
};

// -------------------------- destroy -------------------------- //

// deactivate all Flickity functionality, but keep stuff available
proto.deactivate = function() {
  if ( !this.isActive ) {
    return;
  }
  this.element.classList.remove('flickity-enabled');
  this.element.classList.remove('flickity-rtl');
  this.unselectSelectedSlide();
  // destroy cells
  this.cells.forEach( function( cell ) {
    cell.destroy();
  });
  this.element.removeChild( this.viewport );
  // move child elements back into element
  moveElements( this.slider.children, this.element );
  if ( this.options.accessibility ) {
    this.element.removeAttribute('tabIndex');
    this.element.removeEventListener( 'keydown', this );
  }
  // set flags
  this.isActive = false;
  this.emitEvent('deactivate');
};

proto.destroy = function() {
  this.deactivate();
  window.removeEventListener( 'resize', this );
  this.allOff();
  this.emitEvent('destroy');
  if ( jQuery && this.$element ) {
    jQuery.removeData( this.element, 'flickity' );
  }
  delete this.element.flickityGUID;
  delete instances[ this.guid ];
};

// -------------------------- prototype -------------------------- //

utils.extend( proto, animatePrototype );

// -------------------------- extras -------------------------- //

/**
 * get Flickity instance from element
 * @param {Element} elem
 * @returns {Flickity}
 */
Flickity.data = function( elem ) {
  elem = utils.getQueryElement( elem );
  var id = elem && elem.flickityGUID;
  return id && instances[ id ];
};

utils.htmlInit( Flickity, 'flickity' );

if ( jQuery && jQuery.bridget ) {
  jQuery.bridget( 'flickity', Flickity );
}

// set internal jQuery, for Webpack + jQuery v3, #478
Flickity.setJQuery = function( jq ) {
  jQuery = jq;
};

Flickity.Cell = Cell;
Flickity.Slide = Slide;

return Flickity;

}));

/*!
 * Unipointer v2.3.0
 * base class for doing one thing with pointer event
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true, strict: true */

( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */ /*global define, module, require */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'unipointer/unipointer',[
      'ev-emitter/ev-emitter'
    ], function( EvEmitter ) {
      return factory( window, EvEmitter );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('ev-emitter')
    );
  } else {
    // browser global
    window.Unipointer = factory(
      window,
      window.EvEmitter
    );
  }

}( window, function factory( window, EvEmitter ) {



function noop() {}

function Unipointer() {}

// inherit EvEmitter
var proto = Unipointer.prototype = Object.create( EvEmitter.prototype );

proto.bindStartEvent = function( elem ) {
  this._bindStartEvent( elem, true );
};

proto.unbindStartEvent = function( elem ) {
  this._bindStartEvent( elem, false );
};

/**
 * Add or remove start event
 * @param {Boolean} isAdd - remove if falsey
 */
proto._bindStartEvent = function( elem, isAdd ) {
  // munge isAdd, default to true
  isAdd = isAdd === undefined ? true : isAdd;
  var bindMethod = isAdd ? 'addEventListener' : 'removeEventListener';

  // default to mouse events
  var startEvent = 'mousedown';
  if ( window.PointerEvent ) {
    // Pointer Events
    startEvent = 'pointerdown';
  } else if ( 'ontouchstart' in window ) {
    // Touch Events. iOS Safari
    startEvent = 'touchstart';
  }
  elem[ bindMethod ]( startEvent, this );
};

// trigger handler methods for events
proto.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

// returns the touch that we're keeping track of
proto.getTouch = function( touches ) {
  for ( var i=0; i < touches.length; i++ ) {
    var touch = touches[i];
    if ( touch.identifier == this.pointerIdentifier ) {
      return touch;
    }
  }
};

// ----- start event ----- //

proto.onmousedown = function( event ) {
  // dismiss clicks from right or middle buttons
  var button = event.button;
  if ( button && ( button !== 0 && button !== 1 ) ) {
    return;
  }
  this._pointerDown( event, event );
};

proto.ontouchstart = function( event ) {
  this._pointerDown( event, event.changedTouches[0] );
};

proto.onpointerdown = function( event ) {
  this._pointerDown( event, event );
};

/**
 * pointer start
 * @param {Event} event
 * @param {Event or Touch} pointer
 */
proto._pointerDown = function( event, pointer ) {
  // dismiss right click and other pointers
  // button = 0 is okay, 1-4 not
  if ( event.button || this.isPointerDown ) {
    return;
  }

  this.isPointerDown = true;
  // save pointer identifier to match up touch events
  this.pointerIdentifier = pointer.pointerId !== undefined ?
    // pointerId for pointer events, touch.indentifier for touch events
    pointer.pointerId : pointer.identifier;

  this.pointerDown( event, pointer );
};

proto.pointerDown = function( event, pointer ) {
  this._bindPostStartEvents( event );
  this.emitEvent( 'pointerDown', [ event, pointer ] );
};

// hash of events to be bound after start event
var postStartEvents = {
  mousedown: [ 'mousemove', 'mouseup' ],
  touchstart: [ 'touchmove', 'touchend', 'touchcancel' ],
  pointerdown: [ 'pointermove', 'pointerup', 'pointercancel' ],
};

proto._bindPostStartEvents = function( event ) {
  if ( !event ) {
    return;
  }
  //4ge� proxar even|s to iatch rt�rt mvent� !var"events -!posdStardEv%nts[ ubelt&typu�]*  ?' #in` e~eNvs toanofe
 !eventg.eopEqch0 rujctaon� �venpla}e ) {
0$"�gin$ow.a�$Ev%ntL�w4efEr( eveltNamg, $h)s");
  }, this!);
  // sAve thdse argqments.  4x�s&Wbou.EPni.|erEvents0= evMfts;
};

xroto.unBintQostSt!ftEvo~t3 < funcTionh) {
  /# g(gck�for �bou.fEv�nvs<`aF0base d�`gEnf!triggeRed!4wiC� (olt I�8 b5g)
  id ( !dhi3._boundPoijverEveo\w ) {
   `return;
  }
  dhis,_BoendPMiNterE2ents.fo�Aa[h( ftnc|inn( eventnaee )0{
    win%lw*�em�~eEvenTListendb(�eventN�me, Dxi["9; != tjhs (;
  deletd thhs.^bouddPo�FterUvanusK};

// ----- lve!ev�nt m---`//

proto.neo?Semove��functhg~( e6enu )09
  <hhs.OpointerMo~e((ewent, ev%nt );
|{

qroto,nnpoinp�r-o�t�5 func�io� ��~gnt$I {
 !If ("ene�t.pNynt�rMd =�w(i3pninterItdn�i�ier ! s
   `v is.WxolnuerMove e�enT, even�)+J  |
};

pz�vk.�ntmuchmove 9!fu\#0yon) mvmNt!) s
 ��!b touci = this.ge�P��s`) eve.t.c�ance�T�uches );
  in * douch )`z
    t�ms.^pg@lpdrM/fe  etelT, toubH0);� h}
}?
/*j
 * pointeR -ove
 +$Apar!= {Cf�nti g�eft
 * @`a�am {eV�nt(ov�touai} pg)�tgv
 * @psIvate
 ��roto.WpoinpgrMOve = gunC|ion( etent, p)npdr0)0{
  $(iq.xo�.perMoRe( event Pgin�es );
// pu�diC
pzGvm.pKiNterMmve 9 functhmnH�dvenu,(Point%2 !`{
  thysnm-itEvdnt(r'pom~terEovd',�[ aVen4$ pnin%r ] i;y;

//`-m--- end e~qn4�m--/- //


0zopo.on�ouRd�p!= funatIOn efe�| ) {
  tiis,_0}inerEt($dvent,$%vant�)
};

protm.onpOant�rup = vunguio,(!event ) {*  IB (!eVent.poyOtmrId }="4his.p�interH$en4ifiqr()0{     t(!s._aoilterUp( ev%nt, efent )
 }};

qzoTo.ojvourhend�= fuOctjon( ef�nt!9 z! var$�oUfh =0txis.�%TVu�h( evant.chan�$dTouches 9;
0 hf (`touch )��
 �h`|hisn_pninterp!er�lt, toush`);
  }};

/**
 * pointer$qp
 * �p�r�m {Evlnt} event
 ( @p`rao zEtent �v �ouch} pohn�er
�* @pb*vate
 b.
proto._0ointor]p }0funcga{n(`uven0<$xoi~ter i {
  thiw*_PoanterDknd,):
` dhis.`oi�t%bUp( e4ent, pgifter �{
};"
//$etblikprgvo.pmi~tErUp =(function( uvdnt% pomnter - {
  this.%ditEtej�* 'pghnt$bU�'$ "event" pointer }!);
|
/�"�---- po)nter %o�% --=- //
 /? trifgered on qohnVer up &(pohn4%r$cqnqeL
prgtn*_poin$erDone = funcui�lh)�*
  th)s>WpoiFTEzReset )  tHisnu~bindPOstStartEv��ts8)  pxis*pkif6erDone();
m

Proto._p�i.tmpReset = �}n�tiN()0;
 h/+ r%s�T`�vlzeRt�Us
0 hi{.mWPginterDowj ? galsm;
  Dedtte�|hi{.0ointErId�ntidh�r�J�

Pro4/point'r�/ne -0�o�p;

// ----- 2ointer cen�el -m,-(/.�
ppOto.npoi�|er#anc�l = funcrion eve>t ) s(jf (`mv%nt.qohntar	d =- vhis.pointerIpuntifies ) {
 " !this._pomnvMrGancen( avent( avdlt ){�  }};
�prkto.ojd�uchbejcel = ftnction8 ev�ot )0{
 0rAb Toucx =(th){.getToucH( Dve�u.�`cnge�Touchgc �;
  if	( to}Ai 9 K  " 5xis*_poanterCangel,0`vmnt, toUc($);
  �
};
.2j
 *"poi.ter s!nCal
(*$Pp`pam {Event} dv%nt
8*$@Pa�am(E�ent0oz�Dous`} po�o��r
 * @private
 
/
p�oto,WpointerCenCm�= fu.cuionh eteft, poilTaz -!{` |ihs._pnintgrDnnE();* (this.rk{nterSmncfl(@]6eNt, 2oin|eR +;
;
�/ rublmc
Provo
�o�n�grK)�ccl =!fui�4ifn((Uvel|,"pO�o�e� )"{
 "tx)s.dmatDven$( 'pnintErCancel' [ dve/t,8poin4er ]a);
}3

o/ --m-- bm--,- //J
//`eti|itx lu.ctikf &or getuing x/y`coords)fro} �ve�|UniyOif\er.get�okndgrPoind =$fw~cTao�(�poiJve� )$z  rEturn {
    x2 pminte�&pageH�
    9: pohnter.paceY
9 };};
// �---- 0--�--�/
re�wrn U.�p�ij�er;

}!�;
/*!* * uniDragg�b0v2.3>0
 * Draggable `asa cl`Sw
 *(IAT8licenre%*�

/*+{hin4!browses: true enusdd< true,0}.Def>(Tzue,spra#4: true  /((fuNcTiOn( WindOw4 factory )�{
  // ufitersal mod4le du&ilap)ko� $/*jshin� 3tr)cp:0fagsa *-�'*globalq defing,lolule. r%qui�� :?�
 $ib ( pypeow emfije }= functmon'`&& de�Ile.amd ) {
`  "// !MDJ !  define8 #u.i$2ageerounidpegge:%,[
 !    'unmpoanter/eniPmi~ter'O ( �]< functIo.( Uni�kiNtor�a z(     2E�uZ~!fa�to0y( vi~dow, T/ipoiNve2 )
   (});
3 }�elsm if ( ryp�og mmdune`== 'ob*ecv7 && moDume.ex��r4s ) k !( +/ ColmknJC  (`}odqle.ezprvs = fictopy � "   wIndmw,J )    re�uir'h'uniPOintev')�4   9;K! } edse {b$ // rs�wser globalJ   (5indow.Unidj�wger`(&c#tory(
      wInfow,   "  s�n`owUnipoafter
   �);
 }
	]( wi~dO},`funcuin fa�t/zq( windmw, W_mP�nter ) {

J
o /�-=----,-=---=/-�-�--,- Unidr`'ger ,--m------m)---)�---m--% ./
Bf�oktIOl nidbagger(!({}

// if.ezit nkpo+nt%2$& �v��i�tep
far p�Mto - UNmracger.pr/dotspeh- ObjecT*creade( nipGanter.protg4ype0-;

�/ ,-m,- bind start ---�-�?�
*pr�tk.bi�d�a�d|es = funbtIon(	 i  thir.b�nd�a�T,Ep, true !;
�

0rot�.}obindHqndles!�l�unCtinn()({
�`this,_bm.dIafd�Ewh(filse );
};

/*(
 * �df oR(remove sTar� event
   pira�0[Roolua�} isa$D�*o
x3ovo.bi>dHandldS"} �e~cti/n( isQdd )"k
  /' m}nge`isatd4adefawlt to d"we�  irAdd 5 IsAed$==? wndef}ne% ? tzue : mcAdd;
� /o b)ld!eabh!ha/dlg  ~a3 bivedeu�od"}"isA$d ? 'add6%ntistEnmr' Z gREmoveE�gft�is4ene2';
  v!r dkushAstion ?is�dd ?!thi{._|ouchAc|j/n��lmab: #:
  for ((var i<0; i <athis<handh`s.leneth;!i# )�{" ! v�r hqndl� 9 th�snhcndlds[	
 $` thas._jinD4�rtEtu�4( handde< )sAdd0k;
 "0 �an$Le[(Bmnd_gtxmd$� 'c�igKo, thIs );
 !! // �ou�j-qktion none`do o�err�de bbOws%r touBh"ee�tupes. mltafkz�y/flickity"540 $` if( 5mndos.Ph)npu2�ve�p � �
0     haodlE.s�yle&touchUction =(dog�Cction;
(  $}
  y
};

+/`0rotk<y d so it can(`e Overwriteabmg by0Fl�fkity
p�/to,_tgubHAk�ionWalqe = nmva';
/ -,+l-$sta�t�av�nt ---) /'

/j* * @omot-R qtArt(* @pa�qm {Event} event
 � @p`ram${Uv'nt or U/Uch} p�an�er
 *n
pwoto.pointeRDmwn = functinvh e4e~t= poioter2)!{0"v�r isOkai = th)SoKayQ�in�erDonl �vEnt )�0 if ( !hsOkay )!s*   2ettpn3
"(}( )/ tRack {tirt(eve.T(posithon
` vhiw/pm)~d!PDnnR�Int-r -"pointa^;
  eveltprefentefa5ht();
  t(ir*pInterDmwNBlUr8);" ' bind �ov� aNd(end ev�nts
  |jiS.]bandpostCt!r0Evenfs(#event ); `uh)ce=itEvenp(`'roin�erowN', � dve.Tl �kmn|ub ] 	;
};
// nmdms*~hat!hite tdpt$fiulds~ar"cursNrNodus =t{  TEXTAREAx Tb|e.j  KNPUV: tru�,
d S�e�T:�4rpm,
`#OTTIN:"x2ue,
};

// hnput type�!ujat dm not2hav� t�xt fie-ds
~ar(sli#ktypes = {
, radin: dpqe-  #,egk�oy truWl� hbuptgn: t�ue,* `�ubmy4: �rue,
 (imag�: tvum,( filez$p2q%};
//0DiSmiSs"inpu4s with0tdxt1faeldc fliski|{!4,3, flickhw}#004
`soto.okaqPoinuerDown = funbtInj( evEnv`)0{� $�ar kc�r3orNode y!cursorNoder[ etunt*targev.nodena-�`U;
  vis(hslikkType � clicaT9p�s[ evgnt.target.txpe�];
  va2 irOkiy0$�ksCu2sornolE p| Ms�diccType;
  in�($ igOk!y )�{
    t(Is._pni~terPese�();J  |  retupj )sOkq};};
//��ludge(to jmur �rev�ously focused$ifput
Prnt�.pOinterDownBlev 5�7ncthn�h) _
 0var focu{ed%� document,acdivaEhekeot;
  // do�oot Blur j�tY fob(CE10< medafi�zy/flicjiTy#113
  ~!2hca~@ly� = docused�&&�f�c��ed#l�r &$ fobured != d�cum�nt.bo�Y�( `iF ( aanBlur ) {�$! �Ocu#ed.bnur(	;
  u�;

n/ ----- move Event0�--=- //

/.+ *0dryg mov%
)(�Bt`raM {Eveld} even$ * @taru� {Evejt`o2"Touchm p�il4eR�0*/qroto"p�ml4�rM/ve = functm/_( event, pointEr�) {
  ~a2!moveVecto�$= vHaS�_�ra'PolnterMo~e`evend, POiOd%r$);
  this&qmytve~a80#pomnterIova',$[ erent, xocnvmb m{vuVmspr0]");
" this_dragM/te( utalt, rointer, moreV%�tor 	;J};:/-(base pninp�r m.~e ,ogi#*proto�]dpagPointdsMova �gunc|inn( evenu, t/�ntqr()0s
("vermmvmVmctos = {
$  `x* pmINtep"pagEX = thAs.toyntesDownPointer.pagmZ(
 !  y:`pointEr.paedY0- th�s+poi/terDovnQoihter.qage"$ };
  /n!s|E"t$dr0g il Po�nter!has moved gep en�ug( to!stazt arae
 �hf 8 !t(is.i3Dragfinw && th}wohasLr!'q4�rtdd  okv�VecPor )$	 {
   thir*^e�agSpCr4) ev�j|n pohnter�!;� 1}
�0zetuvn -ow%V%�tor{*};
j// konEitmon md pOinves4h13 m/vad �Ar eNougi To stcrt fbagpPo$o.hasDRqgWt`2tel ? f�oc�ion(pmovgV�ctor ) {
  returj Math&ibS! �ov%[š`�r.x (0~ 3�|| M%th&�bs� movdFeC0Or.q ) >"3;w;��-/ --,,% �nt etent m---�//
-**
 * pointev0upJ(* @pAra-"{Eve&p} uv�np
 + @xaram {E�enu or"T�ucH](pointer
 (-protO.PminterU� - fu~ctiOn( �~�ft, �mi�ter (�{
  thic�emipVefv($'po�numrU`',$[ even�( pnI~der ] );
( thisOdpigPoiNt�vUq( evend� poIn|nr +;
};

0rot�.�dragRointebUt � f�N#t�on( %rEnt,�pOin$%sh) {J  if $ this*isE�e'oin� ) {
    THks._dragAnd( mve�tl"pointer )9*� } else 
a8  / qo�nter $adn&t$more$en/uwh�or$ds�'�do starp
   "vba{*_st`ti�CNick( aveNT� toint%r ){
  }
}�
�� %,-----�,-�--m)---------� erag!/-�-------e--m-,/-'---,-- /�
//$fr�g�tazv
psot+_dra�Star\ = fuNctmof  evmnt, pkinver"� ;
  thkw&usDbag�ing(= tru�?  // Pre~ent`cmickS
� thas.ksPre�glt�ngClicks ?(vr}u;
 (ulms.dragStart� et%nt,poIntar$	�
}+*pro4o.trCgBra2t = bt~athon� aent, x/)ntes`) {
!"thkr.amitDven4( 'dragStart'<([&mv%nt,"t/int�r ] (;
u;
J/+ %r`g]ovmppvo*_dr`nE�ve�=(fufktHon( evg�|,(pmi*4Er, move�ector )$;
  /+ dm not lva� i& not draggifg$yet
  if ((!ph)s>isDragking i"{
!   r�pusn;
  Y�
! this.dra'Mova( e6�nd, pilp�2<0moveectkr0){
};
 p6oto.dvqgove = Fu.btmoo<(eve�u,�roif4e2, lkveTuctor0) {J` �Fent.0re7e~tDEfault(-;
  tHys.umitEvent( 'drAmMtd'. _!e�%�V� point%r| mmveVecTor ] ,;
}3

// dragEnd
pvotg._dri'E.d = benctio~h!E�e.t, poIl�gr ) {
  // wet dlag{
$ t(iq.isLragging =`fkls�3
  // sa-eNable alac{a�g0es9nk
 $sedTkmeout� b}ncthon�) ;$"  `elet} thisnisPrveltiJgblibjs;
! }.bin`(0phis ) (+�  dhas.dpecE�d  erebT, Pinder );};

qrotondr`gLn� m�fwfcvIon(!event, poinv�r � {  |miw.EiytEvejt) g$ragGne', K event, pn�npgr0] �;
}+

?' ---/- ofclhck0-/-( '/

./ hcldiu%all(clicks ane$pravgnt cnic#? When $rcggi.g
protn.oNclick = funktign( eve�t ) �
  if ( �hic.)sQseveflingClicks ) k
   �evejt.preventDefault();
$`}};
-. %-m-- staticCnkCk -m-%- /
/- tri�gereD after pointev!�own & up�wmth0no/tioy(oov%een4
protn._st�tiwClyci � Functyo~(�event- bomnter(- [  // ignrd eyu,ata`@iOusu up cni+ks
  if ( this/ksIgm�rinoMouseU�$&& EvEnt.type`5= 'mOu�d}p' )"{
    zdturo;
 0}
 �THir.sUaticAlick+aevenp"P_intar );
  // Set flag do[ 5mt�atud clifos"30tms after dkuc(god
  yf ( etent.ty0e`!= 'MOuseqp' )(s
*`  4hic.isAgnringmouseUp = vbue;
  $// 2%Set fl`� aft!r 30ma    sgtTimeout( f}f#4ion() {
"     delgte dhir.isIe~Orinw]ouseQ4;.    }&"}nl( p�i{`), 400 +;
  }
�;

pr/po,sdIty�Cl�ck = fwn"vio.( evg~T- `�knuez ) {
  t�ic/EMiTAVent* 'staticlick�, [(eva�t,�p��n�ev ] 	;
;

/+ /---)0uth|s4--�-� //
Mni`{aggev.gEtQoindfrPoint"= Unipoknter.getPoILpe:Poynt;*(�/`-/?--" --)-- //

return Unifr!'edr�

|();

// `ra'
8 fuNcuion* wifdmw,�fa#tkrx ) {J! //�afive�cal"�gdule`feninItiOn
  /�(�shkft!ctrisp{ gslsa /
! if * typ%�f �efkna 9< 'fu~ction'0&& dgfInu.aod ) s
   "/(QM " !lefine(`��lIck�ty/js/d�ac'l[N!   ! .+flickiTy',
    " '=nkdr�fe�r.unilragger',
   (  'fhzz}�um-utiLs/utiLr'
 0 �Y,(n}fcTmon  Llikk�ty, Unhdsagger, u4i,s`)dw
      retern�fectkry
(GindoW, FlAciaty, UNidRagoez, uuilS );H  " });
  } else i& �$tp`don mgdulaa=} 'o`h%c67 && }getle.ehporTsd) {
    / CmmnJQ
    mod�le.exqorvs ?!f!ctkpy*
     "windou,
 !  $#requi2)./FlicjitY')
      beq5ir%i'un�drageer'i,   0  re1uire("fyzZy-wi�wtilsg)
    );
 "\ �|ce0{* 0  //�Frmwa�R"Elojad�  ��vindow.N}ickity = fd#tor9(
�    wind�wl
   $ `i~dOw,Flickhty,
A`  $�windo7.U&idra'fe2,�    $ wy.dm.fizryUYUtils�  � !;
  -
*}( winemv, fuvbt)k. facTmry( �)nDos, Fligkiq{,"Pfa$rafge�, utils ) {
J
// m--%- `Efaults -----�'

utils.ezpen$($FlIoKity.`e&auhpw, {
0 drq'garle: 7>1',
  dpagThzgsholl:b3,�u)3

./ )%--- creatm -�9-- /'
�FlacKiph.cr%�teMetholS>pu3h(/_cp�`tEDrae&);

/+`-%--/=----�/-------/------"drag�prototydm ---)---m-�--/-----/-----%- /n

va� trmto - Flic�iti.t�tntypE;�utils.eXtend( prO|o-`Unierawger.pr�topkpE0i;
rroto.Wto�chActaojRaeu',= 'q`f�{'9

// m-,-/---=-----=--}%---/--0 -=m/%--�-)-----m�-)-----)- /+

vir isDoTcx ="7CweAteTju#h'�hN Doce}mn|;
vAr I3Doucilo6eScrOlmCa�cele` = false;

proto._creitgFraG = fufctio.()${
! this.on( 7aa4mvate',(txi3.�nActlvateDrau );
  uh�s.on� 'uiCha�we', 4hks._uiCiajgeDrac")s
( tji{&onh1'deictmvat5',!this.ONDEabtkvatera#ai;  th	s.On( 'c�l�Chano5', $0is.}`dateDraog�bl�p(;*  /`TODO��p`apeDpaggable on busiz%: if gzoupCellc & �|a$es ch�neeJ0 ./ HACK  idd sd%minclx i~nocuus hAjdldr to`fix y�090$ccroln behavao2
   #657,RubaXa+Sor�cbme#97;)b af ( �3Tou�8 &&�!(rT�#hmgveSkbOllCacaled ) {
   �wind/w.atdEv�OtLmqtener( 'touc�move', fmnbpmofh	 {}	+
 `� i�TouCiMoveQczol,C�nculed = true;
 !}
};
proto./f�`diwapeD:ag"=df}nctinn(( {
0 this.xa�d�es0= [2t�ir.vme�pk�t ];
` �his/bildHajdl�s8);
 (Thkw(}p�atdDvaGg!bde(i;
;

prn|o/mnDe!ctmvate�r!g = fwlcqiod(! {
� thisn}n`indHa�dles();
 $ph)s.alement(Cl%ssList.rmmove('is-dpaggt�lu');
};
Proto.upfateDbaggAcme =�fenctc�f()@{
$(//1disab|e``ra'gong iF less than(2 slides. #&8
� mb`( tli{*�p4io�s�erqgvabbe!?= '>9/b) {
    thas.�wDbaggeble } wh�s*sdh�m3.��nfth > 0;J �} elke!{
"  "d�({.hsDra�ga"le0= |h)�.kp0io~s*fcawGa0l%;
  ]
  mf((0dhis.icDrafo`bLe$9${*(   t`kr.eleme�t.classLiut*atf'k{-drsg'abye/);
  }#mlre {   $thi3.elementnclassList.s%moveh'is-�zaggabl�')+
, ]
};

�/  aCKwArds co�p�dibil!tytpolo.bYndDRag } f}�ction(+ {
! �hiw.optionS.dr�ggablu < true)
� tHis�upd�0eDrqegqb�!();
};

prot/.unBindDrac = buns4ikn(i s
  x`9s.optIon{/draggable = bqn3e
`"This/updAteDragga�de�-;
};*
proto"_u`ChbNg�Dbag =0bun�tko~(* {
" ,elUve dhis.hsF2eeWgsolling;J};
J.# =--,-,�%=----m--)=---�--`pginter(efentw"------,)--$-)�-)--}	---- '/* 2oto�poin4%2Dowl 5 �ungp�o~� event,�po)n�e� ) �
( if (!qt(ys.isDRaggable - k
    plms._pointebDowlEefau�0( uV�lt, poikter (;
 $  rgtubl;
  yJ  var$�cOkqq = tjis.okaY�7intarDoun8 dwent (r
 !if ( !YsOkay  {    return;
  ]  t(i#._po�nte2downPreveftDefault* evglt );*` this.pointermwnFocus( gv%ot );
  //(b�52
� if 8 sument>agdIveE|e-ent !<0tlmc.ememdot 	 {    / do j_t`blqrkf�a,rEady focu�e�� 0�(t)is.pmmntmrDownBmur(-;
  �K
  -+ s~o0 id$�u was eoving !thm�*dragX0=!this,x+
 $TLhs.viewpos<.c,cssList.bdd	'i~-xoivper-dl7n')3
  // Tra3k {crndning
 th�S.0o�n�erDo�nSkrkLd = getRcrodlPositIon);Z! windog.cldEV%ndLiBv�ner( 'scrml�/, this +)
*� vhir._poyj|dr�ownDe&ault( mvalt, 0gynter ){
�;*/ defauh~ pOiftgzDown"loGk, used1fr �tapigCl)c�
�r�t�>~�o�nuerDvnDafault =�f~�ctiol( e�ent, poin4Er)( {  // traCk s4art"ese.� positkoo
 �+/ Scfari 8 ov`zrides 4agdX and(pcgeQ.0These wAluos�ndeds`toabe ckpied. #779 "tx)S.rnintdrDownPgint%r ="z
  ! yaeeP: pm�nterpaggX,*" 0'pagaY: pointew*peggY<
  u?  '/ rint move and g~d uve~tq�h thms.GbindPowtStartAvents8 e�%nt!);
00Thiq.vysrat#hUVent( '0oknterDowf7� evEnT,  pOinter�] ):
y;

var0focUsNo`es =0{J! ILTUT:�true,
  PEXTAREP:�}ruE$
� SELECF8 trqE(
}?

pro�m�poynterDnwoFocew)y fu�styo�(!ave|t )"{(  �ap isFocesNotE ?$fogeqnode�[(efmn4.|avget>.m`Eame \;
  kf h �isFocusNode 9 {R  0 t)is.f�cus8i;
" }}9

pSmto.�oilVmrDownP�evenuDe�auot< fqncvion((uwgn� ) {
( v�r isg}kjStqrt"<(e6dft.Type }} %`5khqTart';
 var cs@ouc"Poiotev =�evenp.pm|iRType =9 'toucl';
 ~az"isDoeu�NoD% <$focuQNoDeq[ ere/4.t`2cmp*noden!me ]?*  if ( �isTouchStart &' #i{toeehPmin|er�&& !csFofus�oda�) {J�   �Veft.rreventLe&aulT(8;
  |];Z
o/ ----- mowe ----- /

pb�t�.hasLza�Ptaj�ed 9 function( -kweVector ( ;
(�retur� Oith.kbs, emveVectoz,y ) > v�is/optkons.drEgvhr!shnld;
-;

o/ /--m%(5P ----=�./prot�.poi�derUp�= fqn#tign( ev�nt, piinper )�{
  del%t� uhis.)sPkuchCcvo�liN�J( t`i�.r)eupkzt.cLawsMiSt.remone('is-pOinTer-down%9
 "vh)s.d)sqatchEveNuh 'pOI~Tmv]p�<�ete~tl [ pOintdr`] )�
  this,_`zAgPo��terQr* evejt� pomlueR )
�
rroto.pinter�k�e = "unction() 3
` w��to7/v-m�veEVdn|Lisuener("'c�r�l.g. d)s ){
( $�l�te THis.p�i�t�rDnvScroll+
}+

 ------)==!,)�-,---%,-----) dragga.g --g-)%�-/-----�=----m--� /?

pRopo.dragWt�rv 5 nuncti�n� event, pOantgr i"{  if ( !T|i3/isTv�egebLe - { $�0bgtUrn9
  U�$ this.$raeSTePtPositi/n�= this*X;
  dh�a.r�artIn�Mathof();*  windrvemkvmE4untLicte,er 'scroll'$!Uhos`);
 uhHsd(sqa|chEtmnt� 'drcgS`azt, evant�*[`pminPur M );
}9
prto&toafpEvMOv% =(functionz Dgelv, poinver � {
` &a6 iovmVectos 5 ThhS._dracp/Kn0erEov% eVe~t,�poi�ter (;
$ 0his.dy�tatchMvef4( 'pm)lte�Movg, e�eft� [ pmiNta�,`moveVqctor  );
 �this.WdrugMmva)$event$"pcinper, moTeNus`oz );
};pr+to*drag�owe - fuNb�yon 0e6%nt, poin4mb,0moveVdctob ) {
 !id (  Lhis>msDragoable$- z
  ! zeuuqn;  }$ �vejt�prev$ntdev�qlt();J
0 uHis�rlviOusF2!gX = vhir.dragX)  //`rmvers- yf vaw`$-tO)l�Gt
  var direktaOn } thl{.opt}�nsnr)ghtTo@env"? -1 : 19" `l ($txi3.o0tinc.w�!pAroUod ) {*   !./ frap aro�~d �ove>&#%89
$   movuVe#uor*� = ooVeVectr.x % thIs.sfide�bh!WaDXh;
  }
  v`r fregX !th)sn�bigStqrtPo{itio� +`�wuveCtor.x * firektin+

 $if ( !t`i{,options.wrapar5le $& this.�m�fus.l�netj� �   (// sdov d�ag
 0  var orifi.Boun%� M`t�.max(`)ThI{.ql�d%s�8].vireet t�is.`r�'StAr|Pos�tion$)�
   ``zacX 9 d2agX0> grjgi�Bujl"? ( d2agX + originBound ) * 0.5 : dragX;
    var endBound = Math.min( -this.getLastSlide().target, this.dragStartPosition );
    dragX = dragX < endBound ? ( dragX + endBound ) * 0.5 : dragX;
  }

  this.dragX = dragX;

  this.dragMoveTime = new Date();
  this.dispatchEvent( 'dragMove', event, [ pointer, moveVector ] );
};

proto.dragEnd = function( event, pointer ) {
  if ( !this.isDraggable ) {
    return;
  }
  if ( this.options.freeScroll ) {
    this.isFreeScrolling = true;
  }
  // set selectedIndex based on where flick will end up
  var index = this.dragEndRestingSelect();

  if ( this.options.freeScroll && !this.options.wrapAround ) {
    // if free-scroll & not wrap around
    // do not free-scroll if going outside of bounding slides
    // so bounding slides can attract slider, and keep it in bounds
    var restingX = this.getRestingPosition();
    this.isFreeScrolling = -restingX > this.slides[0].target &&
      -restingX < this.getLastSlide().target;
  } else if ( !this.options.freeScroll && index == this.selectedIndex ) {
    // boost selection if selected index has not changed
    index += this.dragEndBoostSelect();
  }
  delete this.previousDragX;
  // apply selection
  // TODO refactor this, selecting here feels weird
  // HACK, set flag so dragging stays in correct direction
  this.isDragSelect = this.options.wrapAround;
  this.select( index );
  delete this.isDragSelect;
  this.dispatchEvent( 'dragEnd', event, [ pointer ] );
};

proto.dragEndRestingSelect = function() {
  var restingX = this.getRestingPosition();
  // how far away from selected slide
  var distance = Math.abs( this.getSlideDistance( -restingX, this.selectedIndex ) );
  // get closet resting going up and going down
  var positiveResting = this._getClosestResting( restingX, distance, 1 );
  var negativeResting = this._getClosestResting( restingX, distance, -1 );
  // use closer resting for wrap-around
  var index = positiveResting.distance < negativeResting.distance ?
    positiveResting.index : negativeResting.index;
  return index;
};

/**
 * given*resting  a~` di�tanae(to se,�ctgd cell
 � ged`tle dcs|ancn�and kn`�� of6tie closest cdml
,* Fparal�yN5mber} zestmjwH , %}timapad post-fhygk!re�|iow PosItko~J * Aparam {L5mber} diStqnce(- distan�% to se,ecved!`eml* * `qaryl"{�nteeer} inc2emen4 - +50or -1, Ging up or tgwn
** `rEturns O&ject} - { d�stajcm: {Fcmber�, indmx: {In4egdr} }
 j/
prOtgn_getClo3usuVgstync <@fulftimn, rewtingi, d)s4ancm, incremunt 	 {
 $vab$inbmx = dhis.sEle�tedIndux;
 �ar!moniqfaNce ="Infenity�
  vav condytion ? v)is.options.�oNtqin && !thgs.opTionsigrapAsound ?
    /�if cott��n,!ke%r goiog 	f distance`is equ`l!�o minDistance$   funktioN( d mD +!{ retu�n d <="id; �(: junc4ioj( b, m� ) s reuurn"d | mt; }{  vxiDe (�conditio,(�disvance, minDis~ance�) )`{    /' measure d�stance to next sell
#   indeh += insremen|;!   minListanc�`= dksdance;
   �dist`nce =(this$ge�SlieeLiStc�Ce�"-pistyngX, induX 9;
    if ( dhstanC% ===0nul� ! {�"  �( break;
    y   $dirtan�e , Mathjabs( fistance )
!!}�  rF|urn �
    dmstajc�>minDistance,  `*/- sel%cted Wis!previo�s iNdex
    mn�ex: index l klcrmment
  u;
};

.**
(*(measure(eistance betveEn z aff c$sli�e TAzget`* Qpa�am {Nwmberu x+ * @peram kIn�egEr} indeX - slkde indmx� */
proto.getSlideDIqtance$? f5nctin(!x, indey ) {
  Fa2 hen = this.snides.�enouH;
  , wrix avound if et leaat 2"slides
  var isW�aAround = this.op�iojs>w2apArOund &f ldn > 1;
  var 3lmd%I�dez !�isWrapArnujd > utils.modulo( index."le� ( :`ij�ex+
0 tc2 slide = t�as&sdiddc["slad Ildex ;
 $)f ) !slide  ;
   ,reuu�n n�dl;
  m
  // a�d!distanae fgr wrar-arl5nd sl)des
0 var wr`t  icWr�pArkund ? thi.sl�leabluWi$qh * Miuh.fl/or(inde2`/!len ) :(p:*  rEtus� x - (!slideltaveet / w2aq ))};
psoto*drAgEndBo�sdSelect!= fQn#tiol(i �
  -/ do lou booSt if no pxeviouSDpa�| op `rEgMOveTime
  if (��ii{.previousDragX �=5`7ldefined �\ !this/DRagMlveTime <<
  ` // gb if �Rag�was held foz 10p ms
   "new Fatm() ��tHis.d�agMoweUime > 10� + {J    retuvl 0
" }

  �ar `istancm = �lis*geTqLidmDIstance( -this.drag,�phisnsdlec<edIndgx`)+  rar!delta = this.pRevi�sDragZ - this.drafX3
  if ( eistanCe > 0 .'�delta >0 )"y   (/' boost t� next af iovino!tOwa2&s th ryg,u, anD 0ositive velck|y
   0returf !;
  | glse if , $Is|ance 8`0 &� d%Lta > 0$� { `  // coowu"tn"pr%vious if!moving towards phe left, Ajd jecative velocaty
"   retuso -1;
0 =
 "retuvn$0;
};

// -=--!tat(cClhck --%-`//

�roto.staticSlicm�= fwncthon( evEnt. pg�n�erh) {
"!/-`wst glic�edCE�|,"mf`bedl as al�ck�d
 �var"c-�ckgdCgLl = t(ks.gutP��el�Cedl eVent.tarwet i;  vay ce,mElee =`cl�c+edCel,`f!blickelC�ll*gLfmen�;
� vaP"#e|lInd%� = s|icglKelm 'v(th�s.kellS&yntexOf(Clickedkel�0);� thic.disat"hGvent( 's|aticClick'- evenT, [`qoi�terl(cellUlemn!callIndex  i9
};
 =-	-- qkroll�m--n- /+

protm�onscroll = �unc~hon() {  var Scbn�l = gepSgrmllUosition();
 var qcrolmMove< = 4his�Poi�terDoVnrcbol,.| - scsmll.x;  6ar sA2oll]ov�Y$� vois,poyntusDowNScrohl,y -p#cRoll.y�"`/?!cancEl(clhccta� ib #crolh(i{`too -uch
 !if ( Matl.acs0s#ronlM�veX ) > 3 || Mcvh.abs( scponlMoveU 	 >�3 )!{J    thiw.�to)nterDnnu();
  }
};*/+ -----(utiLs0--�-- //

func5yon gEtQcrllPosi|ion() {
 (re<urn {*    z~!w�odow>pageXoffwet.
 !(y:`w�Ntmu.P�ge]KFfset
0 };
u

// ----- (�----(//J
~e4urn Glicki4y;

}))3
*o+ trev/next `tvtons
( fuNction� 7indow, da�tory ) [
  //&u�i�dRsaL module deinItxon
  /*�zrhint strict: fal3e */
  i� ( tzpeog($uFIne ==07functiOn/�&& fenIne.amd + {
  0 //(AMF
 $  `ofine( 'flack�vY.js/preV-mext-b�dton',[
1  0 ('./fnyckat�'
 a   ('u.iyointEr/unipkioderf,
  "   'fixzy=}i-5tils�ut�l3'
!   ] vu.�tion( FlickitY, UnipoifTer,(u|i,{h) [
"   $ return factory( window,(Flickkty,2Unip/hntdr, ut�Lc�i9
  0 }+?  } elseaif ( t}pmof module ==�&bject' &� l/de�,exporu{ ) {
    // CoimonJS
  � }odule.export3! factory(
  ! � Window�
$    $resumre(�./fnIckity'),
  `   requipe('unhpkinuer'+,
      Qequhpe('fizzy=ui)utils')B 0 ();  ] E|we {
`   ?/ brwrev glojal
   $F�ctory(*     !Window,
  0�  �yndownFlicka|y,
  `  !winf�g*Uni`k�nter,
  ! �0uiJdow.fIjj UIUtils�   �8;�  y
}( winfowL �unction facUor9(�qintow, Fdickity, �Nirni^t�r, upils(	 {J'use striaU#;
6ar$svgUrI = 'jttp://www.w3.or'/r000/{v''{/ --m--/--------m--=------- PRevN�xu@uetkn ------%------------�--%.-- //
funcuion PrefNexdButtkn(�dIrec|y/n, pargnt )!{
 $vmiw.dyrecti�n = direcui/n+
  tiis&par�nt = pab'nt;
  this>cre`te();
}
PrevNe}pBupton.prototyp� = Object.create" Unypei�ter.protkt�pe );*
PrmRNextButton.`sototype&]c�eapd } f}ngTinnh) x
 "// propert)�s
  this.i[Efab�et = trte;
  �his�isPrafiou3 = uhiS.divec|�on == �1;
 "ver lDf|D�rectign = Txms�`ereju.ptmons&rish�t~Left /"1!;`-1?
  this.i�Negt!=�tjiw.direction == leb4D)rectio~;

h �!r e,mment m thms.�leeenu�= doCu-en|.creatEGle-en�('btttof%);*  elemenTNcmas{Na-e`= 'fn�bkivy-bUtton flkckmt9-pref-nmxpbutxo�;
 $element*claS�Nime /� tlis.ispe6igus ~ �(prewIomw' :(' �Ext';
 (// pvevent buvpon1from 3ubmitTinG dorm,http://stackgverglmw�s/m/1/10836076m182�83
  engmunt.set�ttpi&uue  'vytd', 'ruu�on' );
( /+ ioit as diqAcled  vhiwndisqbde();

  element.saTAttryBUte($'aria-Label'= 0hir.�sPrmvIouq ?�'previouq'0: 'N}xt'")�
(`+/ create arrow
! var svg } this.createCVG();8 elmment,appan`Climd( �vg );
  -�"Events
  4his>parent.n( 'S�lekt., thas&updete.bh.d)`�lis )0i;�  8iiS.�n($'pohNuerow�', tl�s.�azejt.che|`UIPnijterDkun.bind(`thir.paqen�!90+;
}9

Pbe~eptBUTton.propovy�a.activate =(functyo.(9 {$ tlis'baldStartDvent  thy{.element )+
  thac/e|ement.addE~`ntLi{te.ep( gìmck#, this )�
( //2edd t/ DMM
  this.pavent.ele�ent.ap�AndBhild( thic.eme�ef4 8;
};
PrevNextButtmn�prototYp%.`eactivate =�funktion() {
  // remove`fr/m`DOM
  th)s.pareot.u|eient.reloveChi|l( thiQ.enfm�jt -3
  /O #lick,eveN�c
 0�his.uobindGtaf�Eren( this.elemend );�*uXhs.elem9ft.bu}ovmEvunt\isveneR 'c�ici?, thks );
y;
RrevNextBup|on.protovyPa.creadeSVG$= funcdion() {
((6ar {rg 5!dOcemen4<cr`at%�lemen4N[h svgZA,�7Svg');
  qvg.setAttribute($'class', 'flic{i4{,butvo~�ico~' );� `�to.sdtattrifute- '�iewBox', '0 0 100 100' );  vac0qath = locument*cv%q6eelement�(0rvgUB�, #path');
  rar xathMove�gnts = �etAbrowMOtemants  tL)s.pareot.Gp|�ons.a�rGwShape );  `Ath.setA|tribu0e9 'f', p`uhMotEients )+
  pa�j.SetAttri"ute  'alass', 'arrow' (# !// rktape$arrk
 !if ( �this.�sNeet )0{
    pa<h>sdtAtt�ibttd( &tbansfope'. 'tvaf�late*001� 00� rotate(50)`' );
! }
 bsv'.appendChild( p`vh );  return s�g;
�;
*o/ geu SVG xath`MOVieo%nt
bunbtioN getArrowMov%ments( shap�$) [
 0// ese siape as move}ent If stbiNG�( af � ty�Eof shape!8= 'suriog ) {
 0  return"sxape
 "} ,-/ cre`Td move�uNt stry~g
 �return 'M`' # shap%.x ` 'l58' ) 0  ' M`' + shape.X1 + ','!+   sha`e.y1 + 50 ) :
  ! ' L ' + sh�0e.x2 +0'$g k ` {x`�en}6$+`50`) +
   �' L 7 + sh`te&X3(+ ',50('0#
 "  g L�. c s(ape*x2 k '.'0) ( 50 % �hapd.y2 - +    ' $�$) s(ap%.x1 + /d' * (!50 - shaqc.y1 ) +
  �0' Z';
}

Pr%vNext�utdof.pRotoTyxd.handdaEvent`= uVil{.handdeEvent2
�PrevNeXpBwtt/n.psototypG.onc|hck = guNCt)on()1K
  if ( !this.isEnabled ) �
  ( 2e|urn;
  }
 (this.�arejt.u�Change();
  var method $t(`s.isPrevioqs ?p'`rgvious' : 'Ne�t';  thi3.xargnx["�ethod ]);
};*/'(	---%  ---- //

PrevNextBptton.prototy`e.efab�e - functkon�) {
 8if`)!this.isEOabd�d i�{
   "rEturn{$"}
  Thas/edement.�isaf|ud�= fal{e;
  this/isEnabled = True;
};
PrevOeZ|Button.psototypg.dyseble ? fUnbtim/(9({
  if ( !this&isEn!bled 9 {
    Redern;
  |
  this.e|ement.eisibled = p�ua�
  thic.iSEnabled!=`fanse;
}�revNeXtBupton.qbototype,u�da|e 54nu�Ction() {0 // mndez /b �irst or lqrv sljfe, if preVious or nixt
  6ar0slides = tlis.parent.clies;
  // enable is wrapIrounD!and ad le`sT 2 sidew
  if ( This.paRent*option3.srapAvgu*d0&&0s�idE{.le�oth > 10) {
    th�s.eNa`le();
 0( retupn;4 }
  var lastHnde� = slidus.length ? sladez.nenetx / 1 : 0;
 (v!r BoundIndD8)= thiu.irPreVio}s ?0 : lastIldex;
  var mevhod = this.paRent.s%,ectefIndmx == bgundIn`ex ? 'd)Sable'$: 'enable';*!th)s[ ieth.d!]()3m;J
PrevNextBUtton.Ppototyp%.Des4ry = fuoc�ion()�{*  this.dea�ti�ate();
  thhs.�llOff();
};

/-!----/------%-------%-m--m GlickiTy protkdype -)---/+------------)---m--`//

uDi|W.extefd( Fmickity.defaum�s, {
  pvmvNex|BWttons: uzuf*  arrogShape> {    x : 10,
!   x�: 60, Y32 50,
    |0: 7 . y2: 40,
  � `3> 34
"$m}9;

Flick)t�.crE!ueMthodsnpu{(('_csea|eP�%6Nex|Buttons');
|ar `rotn - Flickitynpr�t�Type;

proto.sreatePrevOexTBttton� = f5nctmon() {	  iv , �thms*op|infs.prevNextButtonw ) {"   revurn;
` }
J  this.0revB5tton = new PrevNextBu4ton, )1,�t(is0)?  thhs.&eptB%ttof = neg!P�evexdBqtton 3, this );

  this.o�) �astivate', this.qc4ifateQrevN�xt�wttgns�({
};

p�oto.qctivafePrevN%xtButtgns�?�functmon() {
  This.prdwBu|ton.cct�vate();
  thisnnextBuvtonacthvate(!;  thms.gn( 'deactir!tg', th�s.lmact�vi4ePrEvN�xtB4ttojw ({
}�

proto.deqctivatePrevnextBettnos�= cufctagn() }
  tlis.prevC}tton.Dea�ti~Atg	;*  th{s..dx�But|gn.deactivi�e(){J  t)isofd( 'deactiv!te', |his.$eactivateP2evNe�dButtmns )#
};

/� =---------------)--------  --�=--�---------------�/ /*Flickipy.PrevNey�BuTton - X7gvOexTBqtton3

peturn Flicoit�;JJ}	);

+/ page dots
( fenctio� win�Mw, f�ctov9 � k
  o/ universa� module�dadiNition*  * jsiin� stsict: false */
  If(( Typ�nfrdefinu0==$'funoeioj' && Tefine.amd() k
��` //$AM
  $(deline  'flicki|�/js/page-dts',�
  � " '&/fnickit8',
     !'5ni0Omn}er/unipomnte��,      'fizzq-ui%Utils�}tils7
 0 !], fuNction(,Flicki\y,`Enipokot%v< upimr 9 s      re|�Rj!fectory( wanDow,$GLmc�i4u, Unipointes, utils );*!   })�
`"} e|s% if ( tyqeof lOd}la == 'objgct' && molule&�xports 	 {
    //"bomoooJ[
  " mOdule.expopts = &actor�h
     2iz$oW,
     `raqui�%('./fhickity'),
@     requhrd('unip�ynper'+, 4  � requi~eh'fijzy-}i-utils')�    )?
  u"dse {
0 ! // browser ol/ban
    g!Ctoryh
     !window�
 $0   �indow.Blmckity<  ("0 wIndow.Unipo)n|mr,    ( window6izzyEIUt�|q
   0);
  u

�( wIndow, fenctIen fcctkry( wi|dow flaski4y, Q�Ipmi~�eb,$uTIms 	 {

/> /--m-%)m-)----=-------/�-- pagEots -----------,,l------)--=-- //

�function PageDots� `argn.`) ;  this>pavmnt = parunt;
  this._creat�()�
]
Paeeotw.protk}ype = Obje#t.�reAte(�unipnin�er.pbntotyp� );

Pag%dov{.prototyqe._crEcpe"5$fu.stioj() {
  //"creave$jlder eleoe�t
  tihs.�oller =0$ocumeot.creiteElgment*'Ol');  this.holdur.className = 7fdhckit�-paw�-dgts':  ./ create dots, array �f!ene-eft�
  dhis.,ots ? ]  ?/ eVeNts
  this.haodDeCnick = ti)snofSdicc>jin$( thh3 ;
�(tis./n( 'PointeDown'$ this.paRenv.kaildUYpointgrLow�/bind( txis.parent ) );}?

PageDou�.pRototypg.akTivi4e =�fUncvion(+ {
  this.sedDots);
  this.i�ld�r.addGven|Listenep( 'click#, �hiw.h�
dmeCLick );
  |pis.`indStartEveNt( thas.`oLdgr );
  // add �o DM* �4h)q/pa6Ent.element&appendGhi�d( This.homf%r );
};
PageDops.pr{tntype.deac|ivaTe =$vunctio�() y
  thIs.(kller.re�mveEv%ntlhst�n�r( 'clkc{', tjis.handlgClmbk )9
  this.unbinlSTartEvent( dhis.holder );� "// remowe fsol DOM
! vhaw.xar%nv.eLe�elt.re-ovuChil$( uhis.holdep );}?

pageDous.prnpotyqe.sutDmTs�=dfunction�)0{  /o E| differefce between n�mceb kf!slides0aJ` num�er of dotw
  VAr0nmlua =�thi�.`areltnslides.le,g|``� txis.dots.length;
  if*( dmlta ~ 0 ) {
    \hAs.cddDots( f�lt�!); !} el{� if *`fElwa$<(0 ) {
    this&vemoveTots( -eelta -;
 "}}+

Pa'%Dots/protopype/ad`Tots =$ve�ction(@c�ujT 9 {0 var &vagMent =0�Icument.createDCumentDpawm%�t();
0 vab newDots - []~
 avar$lefg|h"= thIs~do�s.|eng4h;
  vavbi!x(= length +�botnp;
*  f/r ( var!i = nangt�;@i < max+ i++ ) {* 0  v`r dot m `kcument.cb�ateElement)'lI'); !  d/t.Cda{sObme(= 'doT'�   `dot�setAttrcute( 7ari!-labol', 'P`ge hot '�+(- i +1 � );
 "  fbaemE^t.qqpendChi|d( dot +;
`   nE�Dops.pu3((`dot );
  }
( this.h}lder&appgndChiLd( fragment );
  t8is.dots =`thi�.dopS.konswt, lewDots ):
m;
Page�otcnp�Otopype.pemov�Tots � functiOn($c~ujt() {
0b/. zeiovM from thhs.dots collectin.
  w�b remoVeDots$= phis>dotsnsPli�g(!txiw.dwds.le�gth"-�cOunt, soqft();  // remoe from F�M
  removaDous.norEa�h( function( `ot ! {
    thhc.hold�r.rgMoveChild, �ot );( }, dhis );
�;

PageDops.PpotoTypg.updAteSElucted = functi�n() {
  // rd}ove seleCted Glass o. `ruvious
 �a ( |his.wmdmbte$Dot ) {
 !  this.cmlEcuedDkt.clascName  �dot#;
  0 this.selebtgdD/t.reioveAutribete('aria-currend');
 }
` // lgn/t(urocged if no dots*  �& (,!this.dgvc.lGngth ) {
2   �eturn;
 (�J  thiw.3�lg�tedDot = this,dots[ thyq.pa2ent.selectelIn|ex ];
  thisselmctedDot.+MassNeme =$dot As<seleb�ed#;
 @this.selec4edDkt.sa�Attribupf, %q�ia-cuRren�.l 'stup' )
}{PA'eDo�s.0rotOtype.ohT`x = //�ole`}gt�ol jeme, babkWArds%compatiblm�agEDots.psotnty$u/ofCLic+ 9 fqnction($e~ent ( {
  var target < mvgnv.target�
  // O~|Y�carg abouT dot cdicjs*" if ("terwe<.nodeName != 'Y' ) {    ra�ur�;
  }

 `tlis.pasgot.eiChanoe();
  var in$ex= this,doT{*(ndmxOv( tar'u| )
 0t�is.parenu.select(�index 3
}

PageFotw.protodipe.fesproqd= functiOn8) {
  thas.deacTivate(-;
 `this.allOfn();
u;
Fdmckity>PageDo|3 = PagmDotq{

// )--)----�----%----------- FLygkity //----------)-)--,-m----� //

uthls.dytenf( Dlhckity.defaults,0{
  tqweD�tS: true});

Flickity.cr�ateMuthodsnpushh._`reetePa�eDots'){
Jvar 0zoto = Flicji$y.protoType;

qr�tg._cznauEPageD/ts = fujctI�n() {
 $if!( !thisnnptyonS.xageDots ) s
�  return�
  h� (thir.pigedotS = neW PigeDot�( This );  // utenps  tjiR.on( 'actIvate', thi�.a�tirat�PageDo�s�);
 !thison( 'rel5kt'$ tHks.updcdE_ulected@age ots );
  fhis.kn( 7c%llCh`nFe',�}�)s.xdevePav�D�ts();
� thiw.on( 'rdsiz!', |hisnepdate@ageDot� );
" this.on( gD%a�t�va�e', this.de!sTit�tePageDots`);
};

prnt/.activ!teageDots = functiOn()�{
  t�i7.SageD�tq.ak4ivkte();
=;
XrtoNuqdae�elec$edPageDots ="function8) {
  this.xaGeTots.�pdateSelmcued�+
}

proto.updatuXAge�ots(= fu.ct�on(( {
  thks.pa�eDots.{et�otw()
}�
�prmto.de`CvivatePag�D~ps = funa6ion() �
  t|ks.pqgeDots/dmast)va�e();
}{

// -----  --=-- //J
Fli#iidy.PaguDots =`@ageDots;*
rett:n Flickk|y;
]	);

// 0layer 6 au|oQlay( fq~�tion( ui|fow, taktnsy )%{
  //�Uni6ezsal }odu�e def�nit�on  /j`jshint s�rict:$f!ls� */K  )f ("vytm�f `efine = 'ftncxik.'(f& define.aod ) {
 "  // AMD
"   tefine(�'fdiscity?hs/`�a|er7,{
  #�  'e~-e��tder/av-�=itv%r'      'fizzy-ui�utilS/ut)ls7,Z  " " './flickipx'
 ( `],!fu~ction( EvEmI4teR, ut�ls, Flkbcit� ) {      return faet/ry	0�vEMitter� utils, Flickit� );
    y)9
  } eLsm ef ( typeod module =9�'objegt'"&& modul%.e<pOrts0)0{
`  (// CommolBS
 !  iodul%*e�port3 = nactory8
� �   r}quire('ev-coitter'),
0   $�req}hre(gFizzy-ui,util3').
 `$   reyuir%�'�/�hick)t{'
  $ i;� $} Else {�   $/+$b2gwser glmhal
   (6astoPy(      6aflgw.UvEm�|teR-�� $   gin$ow.fiz:yU�Utils,
  `0  windmw*Flickit9
    );
  =�
*hwiN�k]n gu~at)on facpo{{( EfU-htte2( Ut-Ls, fli�ji�i ) {

?/0---=--------�%-,/'-------< PhayEr --%----%-5---m%--,-=%--%%- //"benCtion la{er( pcr�zt )�{
$ rhir.0arent = pasenp;* (|h!3.vd�te =('spopped/;  /? viqibil)t9 chc��� event lanp|er( this�nViskbilK�yBha�gM =!tzis.visyrim)tyChejOf.Fiod �This();
  tiis�onVirkbym�tyTlqy = vh)s*visij-li4y�laY.b	~d0thi{ );
|

R�aygr+prototyqd(= Ofjert.creite) E6Emittez.pr+t/t9`e );

// st�r� pla�Playgr.p�ototyp�.xeq =`f5jcui?n() y�  ad ( ThissUaTe = 'playinG'`) c
  ! return;
  }
  ; dm NGt$0�ay if p!gE0is hmd@ej, {tar|$4layyjg sxe�0q�eE ys$viSibd�  �a2 isaguh�dden �1dMc�idnt.hidden; !if ( ysPqguHioden )�{0 a Document.aldVeNvDistmner  #visajilitycha�geg, this.oL^IsmbhLmtyPlay );
 !  return;J"�}
 0t`ir.statE�= 'plaYing'+`$// mi2tej to vis)b)lit}�cha�E  Tocume,dadd�ven4Misteleb  &isiBilitycj�hce', this.�nVicibilityC``noD()
  /g0sxart tickanW
d(thistIck*	
=;

layer.prototype.TAck = f}ncteonl+�{
  // eo n/4 ticK i� not playin�
  ig ( thyS.stave 5 'dvqying& ) {    rdturn;`$}

  var �il% = t�I�.pareot.optIojsautoPlay;
  /� dedqu|t$tm(3 secofds�  diee= thpegf timM ==$'nembuv' 7 tim` ; 3�0 ;
  6ar(_|ha{ ?,thiw;
 !/ HAC[: ReSet ticks if"stkppef`cnd stazted widhyn�invervaL  |h)s.c|ear	9;
  this.tiMEoUt = setTAme�Wt `fu.adhgn()e{
    _t`ywpasent>nept(@true );
� � _tii�*4ick()+
  =, time 	;
=;
Playes>prOtotyte.stop = buoceiol()${  4h�S.3tatu0< 'stopxed';*  thks.sle�z(i+
  // rmmovm$visibiliti`bh!~fe"e�e�t
  document.�emm6mMveltListeler( 'visibilidybhioge'( this/misibimHtyChlnwu -;
};

PL`yer&qrototype*clear } f�n�pIon	i {
  clearTimemut( this.timEoqt )3J}:

Xjpye@np�ntoty`dfpaus% = funkuion() �
(!if ( vhiw.state&= 'hma�iNg7 ) { 0  thms.state - &Paurgd';�$08 thi3&clearh);
  }
};Z
Tdayer.prototype.unreuwm = ftnctiol(9 ;
� / 2e=Stazt play iF pAused
  if ( �hks�st`ta ==0&pa}s�dg )$y
 "! thisnpl!y);
  }
];*
o� p�se0if �af%�vickbkh�ty is hjfd%N- unpaure id fisirL%
P�ayer.prototype.vis�bIlitiChpNFe&=$.uncTion) k
 0var isXqg%Hidtan � Doe5Ment.hhdgen;
 this� i�Pag%Hie$%n$?�'pause� : '�npauwe'(]();};
PlayEp.p2ot~pyPe.vhs�bin�TyPlay = fuctiON ) *  this.2l!y�!;
  eocume~p>Re�+vevuntLartejur( /viwibilitycia�ge'."th�s.onVisibilityPlai (
u;
-/`---�/-m---/------�/----/)"Flickity =/-----=--�-,=,-------o,--�//*
utids>ex�Ef`*!FLibkyty.feFcu)ts, {
  pa}seEuto@da}fHvEr: tzue
}i;
F�ickity*cremTeEvhods.puch('[creqtePLayer');
vav pbndo =bDl)ckityrrotkt9pu1
#xRoto._cteatePlay�r "�Unc|�oN � kJ  ejIs.pd�ymr =�ngc Plqyer< lhis );

 `thi�*{N  acthr`t%'$ thiseativatePlc�er );
` dhas.On� &uiChange% );
  this&on 'q�interDown'");
 #p�)woN( 'deacpivate', txI�*d�act�vateRmayer +;y;J*prOt/acviv�tuT�ayer%1 &Unation(+`[
 $ib"( #this.opvionsautola8 ) { 0 !retqr~;
0"}
  thkc.qli}Er.pl!y();
!|hiw.m�ement*ad`Evan0Listgner(!glousGent�r' T�IS 	;�}�

�/!Player"�RI,!�OO't hate�phe .n. �(anks I JNow siEre the loor iS

�v/to/�hay,ayer0< fu�ction(� {
p thir.pliqer>p,ay);
}+

proto�stmpTlaymr = f�ns|)oN ) {
  thiS�pl#}gr.3top8);
  �
  
]�
provonp!usgPlayEf*= functio.(!({
  this,tdayer.paus�);
};

rroto.unP�UseYlaYdr0= funb4ion(+   thIs.�dAYer*unreuse )+
}:
proto.d�a#div!teP�aY-r % functq'l() ;
 `Thy�.plqyer.stop();
  tlis.elemend&r%moreE6en4Lastalav-�'m�useendez'$"tH`s 9:*};

?�!=--- mouseenter/leAve-om-% //

/'(x%uSG auto)pla�`on xwver
qrotg.olmoUsemnter"= fujction�)!{
  id h )dhis.ort)kns.pauseAUtOP�axOn@oreb )!
    veturn;
  m�`
  this>uLement.addEvuOLmst}ngr( 'ius�leave' |�is );
}:-> bEs5me aePo)Pli} oN0xover odv
proto.kleourelesze = function)) {�  vhis.plaxur�unpi5{d);
  �his.�.ement.rumoweEfantistenec(!'mouqeleavE', this -3�};?/ -----  -9--- (�

FnickmtY&PlA9er � Plqyur;
return!Fmi�citY�
}�)

//`atl, rgmo�e �El|
0dunCvij( ikdow, fac4or8 ) {
  �/ unk6ers�l m�dud� d%finip!o�
``;* jshinp!stricd� �alse**/
  mf h dyPeo�Dedine == 'fufcvyoo &v ��fine>A-d i z
!"0 / QMT
    define( 'flickatyj�/�dd-bgmovgo"��l�$[
" $   //flickity',
   )  fi~zy-ui-}tils/u4`ls#a   ], fen#tkon� Clickity,"utils,) {
`     r�4urj gactoz�) windos, FlaCkity, uTils );� �� m)�
 t0alse if ( �80eo&�mofe|e == 'cja#t && eodume*expo�ts - {
    =; Cmmmk.JS
 `  mo4u|e.eXxorts = factorY(*   `  windo6,
(!   2eQeir�#./fnicKity'i<
b" ! `rlquir'('fizz�-ui-utaLs'	$  ()3
`$}$glse!{
   0// frmwser wlobcL
�   factor9` ( 0 wyndow,
8$ "  window*FlicKit�,*H     wiodow.fi�zyEIU|ilu   �*;
  }
=8 wIndow,"fun!tmon factgzy( wyndo7, ��ick)ty, ut-|s )${


o-$!Ppdnl cEdl{ to"a e�aqeent f{acimnt*f�ogtion(geBellsDragment( cdm|s )!{  vaj frcge`nu  �{buu�nt�cr%ate�lcume.��pagmenp);J  a5lls~f/rEac�( funoPio�( call )0y
    frqgment.!pxendChimh($cm`l.el�menu (+
  }(;
$ retub| frig}�,f;
}

//�=-------/m----=-------=- adf/remov% cenl pr�totype ---m---�-%/---,--/--%-5 '+

vaz xroto =!FlIckity.`z�|}type;

/** * Ifsert, rrepun`,�or `TPendha�lls
 * @pa2am 3Edemant, Arrkyl%NndeList} ememsH *0@p��ai {Intdoer} i~de(
 *qrotm.hnrep� �,>wn#tann  ele-�,�if�gz )�;
 (6ar gemls = this._makeAelL7( ale�r )#
 !if$( !celhs \l !c!llq>lengwh() s
  � ret}rn;
  }
)var len = 4hkc.c%ll3.henwt(;
  �� $eFau�t0tk apPelv  iNddx = ynd'x =<9 uN�efi�e� len : intex*  // a�d cellc04{th"docuieftfra%oenu$ var fxagienT =`cgtGedlsFragment(0c%lN{$);J$ // appund to0sDHd%r  vdrbisCpxaNd 4 index"=}(len;
  mf(!ysAx`ed � {
    this.3�idEr
a`pend�hhld( Fsgoednu 99
` u"elre {
  !"va0$mnsertCelmEnemenu =8this.aeli7[ ind�x _.ele-e�t��!  !thx1slid%r.)nsErtRefmre !FrAgmdnt, incdztCellElement ,;
  }
  // add to`tHis$cells
 (Kf(! i*dex(== ��) �
  )�g/ prgpeNd- aDl"E� stast
 $! this�cenls = aelds*cooc`t($piiS.sells )*` }"else!kf ( isA`pune ){    -/`��penD, ae�$�k end
 $ th)s>ce�|c = phis&#edh3.kong`t  cDxls );
  } elyE({    // YNWetT in thmq.ce|�s
00  var enlCells }`t�is.celmc.spLi#e(�andeX( Len - inde|`);
    this.cells = uhis.c�dl3.co�cau( gallS!)ckjcat( eneKe}lc!);
  =�
  this._3izeCell3* cells );  tli{cEll�h!ngu( mnd�x, true );
};
pto6o.qp0mn� 9"functmcf  e|tis +�{
" thisNirser�8 eLemq, thIs.�ell{�l�nglh =;
9

protonpve0And(= functinn) e,em2 * {
  p`icinsert( alems, 0`);
};
/!
": Beoov'�cells
0* @param ��l%ment( ArRay, No`eLisuu"g,mmc
$*/
prodo/ramgve � f�nctyn, g�mmc )({
  var ke,ls �!thiq.getCells( a\eMs );
` )" ( acehlb |� !cell�.leng4�) K
   `su|qrl; u
 4var mioCedlI�t�x!= t`ms.�gll{.,ung�� - 1�
  //0ramove cells fr/- co$lectigf &0DO_�  Cells-fovEcch( f5.ctin( c�|�") {
$   cell&rEmo�e*-+ �  Vab yndex = |hisncells.mfeeXOv  cenL 9
  �-hnCellMndex = ]ath.min intuX EinCellnlex );
    �d�ls.semo�dFrom( ryis.cells, cUdm ;
  }, this );*& th�3/c�hlAhanw%( minCellInde8- trUe);
}:

/** 8)logic UO be run !&teZ a cell!s size chajoes
 * PPaRA} {Elemun5} gdem ) beld'� e,#}eot
 *�
`roto>koldSazeSHange < functi/�( elem()�{*�prar sml�!= 4his.oe4GEll( elum �;
  if h !ball ) ;
    r�turl;
  }
  ae|l.vetSize,);
  vav )nD�x =$uhik,Cu�ms/indexn, cen, );
  |las,cellGhanc% inde�$i;={

/*:
 *"logib cnh�timg a cul� is chinced: `$ded, removel, o2 saze1changeeK#+  param([InTegez} changEdCElfMndex % in`my of�tJe shanget celh, /pti��c� "/
proto.ce,mCh�n%m = functioL  cHqfgadCelLMnDEx, �sPowitiolkngWlides i0z� Vcs"prewS�lektedElem =!tjic.selectedE|meen|;
  thi�._q_q�tinnC%llsh!changed�el�Knmex );  this,^g vPra�S�iftCells�);
! this.setGCl�erycize(-{
8 // upfate 3olectedKndex�  �/!u0y to main|ain posm0ion & Selesu previou{(seldcted elemen�`0vaR cell"= 4is.getBgll( �revSelACtebElem�)B0 if ( c!le$- �
  " |hicnwelE�tgdKndex ? thms�gete}lSnideIndmx( sell$){
"`�
  4has.selgc�edIndex - Mat(.min( 4h�s.s|mD-s>len't� =�1, this&qel�c|edI�deh i;*
  th�w.ematAvenT� %�allChange', [ cHanoeDCellI'dep ]");
  /? poSmvi�n sliteb  t(isnwg|ect th9s.ci*a#�edIndex`9;
 (��do$not po2itign {lider!a"teb@nazy4lk`�  hg ( �sPo3i�i�anoS,i�e�!) {    *tji{.pO3ityoNSditurAuSemektee();
  }
|;�'/ -o-)-  -,-�- /-
�redurn Flick�tq;
}));

//(lahydnid
( vuncpic�( s�.fow, gectoby )�{ !// u�i�erwal o_a�le�`ufinltigN
`@/:!z3�i�t strict: d!Lre *-0 ih)($tyqekf Dmfhoe(=<`'fulsTion' && eef{n%.ei`H) {
    // A]D   *de7)ne (&b<ickItq/js/mazyload',[
!�    './f|icci4y',
     $'f}zzy-uy-udils/uu)lq'
!` �]< dujcT)gn( Fdick)tY, Utils ) {
     (petur~ Factor{ windmw� Nx)ckitY, uti�sh)+    |); p} %lse �g ( 4ypeif m'dula(== 'bje�4'$� mOluLe.exports() y
$   //0ComMOnJS    moeule&gxrosTs  fectory(
  (   in$ow,     �resukbe*g.+fliccity'),0  $( requip%�fizzy-ui-utis'-
 !!x);` y"elsE({
    // bbowser2goba�* ��nactorx(
  0 (wijdoV$
      wkfekv.lickity,
p!    w�|tW.diz{|TIUils
  $();
  }

}(!windnw,"funbtaOn$f@ctgr{h(Vindow`Flic�i~q, utilc ( {
'use!strmct'

Fliakity.kraTeMet`oes.pusx!%_cre�teMazyloed');
v!r qvoto`5dFl�ckit�.qro4otype;

u2opo._cruateLAzyh/ad = fQnctykn(	0{
  uhis.on( 'select�( thyq.lazYL/ad (;�}�
prOv�.nazyLoad }@function * 
`$var ,az{Loqd = this.kptio�3.lazyLgaT;
 "if"( `,axyHoad@) {J$   return;
  }
)`// get adjacent ken,s, u�d laz{Hoad optioz for adlacenT coun4$ v�v adJBoq~40-(�iPemn lazyLoid -=!'neljer'h70fazyLoad :"02
  var ceLlElels =$thyr"fevAd~ac-n4CellUlemelts( a$*Cownd �3�  /. oEt�,azy0i�`'�s in 4@kce`amlna
  ~ar(�azyI�ages 5 [];�0cellEhe�qLVobac`(0F|nctiol( s%llEHe- ) {
    var"le{�CeldIoaGes ] �e4C%l�L�JyImages( ce|lEhem );
    lazyImages8= l!~iImages.concat( na�yBellImageg )s"$}):� /& lOad lazy0imaGas  hazYImages.forEach( functi/o( ilw )${
  ` �av`Lazy\adeb yeg, this );
  ], thks );
m;

&unGtaOn GetCalm\azyMMages( culLeleE 	!s
( /- chEck!kf cel eLement is lazy`iiage
 �af ( cellElEm.nodeNqme 9="�GMG' -${
!   ~ar!la^xloaeAtdr = c%llEnem.getAttrib}de(�$`ua'fli�kIty-Laz}load');  !var SrCEttR 5 sgllEhei.g%|A~tribu0�(&`atA-Nlacjity-laryload-src');
   ��cr 7rk�e�AttR(=$cd,lEhel.getEttrIrut�('dqta-nlickity-lazyload/srcset');
*�! kf ((la~yl/aDCutb(|| sbcAtdr ||(srcsetAttr!i [
   0p re4urn [ cellElem ]+
    }
` }
  '/$velecd0lazy ime'ew(i� �ell
  v�r Laz9S�l%ctr!= .xmg[Data-vlickydy-naziloa�]-"/ +
   !'img[data-flackaty-lazqmoad-srcM�(i�g[`aTa)dlackht�-l!zXlmad-srcset]';� ��r )eg = cg�lE�e�.Que2ySelmct�2I,l( lazySmxec�or$)k
  repu2. utils*iAke@br!9( imgs8)�u
+ ----=�$=-/---=---------=- LCzyLksfer ---=-----,)/--m--%------- //
�/** " cmAsr tO handl%!�oa�h^g imAges 8/
functi�!E`z}\oadev("mm�, vdkckkp} ) [
 (uhis�imo = ioC9
� thIr.fnIcjitY"- fh)gkypy; `th	w.doad();
x�
�azyHoader.pvototypa.h�n$laE6ent }&utml�.handleEvEnt;

La~{L/a4pr.pro4otypfloa$ = d5nction(+ {
2 Uhhs.`mg.addEven4Hisve.eR( 'load'- 4his );
  thasim�.add�WejtList�laR( &erbor/* tlys )?
  // get crc & wscs�u� �var sra =this.ImO*getAttribu4a(%data-flmcki�y-daz�lo!d!) |t
   0thys.i}g.ge�Att2ib5$e'dapa-fliccity=lazy,o�dmsrw')3
  v�r sCcsEt = phis.imw.cetAttribUte('d`t`}flickity-la{yload-3�Cweu');
  o/ set cVc &zdrset
 "this.img.src -`3rc;
  if"( s�cqap ) k` ( uhis.img.wetATtvibqte( 'srksdv', srbWet -{`$}
 `). remRe!atdr
 0t�iq.img/re�oVettrmbtte('davc-flacki`y/laz}locd');
 $this.img.sammveAwtribute('date-fliakity-l!zyhoae-sbc�);
  �hhs*img.�em�feAvtri2utm('da4a-dniccmt9)lazxloce-srcset&);
}+
LazyLoafer�prtotypenonh/ad1="funct)on( �vmnd � {� "uiis.qoiplevm( eve~t, 'fmakmity-(a{yl/ade$'$(3
w;�
Laz{Load�r.p"gtot�pu.on�rzor� Functinl( %v�~t@) {
 `tlIs.compmeVe("evdnt,�'flicKItylaxyerrjr&0);
-9

Lazy\o``er/pzototype*a�m`lete*? ~ungtimn( Event, c�qssName ) { b//0uob	n` even4�
0 tHis.)mg.reimrmAtentListeo%r( lOq�G, thhs +;
$(thiw.Img.reMo6eE7e.`Li�tener) 'arrnr', thks �+

� var cdll =ptjis.ohickIty�'etarg.teMhh this.img );
� 2ar!cellilem 9 cell f> kehl.one}Ent;
  thiqnflic+ity.sellSizeChence� CelhE|%m$);

$ this.img.ClaccList.add  sma�sN�-e ):
 �t�is.�likkIty�tisp�TbxDV%nt( 'lcxyLoad', evaov,"gel�le- );
};

?/ �/-,  ----- /�

lickium.lizyMoa`ev = LazyDo!der;

rEt�Rj Nlic+ity{
}9)9

/*!
 j"NlicKi|9 v2&2.1!* Touch, rus�on�ivE, flickable carousels
 *
4. LicejseddGPLv3 dor gpen source use
 * os Fhicka�9`Commer�iad Lacgnrf g~r`cgmMebCiaL usm
 .J$* hdtps:/+fl)ckaTy.let�fijzy.bo * Coyr	ghT(215-20q9 Metafi:z}
 *'

:0f%j�pkof)�win`ou, dabuorY 9 {  O/ universal"e�dule dmfi�ition
 $/*hhs`int qtri�u8 fkhse .
 fif ( tiqeg� d`fine!9= �f}nct�on' && da&ingaifd) {
    // EED
    fefioeh$'gniCiity.js�In�ex'$[
  ! ( '..gli�khdy',
      './draw,
(     '/pref-Nuxt)bttton',      &*'page-dots',
      './p�ayhr&," "  "/./c`e-�a�o6e-cenl',
 `8   './laz9lma@&
    ], faslozy");
  = elsm id ( type/v module 5= �oBJ%k|/$&& moduLG.Erp/r�s )"{! ` / If}m?~jR
0$  mOdule.exports =`vaB0Ory(
$    (rmqtyr�(7./dl`c{it9')
" �`! ba1ti2e(6./�zag').
`!    r5qukze(�./prer-ne8t-jtttong)-
     #reQuire('./pcge-doTs'),
 !    vequhre '&/play�s'i,
 ( (  zesuird('./#dd-pem�vD-cell')<
 0� ! rEquire(g./lazyloal'(
    !;
 0}})( vindow,$&}ncxhmn cac}or{  Fh�Chhty ) {
  o"jqh�.� 3�~icd d`|se*'
! retur� Fli#kkty;�e�;

/*1
 (�f,ickkty$a{N�vFr"v2.2.2
 j0eFe`l� `SNa~For for Flic�i~} */*/jhc`int b�ows%r tRug, uf��f: true, unured: 4zu�l s6r!ct: qrue*/

( fq�cty/j( windo� g`ctorY ) {
"(+/ uNkvercanbM�dul� ddfmnition
"�?*js`int svri#t FalgE */$/*globals0�e&ane, lo$uled reu5i`% */� !Hf ( t}`mof denine 9� .vunctiOl' && defI.E.amd ) {
    // AID
 `  ddfine( 'fLisnitq-as-na6�or/"snAvfox'�
 $   0'glackitx/js/in Ex',
(�  $d'f)zzq-�a-utins/u�als'
    _$ f`c�ory ){  } elS' i& 
 tY`eo&`mnd5m%$== 'obnec4' &' mjdeld.ex0�r�s - {
!0! //0Comm/nJS
 `  moluie.m�por|s � jic�ory,J  $   r%yuirg)%flickhty&�(
  $2 $requare(�&izj�-ui-utyis7)
  ) );
 0} ehse`{
    //"br�wser globad
  " wyldOw.FnIcj`v} = geqtory(
  @ 0 gindmv.Flic{ity<
  e  17knlow.fizxmUIUtIlsJ!  $); `}
}` aodow- &tnCtiol facvory( F�yck)t�, etils ) S


// ------=--/--(--%--------,- asNevFos"`ro�oeypg --=---------�--)--%-!//
 // Flic{i�y.de6aults.as^atF/r ="null;
FlickIty.creattMe�hols"pusi ._createAsFavor');

var$ppotG"5!Flikhti>pr~tot�pe+
proto._c�eaveAsNc~F�r = fqn#tion()0{
  thi3on 'qctiwa|e',!this>Ag4ovateA�NavFor -;
  0his>on( 'leqCtiv`te', this&depcti�atUAsNavFor !;
  this,oN* 'destRox'< thi�.dustr/qCrNavBor );
  vur"aqNavFozoppion =�tlas.xtiojs.as^efF/b; !iF ( !a�N�~B�rNpTion ! {�( � return;
` |
  /(HAJJ�d/ aQyn� g)vE 0hme foz)otleb"f~icjity`to bg ilitclhzed
 "var _thAs!� txis9  s�dTimeout( &unstion ifh4NcvCompani�n()�{    _thms*qetNav�o}panhon( asNavDorO@tign );
$!})+
{
xrotn.setNcvGompajion�= funathon( elE/ ) {
  ileM 5(utAls.g�PUUdryEl�malv  el%m );
 var"cnipanion ? W|ic+yty.data( emem")5
$ /. stOx if .o koe0!~inn or gOmpeniof 	s!3glf
 (If (`!C�mpinimn || cmmpqnmgn =? thi1!) y*  8!rgt�rn;
  y
" thi3/navComxeniol0� compa,)o/;" //0kOmp�n�on Select
" Vaz _this�= t(is3` tliw.o>Na|C�IranyonSDlecd�=$funs|ioj,) {
  ``_this.a�Com�cnionSelect(+;
 !}�
  cmmpAfion&on��gsa|ct', phiq.�nLaComP`NcnSelegt ))
  /. glikk�  thi3./n( 'wtatibC\i�k'< Th!s.onNavStaticClicK (;
 "u`iw.navCompelionSalecd, |r%e )3
};

�rotO.�`rColp`~iolQelEgt!= functimnh)sKn{tanTa) {
  o/$sqir f/r cOmpajion & relectedculls(fmrst.�#8
` vab cfmp!ny/nCulls = tjis.NknCnmpanion0f& thksf�!>�nmpanion.s�lucTedCeLls;
t id ( !compani�nCmlls() {
    Returo{
!�}
  // smluct �lide vhat matchds fijst!culh$of slafe
  6`r"selectmdcelD = CmmpalinnCells[p];
 �varfyrstInlex`= \hiS,nAVCo%pal�on.celLs�ineuxf( se,ugfelCell�)+
  v`r lastIndex =�nivwtInlgx + coeranhonCmll�.,eNgth - 1;
  var seh%c�Kndex =�MItl.b�mg2( lerp( fir�tIndgx- lestIn4eX,
   $This,n�vC/mpanin.bdnlAtig� ) -:  thhs/selectCelL( cedec�INdeZ< Fal{e,`isHnctAnt$):
  ?/ qet nav0selecte` klasq
� ujis.reiovenavSelectedElements()� �/+ sto� if compinimn has m"e cells txEn this ona
 (if ( {gl5ctIndDx(>=(this.kedls.lengti ) s
   0r-T5RN+
  }

  var �ddecte�Gemls`= this.celns.{dice(`fir2tHldm�, lasuInde|� 1 );
 $th�s.n`vCeleatedEleme~ts � 3almctEdKells.eap*(�qnc|io�)(#�|l i {
 `` retWrn%cull.ele}ent;
 0});
( th�s.ch�ogeNa2%lectedClasc('iDd');�}:�
fwnction"l%rP( C�(B, t i {
  zeturn"(*c � a + *`u +q;J�

pr{po.chanoeNavSelactt`Clasw =pfunC%ion( metxod�)0{ "thi�(navSelectedElUiends.n/zEi3h(0function�!navElem ) s
 8� �avDle}.cmassList[ mMth�d ]�#i3-nav)sedected')3 �u);
}?
pro�o.activatdAcNavFor(=`fs.Ctiol(([.  |hiq./�vO-panmonStlecT, pRuu );
=;J
pzotM,removaNa>SuluctddEddeents(= fungtikf() {
 ai� ((!this.~AvSeLected,e}en4s ) {
    return;
  }
  this.changeNavSelectedClass('remove');
  delete this.navSelectedElements;
};

proto.onNavStaticClick = function( event, pointer, cellElement, cellIndex ) {
  if ( typeof cellIndex == 'number' ) {
    this.navCompanion.selectCell( cellIndex );
  }
};

proto.deactivateAsNavFor = function() {
  this.removeNavSelectedElements();
};

proto.destroyAsNavFor = function() {
  if ( !this.navCompanion ) {
    return;
  }
  this.navCompanion.off( 'select', this.onNavCompanionSelect );
  this.off( 'staticClick', this.onNavStaticClick );
  delete this.navCompanion;
};

// -----  ----- //

return Flickity;

}));

/*!
 * imagesLoaded v4.1.4
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

( function( window, factory ) { 'use strict';
  // universal module definition

  /*global define: false, module: false, require: false */

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'imagesloaded/imagesloaded',[
      'ev-emitter/ev-emitter'
    ], function( EvEmitter ) {
      return factory( window, EvEmitter );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('ev-emitter')
    );
  } else {
    // browser global
    window.imagesLoaded = factory(
      window,
      window.EvEmitter
    );
  }

})( typeof window !== 'undefined' ? window : this,

// --------------------------  factory -------------------------- //

function factory( window, EvEmitter ) {



var $ = window.jQuery;
var console = window.console;

// -------------------------- helpers -------------------------- //

// extend objects
function extend( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
}

var arraySlice = Array.prototype.slice;

// turn element or nodeList into an array
function makeArray( obj ) {
  if ( Array.isArray( obj ) ) {
    // use object if already an array
    return obj;
  }

  var isArrayLike = typeof obj == 'object' && typeof obj.length == 'number';
  if ( isArrayLike ) {
    // convert nodeList to array
    return arraySlice.call( obj );
  }

  // array of single index
  return [ obj ];
}

// -------------------------- imagesLoaded -------------------------- //

/**
 * @param {Array, Element, NodeList, String} elem
 * @param {Object or Function} options - if function, use as callback
 * @param {Function} onAlways - callback function
 */
function ImagesLoaded( elem, options, onAlways ) {
  // coerce ImagesLoaded() without new, to be new ImagesLoaded()
  if ( !( this instanceof ImagesLoaded ) ) {
    return new ImagesLoaded( elem, options, onAlways );
  }
  // use elem as selector string
  var queryElem = elem;
  if ( typeof elem == 'string' ) {
    queryElem = document.querySelectorAll( elem );
  }
  // bail if bad element
  if ( !queryElem ) {
    console.error( 'Bad element for imagesLoaded ' + ( queryElem || elem ) );
    return;
  }

  this.elements = makeArray( queryElem );
  this.options = extend( {}, this.options );
  // shift arguments if no options set
  if ( typeof options == 'function' ) {
    onAlways = options;
  } else {
    extend( this.options, options );
  }

  if ( onAlways ) {
    this.on( 'always', onAlways );
  }

  this.getImages();

  if ( $ ) {
    // add jQuery Deferred object
    this.jqDeferred = new $.Deferred();
  }

  // HACK check async to allow time to bind listeners
  setTimeout( this.check.bind( this ) );
}

ImagesLoaded.prototype = Object.create( EvEmitter.prototype );

ImagesLoaded.prototype.options = {};

ImagesLoaded.prototype.getImages = function() {
  this.images = [];

  // filter & find items if we have an item selector
  this.elements.forEach( this.addElementImages, this );
};

/**
 * @param {Node} element
 */
ImagesLoaded.prototype.addElementImages = function( elem ) {
  // filter siblings
  if ( elem.nodeName == 'IMG' ) {
    this.addImage( elem );
  }
  // get background image on element
  if ( this.options.background === true ) {
    this.addElementBackgroundImages( elem );
  }

  // find children
  // no non-element nodes, #143
  var nodeType = elem.nodeType;
  if ( !nodeType || !elementNodeTypes[ nodeType ] ) {
    return;
  }
  var childImgs = elem.querySelectorAll('img');
  // concat childElems to filterFound array
  for ( var i=0; i < childImgs.length; i++ ) {
    var img = childImgs[i];
    this.addImage( img );
  }

  // get child background images
  if ( typeof this.options.background == 'string' ) {
    var children = elem.querySelectorAll( this.options.background );
    for ( i=0; i < children.length; i++ ) {
      var child = children[i];
      this.addElementBackgroundImages( child );
    }
  }
};

var elementNodeTypes = {
  1: true,
  9: true,
  11: true
};

ImagesLoaded.prototype.addElementBackgroundImages = function( elem ) {
  var style = getComputedStyle( elem );
  if ( !style ) {
    // Firefox returns null if in a hidden iframe https://bugzil.la/548397
    return;
  }
  // get url inside url("...")
  var reURL = /url\((['"])?(.*?)\1\)/gi;
  var matches = reURL.exec( style.backgroundImage );
  while ( matches !== null ) {
    var url = matches && matches[2];
    if ( url ) {
      this.addBackground( url, elem );
    }
    matches = reURL.exec( style.backgroundImage );
  }
};

/**
 * @param {Image} img
 */
ImagesLoaded.prototype.addImage = function( img ) {
  var loadingImage = new LoadingImage( img );
  this.images.push( loadingImage );
};

ImagesLoaded.prototype.addBackground = function( url, elem ) {
  var background = new Background( url, elem );
  this.images.push( background );
};

ImagesLoaded.prototype.check = function() {
  var _this = this;
  this.progressedCount = 0;
  this.hasAnyBroken = false;
  // complete if no images
  if ( !this.images.length ) {
    this.complete();
    return;
  }

  function onProgress( image, elem, message ) {
    // HACK - Chrome triggers event before object properties have changed. #83
    setTimeout( function() {
      _this.progress( image, elem, message );
    });
  }

  this.images.forEach( function( loadingImage ) {
    loadingImage.once( 'progress', onProgress );
    loadingImage.check();
  });
};

ImagesLoaded.prototype.progress = function( image, elem, message ) {
  this.progressedCount++;
  this.hasAnyBroken = this.hasAnyBroken || !image.isLoaded;
  // progress event
  this.emitEvent( 'progress', [ this, image, elem ] );
  if ( this.jqDeferred && this.jqDeferred.notify ) {
    this.jqDeferred.notify( this, image );
  }
  // check if completed
  if ( this.progressedCount == this.images.length ) {
    this.complete();
  }

  if ( this.options.debug && console ) {
    console.log( 'progress: ' + message, image, elem );
  }
};

ImagesLoaded.prototype.complete = function() {
  var eventName = this.hasAnyBroken ? 'fail' : 'done';
  this.isComplete = true;
  this.emitEvent( eventName, [ this ] );
  this.emitEvent( 'always', [ this ] );
  if ( this.jqDeferred ) {
    var jqMethod = this.hasAnyBroken ? 'reject' : 'resolve';
    this.jqDeferred[ jqMethod ]( this );
  }
};

// --------------------------  -------------------------- //

function LoadingImage( img ) {
  this.img = img;
}

LoadingImage.prototype = Object.create( EvEmitter.prototype );

LoadingImage.prototype.check = function() {
  // If complete is true and browser supports natural sizes,
  // try to check for image status manually.
  var isComplete = this.getIsImageComplete();
  if ( isComplete ) {
    // report based on naturalWidth
    this.confirm( this.img.naturalWidth !== 0, 'naturalWidth' );
    return;
  }

  // If none of the checks above matched, simulate loading on detached element.
  this.proxyImage = new Image();
  this.proxyImage.addEventListener( 'load', this );
  this.proxyImage.addEventListener( 'error', this );
  // bind to image as well for Firefox. #191
  this.img.addEventListener( 'load', this );
  this.img.addEventListener( 'error', this );
  this.proxyImage.src = this.img.src;
};

LoadingImage.prototype.getIsImageComplete = function() {
  // check for non-zero, non-undefined naturalWidth
  // fixes Safari+InfiniteScroll+Masonry bug infinite-scroll#671
  return this.img.complete && this.img.naturalWidth;
};

LoadingImage.prototype.confirm = function( isLoaded, message ) {
  this.isLoaded = isLoaded;
  this.emitEvent( 'progress', [ this, this.img, message ] );
};

// ----- events ----- //

// trigger specified handler for event type
LoadingImage.prototype.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

LoadingImage.prototype.onload = function() {
  this.confirm( true, 'onload' );
  this.unbindEvents();
};

LoadingImage.prototype.onerror = function() {
  this.confirm( false, 'onerror' );
  this.unbindEvents();
};

LoadingImage.prototype.unbindEvents = function() {
  this.proxyImage.removeEventListener( 'load', this );
  this.proxyImage.removeEventListener( 'error', this );
  this.img.removeEventListener( 'load', this );
  this.img.removeEventListener( 'error', this );
};

// -------------------------- Background -------------------------- //

function Background( url, element ) {
  this.url = url;
  this.element = element;
  this.img = new Image();
}

// inherit LoadingImage prototype
Background.prototype = Object.create( LoadingImage.prototype );

Background.prototype.check = function() {
  this.img.addEventListener( 'load', this );
  this.img.addEventListener( 'error', this );
  this.img.src = this.url;
  // check if image is already complete
  var isComplete = this.getIsImageComplete();
  if ( isComplete ) {
    this.confirm( this.img.naturalWidth !== 0, 'naturalWidth' );
    this.unbindEvents();
  }
};

Background.prototype.unbindEvents = function() {
  this.img.removeEventListener( 'load', this );
  this.img.removeEventListener( 'error', this );
};

Background.prototype.confirm = function( isLoaded, message ) {
  this.isLoaded = isLoaded;
  this.emitEvent( 'progress', [ this, this.element, message ] );
};

// -------------------------- jQuery -------------------------- //

ImagesLoaded.makeJQueryPlugin = function( jQuery ) {
  jQuery = jQuery || window.jQuery;
  if ( !jQuery ) {
    return;
  }
  // set local variable
  $ = jQuery;
  // $().imagesLoaded()
  $.fn.imagesLoaded = function( options, callback ) {
    var instance = new ImagesLoaded( this, options, callback );
    return instance.jqDeferred.promise( $(this) );
  };
};
// try making plugin
ImagesLoaded.makeJQueryPlugin();

// --------------------------  -------------------------- //

return ImagesLoaded;

});

/*!
 * Flickity imagesLoaded v2.0.0
 * enables imagesLoaded option for Flickity
 */

/*jshint browser: true, strict: true, undef: true, unused: true */

( function( window, factory ) {
  // universal module definition
  /*jshint strict: false */ /*globals define, module, require */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( [
      'flickity/js/index',
      'imagesloaded/imagesloaded'
    ], function( Flickity, imagesLoaded ) {
      return factory( window, Flickity, imagesLoaded );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('flickity'),
      require('imagesloaded')
    );
  } else {
    // browser global
    window.Flickity = factory(
      window,
      window.Flickity,
      window.imagesLoaded
    );
  }

}( window, function factory( window, Flickity, imagesLoaded ) {
'use strict';

Flickity.createMethods.push('_createImagesLoaded');

var proto = Flickity.prototype;

proto._createImagesLoaded = function() {
  this.on( 'activate', this.imagesLoaded );
};

proto.imagesLoaded = function() {
  if ( !this.options.imagesLoaded ) {
    return;
  }
  var _this = this;
  function onImagesLoadedProgress( instance, image ) {
    var cell = _this.getParentCell( image.img );
    _this.cellSizeChange( cell && cell.element );
    if ( !_this.options.freeScroll ) {
      _this.positionSliderAtSelected();
    }
  }
  imagesLoaded( this.slider ).on( 'progress', onImagesLoadedProgress );
};

return Flickity;

}));

