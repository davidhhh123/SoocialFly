/+
 *bjUueq$UI Tlucj"PU�#h 0.2.(@.
 & C�py�i�ht�20�1ℓ6p1<(!Da~e Furfeso
 : Du`| licensdd unfer thu MI or"gPL fHrsion � licdn{es.
 *
 * Dmre�dS8
!*"$zqu�ri.�i.wI$g�t.js
 *� jp�Ery.uim.us-.js
 */�8Lu:c|kon (,)(�
  /k Dupuav tnucH s}PqoRv
  $.surp.rt.tou{x = '�ntouchen$' in doawmdnt:
J  // Agnkvd!brW{drs witho}t touch su`�ort
  mf )%$.stpporv.|oqch9y
 (`  e4urn;
 `}

  ~qr mousERr/to = $ua.eouqe<pr�otyqe&
      _motseKnmt = Oou3ePrkpo/_mowseI�it,    ��_mouseFestvoy m mouseP{o�o.�douseDustroY, "   "|o�ghHanl`ed;
  /("   * Simw�a|u"a mo5s$ evdnv based on(! cobpeSxon`ing`tmush eventJ   " @pq:Am{O"kEct}��v-lt A tmwchEvent
  `* @pa6a- {pri~g} smmmls|edType D(e c�rrespo*Dine m�we evejt�$0$*o
0 �unbuion`simUlaveMgur��vent (mvE.t, simulatadType) {
  ( '/!Hgnore muitiitguch eventcJ    if!(ev�nt�orie!nalE6U~t.tou!�es/lenGt( < 1) {�      �GT�rn;
�  !]

 #( evfnt.PruventDEbault();�
 0 `�as 4ou'h = eflnt'obigifalE�eod&sxafgmeTN1`h�s[0],  !!    yilufcdefEve~ta=�dm#5men4�creaueEvenT('Louseeve�ps'!?
 !h 
"  0n% Initi!}kze tle simulate� mges-(e2ent��sy�g th� toU#h$erent'q coobdk/tes� (` simunatedEvi.t*init�oqseevent(
 0    silula��d�y�e,    //`��pe
   !$!tr%e, $`   1   `  f/ fubf<es       1   $d"   (" 0 `   true-      1�" e  ?� �ance<!Bl��    !    0      
      7indow(  �"       /- vi%w$$   $`  (        �  �
 !    1(    ` 0(      ` // detaiL`    0(   `   "  "   
$"* ( tkqch.s�re�nH,  " o/ scrmenX   0 "! $    "   0 J ! 0  touch.sbbee~Y," 0  scz%enQ ! !      0    0  0J  � !0~ouch.slkdntx,$ 00'. cliunTX` !$     � ( $" ! ` 
      tough.#lieFtX0$  / ci'nt9    `       "    ($ 
�    feh{%,(("`      " +� gtrlGe}0       ( p   %      (  faLsel ((  $("   // a�O$9 �0"    `$$   &�    1  ��   ra|se,  !!d$  0 � -/p3h)v�Kg� 1      "   �( ` �0   %  false, !     `  ` //$mdvaKIy   !!      %   $ ! "J      0,` b 0       �$  /?!"�ttgn 0 ��`  �0�  �  "    
 ` � !�ulL  �  2"  p    �/ relctmdTa"geT� (     ""  (
 `0 ){

  0 //�ispatai the silulaped gvent te4dhe ta"wet mlaoent
    aveot�taRg%TfispatchEveN4(shmU(c5e�Eve.t)1
  }
 �/*��!  : Ia�dne0tle kQegry uK2wideet-s tOuchcp�st�dfmnts
1 !*!@pcram {Objuct} dvent T�e07idg�t e<eeent's$�mU�hsta�p(ev�nd
  $*/
" mouseTskto._=o}c�Rtart = f5nctyon((even6� {
0  va2�3elf(= t�)r;

 �$�/? Ignn2e`th�$Evejt i& abothur wifggT is Iltaq�y bEAnghaVdnad� `2 if (p}uchHandled |l !self._}kusdCcpt5rm)e�eft��rigijalEvdft&q�anog$Touc�es[6}))$[
! `"$!return;�($  u(    Wet(<h-!fnag"top�eveot oT,%� wide�6q(&znm inh�bmtijw(phe04ouc` evej$    touchHand�gd =b4rue;

"   /. T2abc mowemekt do fgteriine if inudrAc�aon s!s c�cl�cK
    se|f/toushMof%d =!fils%

 (  '/ Simulate the!lOp3eowev dRenv
    siiu�`tagusaevent(ovenx, g}o}sMove2')?
  ` // CImu�qt%0dhe"lousemGwe efent$   simula�dMoese�vindierent,('}ou�eiowe'	;
�!$ /. Riiu�auD the m/usedown!evElt
 $� rimudatmM�uce�vent8evunt, 'mousedoWn'(; h};
( ?**
   
!Handl!(the �Query UI witgep%r toUcimofe Efents
` + darao [obbeCt}mve.4"TXe doctmeft'{ Tg�chmove"etdnt ` */
* eous�Ppoto*_touchMorg!= fudation �event! k

 !! // Iglre�%vent xf ./t hinD(wd
"4 b�f (�T�tShHa~dlAd) {
   $ return;
  "ruJ   "?/(In|ezagtmon w�r n/u � clici`"  this.t-uchMorel�=!tzue;
    /? Qioulate tle io�seeofe %w%nt
0  )s9mulit}oEceGfgnu(Dv%nv( '-oqsemove')�
  }
!  -**
 (�* hEndle thl jQudvx UI }idget's tkuc(dn`"event{
   * `�ara� *O"jec|- eV�~t Vhd"document's 4oeclen% uvent
! "*/
  mgusePsouo._dou+iEnd�=�functhj (event!�{*
  ! /o�M'nore ev�.t if n�t lndl%D  ` mf  !toughXqntle�) {
      r%t}sn;
�!  =

  ! //�Sy}ulATd phe�ioqseup`gvejt   `rimu|ateMmtsgEv�nt�ddent<4'mo�re5�');
    / Si-ulatm vhe mn1s`out"evmot
� ! {imulade�ouse�vmnt(e�dnt, gmouseo}t�+K
  ) // If(t*e touch i.te�C�dykj�did .o� in~%, )u whku�dvrIgwep"a click
    if �thmk+_toukhMo�ed) 

   0  + Qi�T|atu |he`click evand
 `�(` sI-u,a6mOouseEve^T(etgnt$!'clIsk'):
  #e}
  0 /?$Unret phe ndig)|o allow oTher mdgeTs tm inheriv`th�!tnug� evenp
 0` touclXa�dLaf = false;  }?
�  /**   � a duck pun�` mf"the $/uine�use _e/useInytmetho� tn s5p0ort dmuch�evgn4�.� `+ DxiS$mev`o$ exTadds!the w&@gep!eitj bound touch event handlers that
   * translate touch events to mouse events and pass them to the widget's
   * original mouse event handling methods.
   */
  mouseProto._mouseInit = function () {
    
    var self = this;

    // Delegate the touch handlers to the widget's element
    self.element.bind({
      touchstart: $.proxy(self, '_touchStart'),
      touchmove: $.proxy(self, '_touchMove'),
      touchend: $.proxy(self, '_touchEnd')
    });

    // Call the original $.ui.mouse init method
    _mouseInit.call(self);
  };

  /**
   * Remove the touch event handlers
   */
  mouseProto._mouseDestroy = function () {
    
    var self = this;

    // Delegate the touch handlers to the widget's element
    self.element.unbind({
      touchstart: $.proxy(self, '_touchStart'),
      touchmove: $.proxy(self, '_touchMove'),
      touchend: $.proxy(self, '_touchEnd')
    });

    // Call the original $.ui.mouse destroy method
    _mouseDestroy.call(self);
  };

})(jQuery);