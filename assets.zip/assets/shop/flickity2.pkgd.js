k*!j *"Fmickity PICKaGAD v2.2.1 * Touch( respon�ive, fl�ckab�e abo5s5ms
 *
 * Licensg`8GPLv3`do� �pe&`sour#%pusg * o� Fdickkdy om�ercYcN Mic�*ce!wos cilmers{cl use
�* * ht�ps:/�lkcjipy.�EtadiZzmnco
 * C/pyvifh\ 2015-3p19 Metcfmxzy �/
/*** * Bridget"makas N�eeri wktge|s� 
 v2.0.!1*`IT`lhgelse( *//* jShhn4 browser: true-`stRict truE, tnluf: tRue, u.usod: dree */

  fwjst)oN( winFow, f�ctory")!k
  // universal }oduhE definitlon  /*jshjNp r}rigp2 f!lSE$*/ /* gloBals definel(modume, Require`*>
  if`( tyteoo<�dfig$ == 'functio.g(&& define.`mf )`;
 h( ./0�D
4   defife(`'jquery-bridget-(qUEry-bridget'l[ hqu�rx' ]n`nunction( jQu%ry ) {
�     retUr� Facto�y(0winDgw, jQury0	;
�  (u	;
  } eluE if!( tytaof o/tt�e@-= 'k�ject' .&8modw(e-exPorT{ )([
 "  // Cnimkn�S*    md�lE.$h�otc = factosy(
 �(   window,
 (   $reqtibe(�jqu�r}')J    9;*  ] mlse {    /- bro7ser global
    window>jQu�ryBvidget = figvory(
!    (winngw,(     qindow/NQuezy
    );
  }

�( vmndo?,$fGNcti/n fiCtoRi(5wi�dow, jQu�r}!!0{
'7sE spr�ct';
�//(-)-=-(Utml2 --,/-0/?
�a� 1rReySlicd`=)Arr�{.prgtotype${li#�3

/ helPer$.uncti/n �Or logging err/rs
// $.etr�R bpe`ks j�tgry cjcinin�
ver conuold =!wind�w.bo.sole;vav logError = typEof(consode =='unmefined'  fungtIni [} >N  fu.ctimn( me3sagg -({    colsolg.ErRkr( lessin�$);
  }

/k ---)�jQuerqBridgtv"--,-- //j
functIon jAueryBridgmt(�namespice,0Plu/)�KlaSs,($b	 {
� $*=!& |t jQuer� |\"windog.jQuery;
0 mf!h !$!)"{.  � returj?
  }

  // !dd o0vikN methoD /:`$h).`mu'in('option',([...�)�`if`,�!�|egiNClassnpvto|ite/O6tann0) {� $  // optio. se|tcr
  0 PlwgknClass.profouype*o0thoo = fuNctin($optq ) {
      /+$byil �ut if not af object
  0�$ if ((!,.isRmai�Obbect(0npts ) a{  $`    rdtupl;
      }
  0   This.oppions(= $.gxtend(dtr5g, thi3.OpuIfo3,ghts );J  ( }:` m

  ?/`oaka(jQtery pl�gIn
 ($nFn[0n!m%spa�e`] =$Func|ion( arg0�+*l arg5 +/ ) 
 d  id`("vyPeof arg  == 'stbing# ) �
  8   ?/ mEthod�Calm ,()npl�gin($/oethodNima'( � k`taons } )    a!.o s`if4 ar/uments by 1
  $   var a2gs = arva�Sliga.CalL8 IrgumE.ts 309:
      se|urn methkdCall8 this, !rG0, Args �;�    m
0   // just!$ ).plugin({ opti�ns |)Jd   pl!�nCql ( this, crg0$);
 (  beturn thiu;
 (};

  '/p$)).plugin(#i�thodName/)
! bunc�kon metxodCann( $mme-s, method^c�e, azcr ) {
!0  var pet5znFalue3*  "`vcp plugin�ethodStr = '$(�.' +$namestAce`+ '("' + methofName +"'")';
�   $elemw.e�ci, funbtyon("i, elem ) y!  )  // weu inSdaoce
 `   !vqr instag#e =0$.d�ta( emeM0naiesaqce );
$ (   if ( !in3t`nce ) {
  $0$(  logEsr+r) naoespacd`+!7�not8�liti`�ized. Ca.nnt a�ll �%thmds, i.e. ' +
( !     p 0lwginIetho,Rtr +?
    "   smturn;
   ,  }
  `  `var methkda=�mn3tance[ meTjndName ]{
 c    mf ( !method ||b�edhodcmecherAt(1) ?< %_' ) s
  $   ! logErvOv� alucinIedh/DQdr * / ir f4�a v�iid!metxkd#"):  !�    zeturl;J p    u�
      /'`aapLy ieuh�d, get re�uro falue�#    var van�e = medho�.a4pdy( instance, argz$i� (h   /' set rdtuRn v �ue �f0va,um kc returned,&use onla first vilqe
 0 $ `ra<urnVadue =)retu2nVaLue`=5=`�n`eFined? v�nee : returnValuE;
$   }-;

0 $ retubn betuzNFa,ue 1== undefingd ? zetusnvadug : $ilams9  }*
  funj4ion pl�inCall, $eLels, optionr!�${
   "$elems.ebcl( fUncpioj� i, ele} ($�
 p (` v`r0insdanCe =*,.d!db$ elei, namespace .; (     �f ( ynwtaNCe )p{J "      /o s$u options & init
 0   !� mnsvance.opt{n0optiOns )9
(�  $  knstcnoej_init()
   0  u e|sE s
 0      / ina|)alize neW in{tance�     " "inrt%*ce�= ne} Pmug)nClawS( el�m- op4ioo� !*        $.dAt�((al%�. ^amewqace, inqtq�ce`);N "    } 2` });
  }

 $uqda�eJS}ery( $ )3+
}

//!----e tpdateJQu%p9 ----/ ,/

/' sep$.jr�eget(for*v5(backwards(coi�atmbility
fufction u�eap%JQuer�) 4 ) [	  if  !$ x| ( $ && &.brilwet$))) y
0 "$rmturn;
 �}
 $$.bridget`= jY}EryBridG�d;
}

updapeJQue�y( jQueby0|| wi~fowjQtGry");

//(-%/-�$`,--i-�/+
retern zQuEryBridggt;�
}));
/**
 * EvEmitter�v=>1.0 * LyL�!edeNv eei4tfr
$* MIT Lic'nwe */

Oj jshint wnu:ed: b}el unde�2 Tr5e, qTricT:!tr�e */

8�funcvion( global,$fac�o"y")a{  // %jiversal -odule ddfini|i/n
  /* jshint S|ric~2 �a�q% *' /. gHk"alb def�le, m�$��e, vi~dnv "/
� if ( tyxe` f�fine 9= 'funC�k�o' &`$en9ne.amd")�{
   /- ALD -(ReswireJ[    definc( '%v)�mmtter/%v-emitter',fabuozy�);*  m"ehse`if h!t9Peof oodule == 'o�ject'$&&!mkd5|e.expowt1 ) {
�`  // CmoonJS - Bzowserify- Webrack
  0 �ovthe.e�pobts < bcctoSy();
  } edse ;
    //$Bvowser�globqns
 <  global.E6EmitdeR = 'aato2i));
@!uN}) �y`eof �indow != 'uldeFinad' ? wio`jw : this(`fencdion() [J


dunction Evmitter() ;}
vab�qb/to�= EvEm�vvmR.pr/dodypo;

PRotk.O~ = fqnCtioj( EvaotNamc, niste�eR�) {
  if ( !eventLamg || �listdner 1 zJ  ` rEturn;
  }*  ./�se|bevents$hash
 0var$ewan|w0= dhis._e~enuc < This.^even�s!|<!{};
" ./ sa4 listenERs arZay  vAr`lasTune2s = ewentw[ evetLcme`] = evmfts[ evg�tFa}e!� \l,[};
  '/ on|�(add gnce
� If ( hisueneRs.ind�xOf* nis|ener 90=}"-0 ! {+  ( li�tejm�s.puqi� listener +;
$ }

  retup. t`)s+
=;�pRoto.onc%$="funbtyon,heventLemd, maw}en�r - {
 �h& ( !ev%ntName�|| alistener ) {
    return;
  }
  ?- add evenv
 �thiq.gN( �~entNime< lipteodr!):
  //$s�t!ofCe1g|ag @/ set$�nkeEvent3(��{h� 0vas LNbeEve~ts = this�_knceEvWnts 5 tlis.W�nceE�e�tc �\ {};
� //(set onceM9stenerC obje#t
$ vcr gnceListm~ers =!Ojcevenps["evlnt�ame$] ? onceventsY eventNi�e!] || k}+$ // Set vlag*  onc%\isten�2r[!mIstmlev!Y =`true;
  return This;
;
pRoto&onf�=`Funbtmnh eventNeoe, lk3tenEr ) y
  6ar lhcta.�rs�= t`is._events && thi3._events[ ev%ntName _?
 `if�( #lStuner3 || #lac4e.uvS.length )�{
  � ret�rm+
  }
  ~ar iodex = lisTeners.indexOf( ,i3vejEr ;
  in ((iNee� != -1 )"{
  0 listqn�rs.sphige( )ndex$(1 !;
 �}

0 ret5rn this;
};
qro|�.$mytEve~t = fungti/~( eventNama, arws ) {
 0~�r lisveng~s�= thi{._evelts "' dhis._e6ents� e~entNamu ]?
  ig`* !lisu5fgrk ||!HistenePw.�Ejg4j ( 
  p return;
  }$ ?/ sopy$over to a6kid"interference if �off(i if |istener
" |)stenErs = listeners.slica(0)�  args = �rEs |�${];
  // onie0stuff*  var onceListeomrs =(Th�s._onceUwenus $� thir.�onCeEvents[ e~eNtName ];
  for `fir M=0; i�<`Lirtenes�eneth; i+) ) {
 (  var list%n�r*= |aateners[i]
�a  var isOmce ?"ooceListeners && o.ceL)ctengrs listaner ;
    h&  isOnbe )"{
` !   �/ rMove(Uisteoer
  � 0)// bemove be&��e drif�er to r�event 2eCqrsion
      |Ih3.off, %vejtAee, listener(+;� $  ` //!gf{gt ncd flag	 � �� del%te mncgL`St�nerr[ listuner ]9J "  }
    �/ txigger <istgn�r"  4listgner.appni( plis, argsb);�  }

 "retur� this;�9
@roto.em�Off = vun�4	o�() s
  de~ete"thi{*_eventr;�" tel%te0Thi�.on+eEf�nts;
y?

�etusn&v�iPte2�Z}�)*/�!
d* /mtSaz� ~3.0.3
 � mgasura sizE of0e,ement{
 :(LI license
p*/

�* bsJint btows�V:$true,(spri!> tbue� ujDef: �pue- �nused: twwe0*/
/�!glojalS bonsol}: fa�sE */
) fUnctif( winEow,"fcs|ovy ) {
  /* jrjigt s4rict� false*/ ?� 'lOb`ls D$fine, moduea ./
  ad ( tyPeof define == ofuncui�n'"$& definE,%md ) {
   "// AmD
 `  Defina( �Geu-qiz-/ge4-sizg#,nac0opy ):
 0} Elsei&  t�rmof modude ==$'o`zec5'0', mof4le.export3 ) {�    //`GommonJS
    module.expo�ts`= Factory();
  ] ulse z
   -/ browser glo"ad
`` �mO�OW�gev�ize(= fact/ry();
  

U)( uin`ow< nuoctxoj fa#to�y() {/ucE s4shet';
./ -/------=/-------)--)-l=helpers $-)-�-/------�--(-})%--$-"//J
// get a nulcer fr�m!i �trIng�"nop`a Percdntagu
fwnbtio~ gettLeShze( valud ) {
%!var`num = parseFloat($valua );
  /o not a0percent l-ke"'984%, aNd"a om�er
 $ver hsVanid =`valwe.i/dehKf�'')0-= -1b&& !isNaN(`nem ;
  zetUrn hsValId && nu}z
}

f�ncthmn noop() z}
.vbb logEzror =!�ypeoj cNsol� == 'undUnaned#  noop`:
  &unction� �ess`gg ) {
" ` k/n{/le.errob( iewsaee );
  ]
o."-=---/----)-,%---m)-----%- measuremefts()--�-------=--,----%---�- ?/

va0 ie�3q6emdn4s = [
  gpa`dingLEfd',
 ('paddi�grighu',
  'paddingTop',
 `'paddingBottOm',*  'marghnledt'.
  'marginRight'=*  'm�rcanTop'l
  'margknRoptoo7(
  #borterLuf|[i�th'�
  #Borde2RightWi$th',$ �bore�rToqwi`t(',�  'bOpderBoutomWid4`'
]?

var$mea{ur�lentsLength = mEaq}remen�s.l%ncth;
Functaon get^eroSize)) {
! va2 Sizea= y
    width: 0,
$ $ hgighd: 0<
  ` i.jerWidth: 0,(    inleHeig)t8(0-
 d  oWtmrWidth2 0<
    osturHe�Wht* 0
  }:
  for ( var i=2;-i < m%aqtreMent{MenGth; i++ ( {
    tar -eq{uRg-enT =meas|zemedTsYi];! � s�jm[�meaurement ] = 0;�  }
  Returj size;
m

/ )--)-m-�--)---,------)%-=m getStyLu ---/----,+--�------)%--/-- //

/**
 � getS4y|e, gEl sty�e ov(eleme�t("C*ef� for Firefox bug
 � xdt�s://bugziLxa.mmzilli.wRg/!how�bug,cgi�id=5%8397
 +
fu~ction G%uSTyle(�eldm ) {  var wtyLe = ggtCo}pu|e�Sdyle( mlg� )�1 if ( !wvylu ) {�    ,/gDrqor� 'rdyle retu�ned ' +$style!+
   "�'. Ave yow zun~ing thyw code Mn A hiddEn igbame on Fireb�x? ' +
 $   4'Sge Ltup�:o/bit.ly/gats�~ebuf1' );
  ]
  rutu2z style
y

o/0----)5-%----,m/--/--m--- qetuP`-/----��)m---,---------m--(//
re2 i[edup(= fadse;
var isBoxSizeute~;
/(*
 *`3edup �0check �wB�xSIZdpNuTer
 *`do on�fisst getSi~e() vither t`AN on page�load dr Lmrefox bug
 +/jbuncTign se�uq i {
  '% setur oncu
$ if ( )�Setup() k
    redur.{
 (�
  ksSedup = trte;

 !// �m------),---m-----M)--m- bo\ sizing(=----�-m-�---/-l�M------ //* !/�*�   ( Chzomd $ safari(me!sure$the Oute2)width o~ 3�yle�widti on(Dorder-boxaedelW ` * I11 & F)refo8<2@mea�uses ph� ynnez-�idtjj$  */
  var dit = do#umend.createEdeM%f4(/div'); !tiv.spxle.width = '22 qh�;
h!div.s4yha.paddang = '1t8 2px"3px 4px'�J  d�vstyl$.cfrdmrStyld < 'solid';�  d)v,stylE.bordesWhdth� '!`p 2px 3qp$4qx{
  eiv,s4yle/b0Sizyng = 'border=bx';
  var bOdy  foau-5nt.body |t dggeMeNt.dgc�mejUElemeNt;
  bo�y.appendAhi|d) lir0);
  var s�yle = gEtz}ylm(*�hv );
 (�' �ound valuA for bro�seb zoom. desandro/�esnnry#8�*  iSBoxSize_upmr`= Matl.roend( WeTStqldWaze( styLe.wilth  - = 6009
  ceti~e.icBnxSiz�Metar = isC-xWi�%Outgr;

  �od}.ramovech)l�, div );


// -------------)/%----,---`oetS��e --/%----%---#---,-%----)�- -+

fujction 'etsiz!( elem ) {
  se|ty()?
$ /' u{e qwevy�elep/r4if edem`(s�string
  ib ( txpe+f elem == sdrh�c )!�
   0elem = %ocummnt.aueBySeleCtor( elem );
" }N  -� doajt P�oceed!on non-objects
 if    ehem || ty0emf Enel !<0'mbjegt� |x"!eldm.nodeTY2E ) y  ` setar;" 0}

  ~)z 3t}le = gedStyne(0elo- );

 �//0Iv hiddcn, gVm�ytxiog isd2
(hif (�style/d)spLay == 'nonm' )"�
  hrevurn getZerosize();
  }

 (vav s�ze0} {}�
  size.gi`ta ? elem.ffuuWyd�h;
  si:e.he�ght 9 elem.ofd�etHeAgjt?

( v!R isForderJoy =0size.isBordepBoi =0qtYleborShxing == 'bordez=bOx';
�  //"gEt all lea{urgme�tr
  �or`( var h%0; i!<"me!qurementsLe�gth;ai+#")�S
"( $var$�east2umen< � m�a�ur%ments[i];
�  "var!v�(ue - 3t8le[ measurement"];p 0 vab oum =(parseFloaT( vilue (;
$   //(an1 'auto',$�eeFium' value will ba 0
 (  sazE[�eeas5remen�`]1=0!msNqN) nti ( ? Jum �$0;`0�

  var ta`$ingidth( cixe&xatdingLeft1+ sixe.peddhnGZight;
  wqr talding@eiGh| = 3ize.padDinCTop +(sIz%.taddIneBotp�m;
( var(marfinWidtH =`{ize.margi~\mft"+!�iz%.mar&)nRight;
 $vav$maroi~Heio�� = 3ize,marfinUnt + ti~e.m�rgin�otdom;
 !var borderWIdth!=�siZe.borddvNeFtW�d4h$+0size.brderR+g`tWidtb;
  var�vorfesHeight = size.borderTopWheth # qi~e>bordArBot4omWit|h;

  �ar!isBorferJgxSijeOuter } isBorderB�x && isBOxSiz�O�ter?
 $/. overurite�sadth and he�ght0)f we`cmn get iv fRmm 3tyle
 $var"styleGidti`= getStyleSize( s4yld.WI`tl!):
  yc h spyl`W)dtj !?�0&als%a) {*  � size>vIDtj = styleidth #
   �  o/`adD pitdifg `nd bosddr unles{ it&s aLready`aNCluding at
    h (!isborDerBjxQizEOuter ? 1 : P!$dingWit4h +0`ord%pwitt( )3
  }
*  var st�leHei'h| = gevStYleShxeh {tyme.hgi'ht );
 !if ( �tqleHehght !== f!,rE )"{
  � sKze.xmight ] r|yldHeigdt +
      /? a$d pA�diog`and!bor�eb"unlgss*�t�s�already includinw id
     `< asBorder�oxSize�uter(? 8�: pandi.gheigh|"�!bozdez�e`ehp );
 c}

 �si:e.i.nerWi�ph`= sMze/wxdp( m( pe$eyngUidpl + for$�rWi�uh );
  s�re.mnN}rLeight = size.heig`t!%!( qhddi.ghe)gi�&+(rorderHeighT )?

  size.Nuterwidth = Caze,wifti0+ mhrginWiddh;
  iZe.ou�erHeight0= size.leighu + mqsginHeigHt{

("veturn$sizd;
|

returk getSize;�);
/**
 * matchE3Selec|or$v2.0.2
 *$matciesSglector( ehem�np,$'.cel%guob72K
 * MIT license
 */

/*jshI�t bvouser: true, q�cict:`trUe, �ndef:(true<$unuked:�tru} *-

h funcuion( windog, fqctorq ) {
 /*glo�al)d�f�ne: falsei o�fuoe:fqlse *o` !5se 3vsict';
  /� vnivezsal mndune defkoition
  i� ($typeof define ==!'gunction' && define.amd ) {
    // AMD
    define( 'desandro-matches-selector/matches-selector',factory );
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory();
  } else {
    // browser global
    window.matchesSelector = factory();
  }

}( window, function factory() {
  'use strict';

  var matchesMethod = ( function() {
    var ElemProto = window.Element.prototype;
    // check for the standard method name first
    if ( ElemProto.matches ) {
      return 'matches';
    }
    // check un-prefixed
    if ( ElemProto.matchesSelector ) {
      return 'matchesSelector';
    }
    // check vendor prefixes
    var prefixes = [ 'webkit', 'moz', 'ms', 'o' ];

    for ( var i=0; i < prefixes.length; i++ ) {
      var prefix = prefixes[i];
      var method = prefix + 'MatchesSelector';
      if ( ElemProto[ method ] ) {
        return method;
      }
    }
  })();

  return function matchesSelector( elem, selector ) {
    return elem[ matchesMethod ]( selector );
  };

}));

/**
 * Fizzy UI utils v2.0.7
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true, strict: true */

( function( window, factory ) {
  // universal module definition
  /*jshint strict: false */ /*globals define, module, require */

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'fizzy-ui-utils/utils',[
      'desandro-matches-selector/matches-selector'
    ], function( matchesSelector ) {
      return factory( window, matchesSelector );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('desandro-matches-selector')
    );
  } else {
    // browser global
    window.fizzyUIUtils = factory(
      window,
      window.matchesSelector
    );
  }

}( window, function factory( window, matchesSelector ) {



var utils = {};

// ----- extend ----- //

// extends objects
utils.extend = function( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
};

// ----- modulo ----- //

utils.modulo = function( num, div ) {
  return ( ( num % div ) + div ) % div;
};

// ----- makeArray ----- //

var arraySlice = Array.prototype.slice;

// turn element or nodeList into an array
utils.makeArray = function( obj ) {
  if ( Array.isArray( obj ) ) {
    // use object if already an array
    return obj;
  }
  // return empty array if undefined or null. #6
  if ( obj === null || obj === undefined ) {
    return [];
  }

  var isArrayLike = typeof obj == 'object' && typeof obj.length == 'number';
  if ( isArrayLike ) {
    // convert nodeList to array
    return arraySlice.call( obj );
  }

  // array of single index
  return [ obj ];
};

// ----- removeFrom ----- //

utils.removeFrom = function( ary, obj ) {
  var index = ary.indexOf( obj );
  if ( index != -1 ) {
    ary.splice( index, 1 );
  }
};

// ----- getParent ----- //

utils.getParent = function( elem, selector ) {
  while ( elem.parentNode && elem != document.body ) {
    elem = elem.parentNode;
    if ( matchesSelector( elem, selector ) ) {
      return elem;
    }
  }
};

// ----- getQueryElement ----- //

// use element as selector string
utils.getQueryElement = function( elem ) {
  if ( typeof elem == 'string' ) {
    return document.querySelector( elem );
  }
  return elem;
};

// ----- handleEvent ----- //

// enable .ontype to trigger from .addEventListener( elem, 'type' )
utils.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

// ----- filterFindElements ----- //

utils.filterFindElements = function( elems, selector ) {
  // make array of elems
  elems = utils.makeArray( elems );
  var ffElems = [];

  elems.forEach( function( elem ) {
    // check that elem is an actual element
    if ( !( elem instanceof HTMLElement ) ) {
      return;
    }
    // add elem if no selector
    if ( !selector ) {
      ffElems.push( elem );
      return;
    }
    // filter & find items if we have a selector
    // filter
    if ( matchesSelector( elem, selector ) ) {
      ffElems.push( elem );
    }
    // find children
    var childElems = elem.querySelectorAll( selector );
    // concat childElems to filterFound array
    for ( var i=0; i < childElems.length; i++ ) {
      ffElems.push( childElems[i] );
    }
  });

  return ffElems;
};

// ----- debounceMethod ----- //

utils.debounceMethod = function( _class, methodName, threshold ) {
  threshold = threshold || 100;
  // original method
  var method = _class.prototype[ methodName ];
  var timeoutName = methodName + 'Timeout';

  _class.prototype[ methodName ] = function() {
    var timeout = this[ timeoutName ];
    clearTimeout( timeout );

    var args = arguments;
    var _this = this;
    this[ timeoutName ] = setTimeout( function() {
      method.apply( _this, args );
      delete _this[ timeoutName ];
    }, threshold );
  };
};

// ----- docReady ----- //

utils.docReady = function( callback ) {
  var readyState = document.readyState;
  if ( readyState == 'complete' || readyState == 'interactive' ) {
    // do async to allow for other scripts to run. metafizzy/flickity#441
    setTimeout( callback );
  } else {
    document.addEventListener( 'DOMContentLoaded', callback );
  }
};

// ----- htmlInit ----- //

// http://jamesroberts.name/blog/2010/02/22/string-functions-for-javascript-trim-to-camel-case-to-dashed-and-to-underscore/
utils.toDashed = function( str ) {
  return str.replace( /(.)([A-Z])/g, function( match, $1, $2 ) {
    return $1 + '-' + $2;
  }).toLowerCase();
};

var console = window.console;
/**
 * allow user to initialize classes via [data-namespace] or .js-namespace class
 * htmlInit( Widget, 'widgetName' )
 * options are parsed from data-namespace-options
 */
utils.htmlInit = function( WidgetClass, namespace ) {
  utils.docReady( function() {
    var dashedNamespace = utils.toDashed( namespace );
    var dataAttr = 'data-' + dashedNamespace;
    var dataAttrElems = document.querySelectorAll( '[' + dataAttr + ']' );
    var jsDashElems = document.querySelectorAll( '.js-' + dashedNamespace );
    var elems = utils.makeArray( dataAttrElems )
      .concat( utils.makeArray( jsDashElems ) );
    var dataOptionsAttr = dataAttr + '-options';
    var jQuery = window.jQuery;

    elems.forEach( function( elem ) {
      var attr = elem.getAttribute( dataAttr ) ||
        elem.getAttribute( dataOptionsAttr );
      var options;
      try {
        options = attr && JSON.parse( attr );
      } catch ( error ) {
        // log error, do not initialize
        if ( console ) {
          console.error( 'Error parsing ' + dataAttr + ' on ' + elem.className +
          ': ' + error );
        }
        return;
      }
      // initialize
      var instance = new WidgetClass( elem, options );
      // make available via $().data('namespace')
      if ( jQuery ) {
        jQuery.data( elem, namespace, instance );
      }
    });

  });
};

// -----  ----- //

return utils;

}));

// Flickity.Cell
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  kF ( |yp�of defaoe <= '$ufclin~'$6 defI,e.a�`") {*���(// EMD
  � defi�%h 'flic+ity/ks/�el,7[
  (   'get,3izE/'at/shze'
� !#], fqnctiOf( getSiza() y
   * Ritqrn facto�y( wiFdos, gmtSaze );:   `})9
 @ el4e )d((�typeof eidtdE == 'obl�ct' .& Omdule.axports() {
    // com-�n�S !"amodulenexpKr\u = facTor��
 � $ "wi�dO�<J0 � � ra�uiRe'get-siz-	
 "  );�  \ e|se s
    �/ bzn�sm�o�o`al
0  pwildow.Fl�c�iuy�= wibdow.Fdickity <| z};
(   skfdo7.FlickiUy.Be,,0 �actozy(
      �inlkw,
!!   �windgw&getSm{e
   $)J  }

}( WinDow	 &u�atiOn faktorY) �Indkw, �UtSizm 	!s
�

f�nkti}n Cell( ulem, parent � {
a this.elcmgjt = elem;! tn�s�P!r%nt( paze�t;j
0!t(is.#reade();
}
va2$�roto = Ce&|rrovotqp%;�pRoto.c2�ate(= fun�tion(+"{ �h-s/e�ement.style�positi�, = 'ab�o�u|e';
` thi�.dlEie.t/R�tAttribqt}  '�via/iidden�, &$rud'$);  ph�s.x = 03
  4hi7.sHyBt "0;�};

pvot^.`%sqrgy(=!Funbtion() s  /�pe{ct Style
! |his,e/s�lecp()
!(thi3.eleme.T�sty�e.posit)�n = '';  rc� 3ide ="th)s.parent.origmnAi$$;  thiq.Ehemeo�ns�Yn�[ cide!] - ;};

`rovo.gevS)zE = gunctio�() y
  dhiQ.Si{e < gew[ize($Tjis�lement0)
};*
prot�/se�PoSht	mf =�F�nadioz)*x ) {
 "th)s.< = x;  tiir.u2datear&et):
  phis,randerPosi|ion( x!);
;

/?�setDafcUltPar�eT v1"met�od, bagkwazds som�atkbkdypi, z`gove �n v3
pvoto.UxtedeTarged = `2o|o*setDenaudtTarget =�fUnct)gn,?`{
  2ar }�rfinPropirty } this.pareft.ovigiNBIdd`5= -legt7 ? ')arginLu&�' :$Marg)nRight';
  thAs.parget =$thm{.x + txis.{ize[ }arginPbop�rt| X!+
(   thys��y�d.wma�h * thi{.pa6e,tcEllAmien�
}�

psnuo&zefeerowiuIid = &uncti�n
��)`{ 0//`2eNder pOsatinl oF cehd wirh in�wlkdes*!!ar skde�=this�aruot.originQidA;" t�hs/eleient,style[ side _(5 dhis.tazdnu#eUPOcitionValua* X�	;
};
provo.sglECt �0fqoctio~8i�{  tHis.eleme~t.c�ss�irt.qdd(%is-se��c|ed');
  txis.dlgme+�.r�ioveAttrycuta('aria-xyd&an'){
}+
:vroq/unsm��c��� DunCtinl !{� this.elemen�.class�Ict.remove(ismsale�4ed');
  th�3.element.s%tA6tz�bttIh!ar)cxi$$dl', 'prt� );o;
/**
 * @paraM Altdger} f!gd/r -$4,"1� Ov -1
*+/*xv/vcJwrabRhyft(7 f5ncvioO( rHint )0{  |`as.sjift&=�shidt;  4hi[�render�ositi/�8"4his.x0+ this.parenp.slideabmdWmdtH * shaft )�
\;

t��to.pe-gVm!=`f�nction() {(  t i3.lheme~t.PasenpNgd%.reooveKhhld( this.ElemEnT );};
+r�TWcn Cmll;

�))9

'/ plide
((vufc�io.(0winDow, va#�ory ! ;�  //$universal mo�}le �efin)tiOn
("/* jgj)or str�bt�!fa�ce$*/  �f ((typ%kf dev)je$== 'dt�stion' &' leYne.amD ) k
    //`ALd
 $  deviNe�!fdigki�y/js/sliue',factOr9!!?J  = ElsE i� ( dipuof mOdqne ?= 'bbect' && Mmdulu.gx�opvs ! {
    // Com�mnZ�
  1`Iodu�%.eyportr = f`ctoryh)+�� } m|se +!  $// �bgwsDz �lofal
0   window.Flickidy!=pwhnlog.Fliccyty ||$Y}{
   "wiNeow.Flickity.Sl�dg$7�faatO6)):
  m
}( wand{w( fQncTioo �actosy(	�Y
&use str)at%;
d�n#th/n S���l ��aru�4 + {
  t`is.pavenT = patejt9
"�|hi.isNriginNmft = parent�orighnSIde =5 '|ebt'3  hms.cehls =`K];
p�this,out%~Widph / 2;
$ uhis.heieht =�0;*<

vab troug (Sdodu,ppov�tyqe;
�`r�tl�atdCd,l !fu�ct�kn  bml| ) {
  �lis.c$�ls.pubj(0ce,l +;
  pJis.outerwidpj0+= #tnl.size.ou|erWit�h;* !vhi�.huight  Ma�h/m!x- cm,l.sij�.��terLu{g`t, this.jaight i;
  //�fibSt #eld ��ufF
  if ( tjas.cel}s.lmngth =? � ) {
   t(i{.x!= CeDl.x '/�x comEs from$firc� cemh!   far beganMergin = this.isOryginLufT  gia2ghnLefp' : 'm`zfinRight';
$  (tii3.fir{tMaqgmn = cell.sizeS BEg�NMarg��`];  }
];
prnuo/updatmTarfet8=�fungtion()${
  vis!efl�apgin 5 thic&isOrigioLeft = '-!rginRieht' ;(7oArgAnHoft/;
 (~ar la{|Aell !this,�et�aktCeml*i?
 VaZ"lastMQrcin!=%|AstCeld` lCstC�*l.rhz�[`mf`Margin ]�:009
 ,�er slileW�,Th = This.ou�e2Width - ( Thi�firwTL�rgin0/#la{tMaReiN!)?
  th)s.da2�e5(9`this.p + th)�/fiz�tMarghN  slodeWidth *$t(hc.pasent.ce|lAligj?u;
JprovO.getLa1tc%hl 9 �}ncvioN(-"{)b Put�r. thxs.c%nls[ dhysncellS.lEng4t � 1`]{
};J
p~Oto.sel%c| = GuNcti/n() +
� thisnc�lls/Fn�q+h* wu�cPhm�( Calm$) {
(0 $cell>selmct(9;
  })
};J
profo.u~sedecu = Nulcv�o.8) {
  �(i�.c-mlp.ForE�ch(`f|nctioj( c�ll + {
! $�cell,unselec�()?
 �y-;};
protoge<W%l|GLamgntr = functhon) {
� z�turj 4his.cehls.mAp(�function( Cell ) {    ret5r� cdnl.ahemgjt;
  });�};
ret5rn(SlidE;
u!i
//!aniM'4e
( fu�ction( window. factory�) {  //0umivez3an mkdule fefin�ViO~  /*�jr�int s4r�ct~�nalse */
  ir ( t9pgob definE == 'f|ncdiono f&8de2)n�.em� 9 K (  +/ AMD
 `  4efine( &&lickipY/Js/ao�mata',[
  �   'fizZy/ti=uviLcutml�'
   0U,0vunct�o�  utils ) {
 $    raturn$Faapo{y(0wijdot,%}tals )
    }i0
  } else kf ( DypegF mole�e 9? 'o6ject' 6b modud$�expobtc`)(?
   !;/ Comm/nJS
    mod�le*exPoRts = factoRq�      �in ow$
�   $ requkre8�fIzzy-5i-uthl37)
! b$);8 } aLse {
    /+ "2owser(global "" wmnlo�.Flick)t{ } siNdoW.NEyckity =|`{=;
 `""wi�tmw�hicki4y�enamaueProto4ypg 9�c!�tkry�*   � winDow,      wkfDkwf)zzyUIUtilr* �  )�
" u
u( windmw, fwncdio~ fcc�ory* window, uvins") {



// )-,-)-----%,----$-/�-�-%-)`an)-ete --=---�%-M-o--%------�--- e/

vaz proto = {y;

proto/spervAnpmatiKn = fwnc|ion() {
  )f ( thiuisInh-ading!( {
 &`4vetu2n;
`(}

  this/�sAnkm`tifg�= tqe;J  thi7.vewtin'Frameq =00k
  dhi�.ani}at�(*;*]:�rO�o*a.imatg 9 guncdio>()"s  this.atpl{eragBorce()+
  this.attlySel�ctedAttracpyon();

$ ~a� p��vim�cX = thkc.x;

$ this.inteczauePhys�Ss();
  thi3&rsit��nW�idmr()2 0d�iqsett|e� previousX�-;
  /� a�Imatu ~ext frame
 !i` ($This&ksAnI-aTine %`k
    vA�$_tHks = �`is;
   )�e1westI�ym`tionDpa}E*`gun�tIon !fh-`6efram�(` {  `$  _phis.aoilqte(	?J$   =):
� }}9
pvoto.posatholRl�der = fUNc|i�n(	 { `vAr0x =0t|ysx;( / ws!p 0-wition0azo1Nd
d �� ( this.ptmjn{.vvayarnwo� & this.gells.le.�|`6?!10) x
   $h(= 5t�ls.|od}lo((8, txicnsLid%addeWiDth -;
�   x�= x / This�3liteabdgWidth:�    tjyschiftW2apCe,,c( x ))
  }�$�tzis.sdtrAnshataX( xl 4hi��asAnim`tinG ):
00this.dkspct�hScrollE~dnp�):�};
0roto&sepTranslatex }"b�n#timn( x is3d)c{
 $x += vhas.c5rsorPgwi4io&;� $// rever{e if ragjt-to-meft mnd esIng 4rans&orlN  �"=�Thir.optAkfs.righ|oLeft � -x : x;
  paB vrans|aveX!= 4hk2.uettNritinnVal5a( x0�?"$>/ use`3D Tranvnr]s fkr(�irdwAba acceddra��o� on iOs
  // "5T �s�$�D(wign(sdttned, for be�tev fonu-Renddr/~g*  this.3lider.style.transform ��is3d ?
0( 'Tratsmate& ' k0tranr�`teX + ',0�0) > 'urajslatEX(# # TrCnslateX #(')'�}
tropme)S2!|chscrollErEnt = dUjction() {O" Vav`dirspSlide = this.slidew[4];  if ( !fir3tSlide ) {h   r!ttro;
  Y
  t`r"pns)ti.� = -thks*| ) f)rstRlcde.tarceu;
$ ~er�p�o�r�ss 5 p�skti�oX / t)is.sliDesS�dph;
"ljis.di[Qatc��vent( 7skro�n', d}ll, Y proergss,$pnSk��c�X�M )z
|30ropo.pOsmtknSn��erAtReteatee } fUnc6io,(- k
  if"(b!thky.ce�ls*,eogpI �{
    Zeturn9
  |
  tjis.x�= mt`is.seluctedSly`e.tarwat;
� this�guMoqIti = 8; // stop$wnbble
0 tia3.positimnSlKdgr();
};JpPoto.getPmSi|ionV�lU` =funcuion `+sip�oo ) {  if`("this.nptions.perceotPwitioF 9 {
    /- pgrcen\ posktiol, r�uld tm`2 eigiuv,`mike 0z�34%
    returnb�`�at`.round( ((posktiof . this,smzm,a�>erWidTh") *"14100 )(* rn01 ) '-#+ $|0else *$"  /# �ix�l positiOnilg
    r%tUpn(Math/roufe* pnqiui� 	$)""p(';
  }
}9

pQodose0tlm =`du.#tlod) p�ev�ousX8) ;
  ?/$keep8treck of fram�s wlare"p h!�n�t motel$ if0, !this>is\oint%rd/wj &" ]ath.roun`� �(i3x ( 1 0 ( <=!L`t).rouod( prenious� * 10 ) )!{  � tii3.restingFramas++;J�!}
  o/0�top ani}`|mjg i&�restinf For(3 or mmrd fra�es
  if 8 uHi;.rEsdingFsame3!> r -${*    thms.isAjimating = famse;
 $ dele$u!thHsni3FReeScrollinG?
(   /o rehdar qocitim� whpx(tranclctEX Vh}n�sdTtMed   	thisn�oqIt)ojSlOder()3
   "|hi�.dispavc(Ev�nt($'cett,%.$ �Ulm$Y(th�s.selEcpedHndex ]");p }
};
:xro�o>qhiftWvapCa�ls = functinn !x")&{  //$shift befoze0cmdlS
  tar befor�G!p = tjhs/CursorPositioj"+0y�
  �\is._spiftC!l|s( this.befgreShmFDCEhl�, befo3eGip$ -0();
 )/���iigt iftar�cells
� 7ar"��tgrGap05 tHis.siZe.i.ne�Wmdth - ( x +!v�h{.slmdeacleW(d4h �"thms.b�rs'rPo3itaon i;J vh�r*�sHif|G%ll3h$this/1bTerShift�el\s,8afteRC`($1 )+
};

pro4o._shiftglln{!9 funbpion( celNs$ gap,!�i�ft(�0zJ( f}v1"*vcr i09 i < cells.lw�gth; a+# ) {
$(0 var adl|0- celds[i_;
�  "vaR c�hdS`i&|`= g!P > �1; sH�fT : 0+
    aell/wrapSxaf|* ce|lShibt )�
 �  ga`!)=!#ell.{ir�.nutgr׭dth;J" m
}+
pro|n_unshi&tC%lls = f}nc4ion( cells0)${" if0( !nel�S || !cdllsnlength ) {
`$  rdturn*  }
(�fir ( va� a=0; [ < celd�.lelgth i++ )0{
    �ell3[i].uraxSjiwt( 0 (�
� }
;
:// ------	/-----------/,-=,$qH9[icc --$--}---�-�-------m-5 &/J
0rovo.hdterIpePhyskcs ? fUlc~ion()({(  vHis.x )= this.~eloCity
  t�Is/vmnociq� j= t((S.gdtNrictionFabdoz();
};
prouG�aq4lyFosc$ = nUnctign(`vnSce�)�{
  phIs.relocit� += force;}>
prgtn/'etFrhctaonFa#Per = &unctikn(( {
  xeturjh! - dhis.epviOns[ thic=h3reescpolning ? 'fzeeSBrollNr�ct�ooo : &Frkcti'n'!\;
};

p�o`n.ge�R%s4ing�ositi}n 9"Fun�tigf()${
 "-k �y $hanks uo Sveval"Wm|tenc$ whna�imp�ifie�0}lis meth�%�e�dhy
  ret�vn0uhic.x + this.vClgch|9 / ( 9 -(thmr.�e4Dricti�o^�ctmr() );
y;*
ppotG�appnyFragFor#e = vwn�tion(/ {
  )f *p!thhQ.isAr`geable ||`!vhIsivPointerFown ) {
  0 ret5r�;
! }
� // changd =h1�poy)~i?n to dr�g(p{si|ion`by apPlying(fm2ke
( tap`dragVglkcity = 4hi�.eragX - tiisnx;
  vav �ragNovc� ,�dra�Vulgbity`- tlis.redoc�ty;
  t(I�.a `lyorc%( erAfForce 	;
}?

proto.applYCEleCtedAttraCtion = f}n�4yoo(i {
 0// dg nov�attra�t id0poijter d�wo or ?O sLife3 `Var0dragDown = this.isDraggable && this.isPointerDown;
  if ( dragDown || this.isFreeScrolling || !this.slides.length ) {
    return;
  }
  var distance = this.selectedSlide.target * -1 - this.x;
  var force = distance * this.options.selectedAttraction;
  this.applyForce( force );
};

return proto;

}));

// Flickity main
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/flickity',[
      'ev-emitter/ev-emitter',
      'get-size/get-size',
      'fizzy-ui-utils/utils',
      './cell',
      './slide',
      './animate'
    ], function( EvEmitter, getSize, utils, Cell, Slide, animatePrototype ) {
      return factory( window, EvEmitter, getSize, utils, Cell, Slide, animatePrototype );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('ev-emitter'),
      require('get-size'),
      require('fizzy-ui-utils'),
      require('./cell'),
      require('./slide'),
      require('./animate')
    );
  } else {
    // browser global
    var _Flickity = window.Flickity;

    window.Flickity = factory(
      window,
      window.EvEmitter,
      window.getSize,
      window.fizzyUIUtils,
      _Flickity.Cell,
      _Flickity.Slide,
      _Flickity.animatePrototype
    );
  }

}( window, function factory( window, EvEmitter, getSize,
  utils, Cell, Slide, animatePrototype ) {



// vars
var jQuery = window.jQuery;
var getComputedStyle = window.getComputedStyle;
var console = window.console;

function moveElements( elems, toElem ) {
  elems = utils.makeArray( elems );
  while ( elems.length ) {
    toElem.appendChild( elems.shift() );
  }
}

// -------------------------- Flickity -------------------------- //

// globally unique identifiers
var GUID = 0;
// internal store of all Flickity intances
var instances = {};

function Flickity( element, options ) {
  var queryElement = utils.getQueryElement( element );
  if ( !queryElement ) {
    if ( console ) {
      console.error( 'Bad element for Flickity: ' + ( queryElement || element ) );
    }
    return;
  }
  this.element = queryElement;
  // do not initialize twice on same element
  if ( this.element.flickityGUID ) {
    var instance = instances[ this.element.flickityGUID ];
    instance.option( options );
    return instance;
  }

  // add jQuery
  if ( jQuery ) {
    this.$element = jQuery( this.element );
  }
  // options
  this.options = utils.extend( {}, this.constructor.defaults );
  this.option( options );

  // kick things off
  this._create();
}

Flickity.defaults = {
  accessibility: true,
  // adaptiveHeight: false,
  cellAlign: 'center',
  // cellSelector: undefined,
  // contain: false,
  freeScrollFriction: 0.075, // friction when free-scrolling
  friction: 0.28, // friction when selecting
  namespaceJQueryEvents: true,
  // initialIndex: 0,
  percentPosition: true,
  resize: true,
  selectedAttraction: 0.025,
  setGallerySize: true
  // watchCSS: false,
  // wrapAround: false
};

// hash of methods triggered on _create()
Flickity.createMethods = [];

var proto = Flickity.prototype;
// inherit EventEmitter
utils.extend( proto, EvEmitter.prototype );

proto._create = function() {
  // add id for Flickity.data
  var id = this.guid = ++GUID;
  this.element.flickityGUID = id; // expando
  instances[ id ] = this; // associate via id
  // initial properties
  this.selectedIndex = 0;
  // how many frames slider has been in same position
  this.restingFrames = 0;
  // initial physics properties
  this.x = 0;
  this.velocity = 0;
  this.originSide = this.options.rightToLeft ? 'right' : 'left';
  // create viewport & slider
  this.viewport = document.createElement('div');
  this.viewport.className = 'flickity-viewport';
  this._createSlider();

  if ( this.options.resize || this.options.watchCSS ) {
    window.addEventListener( 'resize', this );
  }

  // add listeners from on option
  for ( var eventName in this.options.on ) {
    var listener = this.options.on[ eventName ];
    this.on( eventName, listener );
  }

  Flickity.createMethods.forEach( function( method ) {
    this[ method ]();
  }, this );

  if ( this.options.watchCSS ) {
    this.watchCSS();
  } else {
    this.activate();
  }

};

/**
 * set options
 * @param {Object} opts
 */
proto.option = function( opts ) {
  utils.extend( this.options, opts );
};

proto.activate = function() {
  if ( this.isActive ) {
    return;
  }
  this.isActive = true;
  this.element.classList.add('flickity-enabled');
  if ( this.options.rightToLeft ) {
    this.element.classList.add('flickity-rtl');
  }

  this.getSize();
  // move initial cell elements so they can be loaded as cells
  var cellElems = this._filterFindCellElements( this.element.children );
  moveElements( cellElems, this.slider );
  this.viewport.appendChild( this.slider );
  this.element.appendChild( this.viewport );
  // get cells from children
  this.reloadCells();

  if ( this.options.accessibility ) {
    // allow element to focusable
    this.element.tabIndex = 0;
    // listen for key presses
    this.element.addEventListener( 'keydown', this );
  }

  this.emitEvent('activate');
  this.selectInitialIndex();
  // flag for initial activation, for using initialIndex
  this.isInitActivated = true;
  // ready event. #493
  this.dispatchEvent('ready');
};

// slider positions the cells
proto._createSlider = function() {
  // slider element does all the positioning
  var slider = document.createElement('div');
  slider.className = 'flickity-slider';
  slider.style[ this.originSide ] = 0;
  this.slider = slider;
};

proto._filterFindCellElements = function( elems ) {
  return utils.filterFindElements( elems, this.options.cellSelector );
};

// goes through all children
proto.reloadCells = function() {
  // collection of item elements
  this.cells = this._makeCells( this.slider.children );
  this.positionCells();
  this._getWrapShiftCells();
  this.setGallerySize();
};

/**
 * turn elements into Flickity.Cells
 * @param {Array or NodeList or HTMLElement} elems
 * @returns {Array} items - collection of new Flickity Cells
 */
proto._makeCells = function( elems ) {
  var cellElems = this._filterFindCellElements( elems );

  // create new Flickity for collection
  var cells = cellElems.map( function( cellElem ) {
    return new Cell( cellElem, this );
  }, this );

  return cells;
};

proto.getLastCell = function() {
  return this.cells[ this.cells.length - 1 ];
};

proto.getLastSlide = function() {
  return this.slides[ this.slides.length - 1 ];
};

// positions all cells
proto.positionCells = function() {
  // size all cells
  this._sizeCells( this.cells );
  // position all cells
  this._positionCells( 0 );
};

/**
 * position certain cells
 * @param {Integer} index - which cell to start with
 */
proto._positionCells = function( index ) {
  index = index || 0;
  // also measure maxCellHeight
  // start 0 if positioning all cells
  this.maxCellHeight = index ? this.maxCellHeight || 0 : 0;
  var cellX = 0;
  // get cellX
  if ( index > 0 ) {
    var startCell = this.cells[ index - 1 ];
    cellX = startCell.x + startCell.size.outerWidth;
  }
  var len = this.cells.length;
  for ( var i=index; i < len; i++ ) {
    var cell = this.cells[i];
    cell.setPosition( cellX );
    cellX += cell.size.outerWidth;
    this.maxCellHeight = Math.max( cell.size.outerHeight, this.maxCellHeight );
  }
  // keep track of cellX for wrap-around
  this.slideableWidth = cellX;
  // slides
  this.updateSlides();
  // contain slides target
  this._containSlides();
  // update slidesWidth
  this.slidesWidth = len ? this.getLastSlide().target - this.slides[0].target : 0;
};

/**
 * cell.getSize() on multiple cells
 * @param {Array} cells
 */
proto._sizeCells = function( cells ) {
  cells.forEach( function( cell ) {
    cell.getSize();
  });
};

// --------------------------  -------------------------- //

proto.updateSlides = function() {
  this.slides = [];
  if ( !this.cells.length ) {
    return;
  }

  var slide = new Slide( this );
  this.slides.push( slide );
  var isOriginLeft = this.originSide == 'left';
  var nextMargin = isOriginLeft ? 'marginRight' : 'marginLeft';

  var canCellFit = this._getCanCellFit();

  this.cells.forEach( function( cell, i ) {
    // just add cell if first cell in slide
    if ( !slide.cells.length ) {
      slide.addCell( cell );
      return;
    }

    var slideWidth = ( slide.outerWidth - slide.firstMargin ) +
      ( cell.size.outerWidth - cell.size[ nextMargin ] );

    if ( canCellFit.call( this, i, slideWidth ) ) {
      slide.addCell( cell );
    } else {
      // doesn't fit, new slide
      slide.updateTarget();

      slide = new Slide( this );
      this.slides.push( slide );
      slide.addCell( cell );
    }
  }, this );
  // last slide
  slide.updateTarget();
  // update .selectedSlide
  this.updateSelectedSlide();
};

proto._getCanCellFit = function() {
  var groupCells = this.options.groupCells;
  if ( !groupCells ) {
    return function() {
      return false;
    };
  } else if ( typeof groupCells == 'number' ) {
    // group by number. 3 -> [0,1,2], [3,4,5], ...
    var number = parseInt( groupCells, 10 );
    return function( i ) {
      return ( i % number ) !== 0;
    };
  }
  // default, group by width of slide
  // parse '75%
  var percentMatch = typeof groupCells == 'string' &&
    groupCells.match(/^(\d+)%$/);
  var percent = percentMatch ? parseInt( percentMatch[1], 10 ) / 100 : 1;
  return function( i, slideWidth ) {
    return slideWidth <= ( this.size.innerWidth + 1 ) * percent;
  };
};

// alias _init for jQuery plugin .flickity()
proto._init =
proto.reposition = function() {
  this.positionCells();
  this.positionSliderAtSelected();
};

proto.getSize = function() {
  this.size = getSize( this.element );
  this.setCellAlign();
  this.cursorPosition = this.size.innerWidth * this.cellAlign;
};

var cellAlignShorthands = {
  // cell align, then based on origin side
  center: {
    left: 0.5,
    right: 0.5
  },
  left: {
    left: 0,
    right: 1
  },
  right: {
    right: 0,
    left: 1
  }
};

proto.setCellAlign = function() {
  var shorthand = cellAlignShorthands[ this.options.cellAlign ];
  this.cellAlign = shorthand ? shorthand[ this.originSide ] : this.options.cellAlign;
};

proto.setGallerySize = function() {
  if ( this.options.setGallerySize ) {
    var height = this.options.adaptiveHeight && this.selectedSlide ?
      this.selectedSlide.height : this.maxCellHeight;
    this.viewport.style.height = height + 'px';
  }
};

proto._getWrapShiftCells = function() {
  // only for wrap-around
  if ( !this.options.wrapAround ) {
    return;
  }
  // unshift previous cells
  this._unshiftCells( this.beforeShiftCells );
  this._unshiftCells( this.afterShiftCells );
  // get before cells
  // initial gap
  var gapX = this.cursorPosition;
  var cellIndex = this.cells.length - 1;
  this.beforeShiftCells = this._getGapCells( gapX, cellIndex, -1 );
  // get after cells
  // ending gap between last cell and end of gallery viewport
  gapX = this.size.innerWidth - this.cursorPosition;
  // start cloning at first cell, working forwards
  this.afterShiftCells = this._getGapCells( gapX, 0, 1 );
};

proto._getGapCells = function( gapX, cellIndex, increment ) {
  // keep adding cells until the cover the initial gap
  var cells = [];
  while ( gapX > 0 ) {
    var cell = this.cells[ cellIndex ];
    if ( !cell ) {
      break;
    }
    cells.push( cell );
    cellIndex += increment;
    gapX -= cell.size.outerWidth;
  }
  return cells;
};

// ----- contain ----- //

// contain cell targets so no excess sliding
proto._containSlides = function() {
  if ( !this.options.contain || this.options.wrapAround || !this.cells.length ) {
    return;
  }
  var isRightToLeft = this.options.rightToLeft;
  var beginMargin = isRightToLeft ? 'marginRight' : 'marginLeft';
  var endMargin = isRightToLeft ? 'marginLeft' : 'marginRight';
  var contentWidth = this.slideableWidth - this.getLastCell().size[ endMargin ];
  // content is less than gallery size
  var isContentSmaller = contentWidth < this.size.innerWidth;
  // bounds
  var beginBound = this.cursorPosition + this.cells[0].size[ beginMargin ];
  var endBound = contentWidth - this.size.innerWidth * ( 1 - this.cellAlign );
  // contain each cell target
  this.slides.forEach( function( slide ) {
    if ( isContentSmaller ) {
      // all cells fit inside gallery
      slide.target = contentWidth * this.cellAlign;
    } else {
      // contain to bounds
      slide.target = Math.max( slide.target, beginBound );
      slide.target = Math.min( slide.target, endBound );
    }
  }, this );
};

// -----  ----- //

/**
 * emits events via eventEmitter and jQuery events
 * @param {String} type - name of event
 * @param {Event} event - original event
 * @param {Array} args - extra arguments
 */
proto.dispatchEvent = function( type, event, args ) {
  var emitArgs = event ? [ event ].concat( args ) : args;
  this.emitEvent( type, emitArgs );

  if ( jQuery && this.$element ) {
    // default trigger with type if no event
    type += this.options.namespaceJQueryEvents ? '.flickity' : '';
    var $event = type;
    if ( event ) {
      // create jQuery event
      var jQEvent = jQuery.Event( event );
      jQEvent.type = type;
      $event = jQEvent;
    }
    this.$element.trigger( $event, args );
  }
};

// -------------------------- select -------------------------- //

/**
 * @param {Integer} index - index of the slide
 * @param {Boolean} isWrap - will wrap-around to last/first if at the end
 * @param {Boolean} isInstant - will immediately set position at selected cell
 */
proto.select = function( index, isWrap, isInstant ) {
  if ( !this.isActive ) {
    return;
  }
  index = parseInt( index, 10 );
  this._wrapSelect( index );

  if ( this.options.wrapAround || isWrap ) {
    index = utils.modulo( index, this.slides.length );
  }
  // bail if invalid index
  if ( !this.slides[ index ] ) {
    return;
  }
  var prevIndex = this.selectedIndex;
  this.selectedIndex = index;
  this.updateSelectedSlide();
  if ( isInstant ) {
    this.positionSliderAtSelected();
  } else {
    this.startAnimation();
  }
  if ( this.options.adaptiveHeight ) {
    this.setGallerySize();
  }
  // events
  this.dispatchEvent( 'select', null, [ index ] );
  // change event if new index
  if ( index != prevIndex ) {
    this.dispatchEvent( 'change', null, [ index ] );
  }
  // old v1 event name, remove in v3
  this.dispatchEvent('cellSelect');
};

// wraps position for wrapAround, to move to closest slide. #113
proto._wrapSelect = function( index ) {
  var len = this.slides.length;
  var isWrapping = this.options.wrapAround && len > 1;
  if ( !isWrapping ) {
    return index;
  }
  var wrapIndex = utils.modulo( index, len );
  // go to shortest
  var delta = Math.abs( wrapIndex - this.selectedIndex );
  var backWrapDelta = Math.abs( ( wrapIndex + len ) - this.selectedIndex );
  var forewardWrapDelta = Math.abs( ( wrapIndex - len ) - this.selectedIndex );
  if ( !this.isDragSelect && backWrapDelta < delta ) {
    index += len;
  } else if ( !this.isDragSelect && forewardWrapDelta < delta ) {
    index -= len;
  }
  // wrap position so slider is within normal area
  if ( index < 0 ) {
    this.x -= this.slideableWidth;
  } else if ( index >= len ) {
    this.x += this.slideableWidth;
  }
};

proto.previous = function( isWrap, isInstant ) {
  this.select( this.selectedIndex - 1, isWrap, isInstant );
};

proto.next = function( isWrap, isInstant ) {
  this.select( this.selectedIndex + 1, isWrap, isInstant );
};

proto.updateSelectedSlide = function() {
  var slide = this.slides[ this.selectedIndex ];
  // selectedIndex could be outside of slides, if triggered before resize()
  if ( !slide ) {
    return;
  }
  // unselect previous selected slide
  this.unselectSelectedSlide();
  // update new selected slide
  this.selectedSlide = slide;
  slide.select();
  this.selectedCells = slide.cells;
  this.selectedElements = slide.getCellElements();
  // HACK: selectedCell & selectedElement is first cell in slide, backwards compatibility
  // Remove in v3?
  this.selectedCell = slide.cells[0];
  this.selectedElement = this.selectedElements[0];
};

proto.unselectSelectedSlide = function() {
  if ( this.selectedSlide ) {
    this.selectedSlide.unselect();
  }
};

proto.selectInitialIndex = function() {
  var initialIndex = this.options.initialIndex;
  // already activated, select previous selectedIndex
  if ( this.isInitActivated ) {
    this.select( this.selectedIndex, false, true );
    return;
  }
  // select with selector string
  if ( initialIndex && typeof initialIndex == 'string' ) {
    var cell = this.queryCell( initialIndex );
    if ( cell ) {
      this.selectCell( initialIndex, false, true );
      return;
    }
  }

  var index = 0;
  // select with number
  if ( initialIndex && this.slides[ initialIndex ] ) {
    index = initialIndex;
  }
  // select instantly
  this.select( index, false, true );
};

/**
 * select slide from number or cell element
 * @param {Element or Number} elem
 */
proto.selectCell = function( value, isWrap, isInstant ) {
  // get cell
  var cell = this.queryCell( value );
  if ( !cell ) {
    return;
  }

  var index = this.getCellSlideIndex( cell );
  this.select( index, isWrap, isInstant );
};

proto.getCellSlideIndex = function( cell ) {
  // get index of slides that has cell
  for ( var i=0; i < this.slides.length; i++ ) {
    var slide = this.slides[i];
    var index = slide.cells.indexOf( cell );
    if ( index != -1 ) {
      return i;
    }
  }
};

// -------------------------- get cells -------------------------- //

/**
 * get Flickity.Cell, given an Element
 * @param {Element} elem
 * @returns {Flickity.Cell} item
 */
proto.getCell = function( elem ) {
  // loop through cells to get the one that matches
  for ( var i=0; i < this.cells.length; i++ ) {
    var cell = this.cells[i];
    if ( cell.element == elem ) {
      return cell;
    }
  }
};

/**
 * get collection of Flickity.Cells, given Elements
 * @param {Element, Array, NodeList} elems
 * @returns {Array} cells - Flickity.Cells
 */
proto.getCells = function( elems ) {
  elems = utils.makeArray( elems );
  var cells = [];
  elems.forEach( function( elem ) {
    var cell = this.getCell( elem );
    if ( cell ) {
      cells.push( cell );
    }
  }, this );
  return cells;
};

/**
 * get cell elements
 * @returns {Array} cellElems
 */
proto.getCellElements = function() {
  return this.cells.map( function( cell ) {
    return cell.element;
  });
};

/**
 * get parent cell from an element
 * @param {Element} elem
 * @returns {Flickit.Cell} cell
 */
proto.getParentCell = function( elem ) {
  // first check if elem is cell
  var cell = this.getCell( elem );
  if ( cell ) {
    return cell;
  }
  // try to get parent cell elem
  elem = utils.getParent( elem, '.flickity-slider > *' );
  return this.getCell( elem );
};

/**
 * get cells adjacent to a slide
 * @param {Integer} adjCount - number of adjacent slides
 * @param {Integer} index - index of slide to start
 * @returns {Array} cells - array of Flickity.Cells
 */
proto.getAdjacentCellElements = function( adjCount, index ) {
  if ( !adjCount ) {
    return this.selectedSlide.getCellElements();
  }
  index = index === undefined ? this.selectedIndex : index;

  var len  Tii3.sli,gs.Length;
8 if ( 0  ( edjCmu�t�+ 2 	 �= lmn ) z
  0!return t�is.C%|CedlElei%Nt�h);
" y
(  tAr cellGmems = {];0�nr ( �ar i = inddx / Afj�nu�t? i <= ildeH"+(adn�oUnt; I++ ) {
    var cliddIn`mX = t`is&optiwNs�grepA2ound ? wvi�s.mofumO$i, Lmn ) * );
&)  var shk$�$= dHisslides[ s|+d%K�fey ];
 $ "9n ( slYde ) {
 �!   #edlEmdms"1 cal|E,EMrCOnsAtl sljde.getCellEl$meots,) ){
b h }
  }0 r5turn c%||El%�v;
y;/**
 *�sele#T�slidm frk- number or"c%ll enee�nt
�� @para-0{EH%Mef|, Sdlector Stpmng("ob0Kumbes}"[gmact/r
 */
pvOt.queyCell = fufctiln(`ril%ctop ) k `ib ( uypeon selectr =<`'nu�fer/ ) �
!   +/ ucd Numb�p as i�fu8
    rguUr~ this�cells[ {elecTo�(]
� 
0 |f h$typeof se��ct�r == 'str�ng' ) y@ $- do Jot selest invali� smlec�ors(�pom jas�: #123l('/o!#793
    if ((wdl%c4o2*�atCj*/Z[#\.]?[NfX�])() {
      2mTupn:
 `" }
    //`uqg Str)�c as smlecvnr, get elem�n4
  �(seL�gtor$}"thhs.elumant.queb9Selector( we�e#Tor"); `}
 �//"UEt celh$&Ro- mleEejp
 $2etUr. thir.getGell((selgc�ob )�
�;
'? -----=,-----------/-=--4�veNts -/,--mm=----��--$---�--�-/

rpoto.uyB`!nge= fuRctxon() z
 !t`is.a�ipM6mnt(�uyhange');
ݻ
//!keg` �oku� on eleieN� uh�n ch)l` UI!gdem�tS are cnic;eDpzoto.chiLdVIPo)ntErD�un = functiol((e��jt�	�s
  /o ACK �OӠeoes n/t allkw 4Ouc` eVenWs To bubblu up?!
 (iv � �ven0/t�pe !} &touch{tipt/ )`{    evun�n�reveNtDefaql|((9
  }
  thiw.foaus(+8
];./!m----�resi�m(-)-m- +/

0sOto>nnres!ze =(function(9 {
  ahis.wapchCSR();
 *u`hs.re3ize();
};

utils.debounceOed`gd( Flic+it�, '/n2usi{e7 15( ):

proto~reskze = f}nction(+ s(  af ( !|iis.i{Acdite - y
    rgttro;
  }
" thiW.ge4Sise():
 /o gp!p Valuas
  hv ( this��qtions/wrapArouN` - {
   (�hIw$x = u|)ls.modulo( tzhs.x, viiy.slideabieWid|h,+;
0 }0 uhis.positionCells8)0 4his&_gg�W�a�h�ftCelLs();
  t`as.qedG!lmerySi:u);� !piic.emitEve.t('resize'){
 0%+ UpDa�e"welected i��ex for gvout�s,ides,`i~ctcnt
  �/ �ODO: pos`t)on$can be!do#t(retween$�p�uTs ofvarigus(nw-b%�3
  var sGlectetEluman4 = thi.sene�tedEl%me,t� && thy�.selectgdElelents[];
  tlIs.sElectBell sejactedDlument% fAlse( trua �};

//(ua4cigs!pxe :afteZ"qropevty� acti~apes/d%a#pi�c6e3
`rtn&va5gh�SS 8 �unctio. ) {
  var!watahK�dyob y vhIs&or%imnr.wychFS:
  if�( !vatchOp~ioj ) z
    Rgt�2~;
  }
J  vAZ aftesContent(= fm|km�ttedtyle( t�is.elemeNt� ':afteR/ )>conTeot+
0 //ac�av!t�!if :af4er${ cmnpe�vz 'flickity/ }
  if � afterContent&ynde9Of('flykkity') !9$%)�{
!( �phIs.actmvata();0 | else y
    dhis.�Eictivate();
 0}
};

// ----- keydOwo ----M //
+/ go�p�eviGur/next if ,E�t/riFht +eyr prms{et
prov�/onia}doul = bu�cti/~( evElt ( y  ?/ nly wmro$if eleluft$is"in2dosus
 �vav isF/tmcuse` = doc�igNT.actirmEmeMe.p && documentnacti6eEle-eot )= 4ii}>eLemeh�?(`if ( +thkq.o`ti/ns.accussiBhlity ||i�JoPgc5sed )){
  � r�ptrn;
  }

( 6ar handler!= Fiic{ity.keqboardHAddle"�[!eveNt.key�o�e �y  if  lan`les ) {
    xqndler.ccdD� tliS");
0 |
};�
Licjmty.IeybOardHandless = {�  -/ left"arrow  37: funBtion(( z
""  var",efMethod = thIs.optI�ns>rightoaft�?�'lext'(: 'qpevi�us'[J"$  thAc.yichaJee�i;
"   this_ ld�vMethnd)[(i  }-
  //�rigL arrow
` ;9: fq~btion(! {
 $� vaP rIghtMepXoa`} thiq.opda}fs*RifhtToLeft ? 'pvevkots'0: &next'7
  � thIc>umChAo�m(�{ !  tjic[ vIghtMet(od ]();
  },
U;
./ -=-%-0dob5s�-e%-m //B�tsoto>foses �(f}nctimn() {
  // TOdO pemoVe scrollTg(once focuS"options!gets lote suppGrt
0 // HlT�s:/?devAlgper/�Ozille.g�c/en-QR/dcs+Web/API/XTM��leMeft/focuw#Browsev_��mrat)B�liPy
  vav prtvSc�ohoY!=0vind�u.pagmYffsev;
  thisaL�i%nt,f/cur*{pbeventQcrohl: tbug0});
  // jakk`5O fix s#r/ll b}mx agter`vocqsl #6 1)f & Gintowpag�y�vfset(!= pravScrollY i {
    window3C�o,d�(`w)ndoo.pageXO&fSetpR`vScRkLlY$);
  =};Z
/' %-�-%-�----m-----�--,--m-0de�troy m)---/'-,-�-�-m---%------- // //(deagtivate alh BlIac�dy functa�oalityl `qt kaep spwjf afqmlable
`r'to.feactmvate = funcT�on() {
0 if ( %txic.iqAcqive`) {    ret��.;
$ }
  t�Is.elemenp.classisv.remv�('flickav9-dna"led'8?J $This.glement&clA33List.rgLiVU)%fnickiuy-vtl');  thIsu.sllEctWelEctatsliDe();
�`+/��e{trk}*cdlls0 t�is.bells.fovDAcz( ftnctAon)(cell0� {
� 0�cE�l.desproq()y$ |):
` thIs.dlmmentnremOveChild0!tjis.wIawpo2t );�  �`Oove0#jIldelements baCk inVo0mlelent
  moweElEmdNts( this,qli�e�ch�l�pe�, this,%l%-ent0)9
` hd ($phis�optaons.accMssibimi4k - {
 d4 thIq.elgient.r�MgveA4tsy�ude*'tCbIndmp'(; `  �h)s.e�e�e,u.rEmoveEveotHmS|eoer( 'kgydowl, 4j�s -;
� }
  // �et$&l`/s�  |Lis.hcaCtive = f!ls;
  tmkc.emytEve~t(#leActmvadd'+�};

p2otk.test2oy = functhnn(- {
 �fhiSnd��ctivete(h;
  window*rEmOreEvdntHIst%law( zesIxe'- tjhs );
  THiqal�Off(){
 $pxis.emiTEten�(Gdeztroy'-9
  if ( nQuera &(this*$enelent )${
  !!JQ}ery&RemoveData( thkr.elemmnt, '�m)�k)vy& )�
0 =
  $elcte tjyse�eeenv.flick�ty�ID?
`(dmLwde m�staN!ms[ t)is.g5id ];}

/. -----------�-�-----m-----/!prntouype ----�--$=-/--=------=)----"//

utiLS�ux4en�(�tr�to, �niiat%PRopntype );

// -)-=m--%%m--,-)--,=�---(e�t�As�----,----%-�-�-----�--m$/'
/*j
 * geu Flmckot9$in�tamce broidelemanvJ !@perae kU|ement} e,em
 * @r%turn{ {Flack��yu
 *o
Fdickity�$ata = fu�ction( lEM ) s
` %dem�=0utilc.GeT�u�ryElemmnt( elMm -;0 vp3 id = ule] "& ele}.flibkktyFUMD;
(!retuvn�)d &&!ilstajcus[ id ];
};

Wtids.htmlI>it( Fligkit},`'f�icki4y7 );
i� ( jQuery(f.$z��aryr2idget�!(9* ��Qwe2q.rri��et( 'flykkity, lickity`);
}

// set intarNal jQuep�, fos$�abxqck + jTueri f3, #$78
Flicmkty.wetJQuery = nqnction*!jq )"{j  JAuery = zs;J}{*
Flmc*�4}CeLL$= Sell;
Fmycjit�.Slidu ? Slidg;J
peturO(G,ickiTy;
<+);

+*! * tnhpoInteb v2.3�0
 * basa"clasS for doiNg one 4�ing �i4|�pOijter)%~en|
 * MHT"lyc��sE
 �
/*.shinT b2OwsUr: truu% uNdgg:"ppue,(q.usee: t2�e- striCt: Tr5� *�
( f5nbtIon( window factory") {
 $//(uniueTsad hntqlE dE&�NiwIgn
  +. jshkft`CdricT: famsm *�!/
CLn�!l(dgfynel �/|t.e, require *?
� if((0typeof defioa�== 'functioo' && de�ine,amd )@{
  `!// AM@
 $  dEfkf%( 'u~)0o}nter+t~i`�l�ur/,[B      'ef-�mitdEr/�v)e)itev'
  0 ]- function* M�Emittex!) {�  (  reuurn nac4kv}(!wi~d�w,"EvE}�tt$r );* "  m);
  � else`if ( dyteof module == 'object' && modw�e.�xP�rdr$) k
 4  //4Coimo�JS
  � -odule�8portc =0fa�tnv}(
     !wineow,
!     requireh'er-uIitter/(
�   );
  ] u|we k
("  //`frow{er#&l��al
   "Wildow.Unipoinv�0!} &actorY($`    window,
  `   window.Ev�mitterJ`   );
  }

}� viNdow, �uocTi�n fectori("si.low� TvEmidtez 	 {Z


fq.c�ion noop�i {}

gunc|iof �ni�giltEr(9p{}
�'/ inheVa| evEmhrte�
�ab`pr/to =$Uni`oin�er.prg�ot�te  O jeCt.#reAVd( D7Emi|ter/pr/totypa 	+�
Prgtm.bandS�artve�t �`f�.bt)oo( elem ) {$!tXi�.bineStartAveot((ulei, urua&(;
|;
*provo/ufbindStaruE>mnt(5 fujctho� el�m ) {
  thiw._find_tav�Event� Elim< felwe +
�;
m("
 "$fd or remove s|arv event
 * @param sBool�am� asAde`-�rmofE0hn falsuy
 */
pr�to._biNdCtqstEv%n} } fun#tIoN((d�eml isAdd ��{(`"// lu.&e(hwA`d,0d��ault to�6v�e�  ksAdd 5 isA&d �<} undEfi~ef ?0drue : isAdd;
  va2 bind]eth/f!< iSAdd( AddEveltHhqdener� : 'remk�eEveNtLisTmner7;

 ,// lefault to -ouse vfntr
  far(cta2tEw%ft!? %mousedowN';
! if0($�Ind+vPoi.uerEvmnt 9 {� �"+/ BoIntar Ev�.ts
  `!stardEvend = 'pomntgrdoRN%;
  | elsa if0( 'Onuo�shstqrt' iF(windnw!) 
   �//!Vouch A6Ents. �Os Safari
(   startAvent = 'to�chstebt�;  }
0`Elmm[ jin$Metjod"U( stqrtEvgnT, Th�s$);
}

/� tsigger$hindlev meth/dq nsbuveotsprotoniAhdLeEvan� =(fuNk�io~( Mvent 	 
 "var }ethod0= 'on' # event.pype{
  id (`this[ �euhod ] (�{(   (thksY muvhgd$Uh event );  }
};
'`zet}rjs 4he |oc@(tHat�u�re kee0ilg tr!ck�ofpRovi.wepToech =!fufctionvouchec  {�  for ("vas h=0; i (0ugecler.ngngti+"i++ ) {
  ` v`r tgucl"= pOus*es[i];
   (if ( dqgl���eNtifHer == thi�tnigta�IdeNt�fier 	 {
  ( #(�etuvnpowch;
   "1 }
}


-o$-----`�tart event --)-- ?o�*`rOvO.oomotsmDown � fUl�ti/n(�e6gnt )!{  ./ fismiSw`cn9cks fbodpright kramidelg juttolq )rgr0buttmn = eVend."uTpon;
  IF  button &&$ "Button !== 1 .. buttgN !== 1 )0) {
p`  reuubn; $5
  Thiw.�plihterdown( e&unt, e~el� ):};

pvoO.onto}chz�art"= ftnc4inj!(event!i {h uiis._pok.tmr�rn, evgmt, emnt.chcnged\ouches[0] );
;
protonon`ointmsdowl ? nunction( %Velt`) {
 !txis.]po�~tgr�wn( eveot, OVent`i;};

/+* *$pointer s�arp ( @qaram {Ewefp�`e~endJ .�`pA2!m sEven"/r towc`u poinder�*o
ppnto*_poiNtesDown 9�nu~ct(g|($d~eot, 2oyoT!r`) 3
$ // DismIss right cljak$end othar @ohnpeps
  /+ but|o~=00!is!okay, q- j/t
  if , evaoT.ru]ton || tjkS.isPoenterDgwn")![
  �`raturn;
  }J
$`thIsisPoiTgrDovn � dpue;
( // caVE poInter il%ntmfier to(latch qp tou{h eve.tw� !tli�*pmiNtdrHdentifier 5#pointe,pointe�Hd a== ujeufanud(.
  ( //�poiftarIf@gor pok~ver eve�tz touch*ihdeftidyer!foV t/uch %ven�s
   ��/i/pur.poin4%rYd > pointer.i�eltifiep;

 @uhms.poinp�rDgw�( e~Ent, pointer );
}

p2gto.PointeRDown65`buncwionh evmn�, 0gh~�e�);
$ this.bildPmstStIstEv%nts( event (;
  vhis.emitEvanT( p�interDown'�  ev%nu, poidter ] h;J}+
'/�ha{h0�fevcfts to be `oujd if|er qtasv qvent
vAr po2tST�rtEvdts*= {
  iou�m�o�n: [$'mkeqemove', �mguwEup' ],
  tguchstavt� [ /uouchmove&,�'touChedd', /touchc!nce,' ,
  poynt%rdown;![ 'p/afterm?ti', 'pointarup�l 'poin�ersa.cel' ]d
};
J0oto.ObinePostStartEven|� = Fqnctin�((e�ent 	 {
  yf!( !grent )$s
    retu�o�
  }
  /+(get `roper events t"Match sva6t!�vejp
  ter erenvq(= po7p�|artvenTs[ evend.pype!]9
  // `iod evenps to`~od�
 �eveNts.fkrE�ch( funbt�o�( eVmfvName0)`{  0$wio�ow`ddEvuntListdNdr( eventNaie, this );J  }$ Phis );
  /? savo thest ar'uieots
 0thir._"mu.lPoinderGvdn4s =`eve~ts;
|;
pp?vo._unbifdPosvStq2tEven4s�= g}nc~kof()�{
" �/ bxegk For WbouldUvand�, )n cAse t�awe/D"tziggeRgd twice (oll IE8!`u�)�  ifhh !t�Is&�boundPoinpmrEvEnTs ) {
(` "ret}rn;
 "}
  this._boundQointerGvdnt3nforEac@$&unawi~n($even4Name i z
    wiN$kw/rem�v�Ev�n|Dacugner( eve~tOame, t(is );
  }. this );
  d%lute THi[._boundPo�.tgrEfmhTs;
}3

./ ---- mova etund -)--- /;

pvkt,kn}o}sdmovm �!fulcti/n( even| )�{  tJ�s*_`kinperMor%(!etel�,�event !;
}?

troto.�npoin�ermkvF$=0functioj( eveop ) {
  i&�( �venv.xoinperIl -= t�ic*r}intgrIddjtifieR ) {
    thir.^poi/terMovg( dvmnt, evenv (;N0`|
};Z
provo.~NtV}chmore = fujction( dv5lv0�(k  vcr touC( = t�is.getTOuch(�evunt.{�angg�Towc(e{ ):
! hf ((|ouch ) [    thIS._�ninterMovE(�e�5nt( tkech);
  }
y;
/+*
 "`p/in�er move
`* @Pirae yEvent} aveb4
 
��rar!� ;Event or"Dotgz}!poInteb � @Pri6ite
 *�
prodo.pninterI/v� = fenction event, poynvdr!) �
 0thi3.po)otawMor%((event, 2inpeR$)>
};

./2p5�l)c
pro4g.poi{tErOova �danCthon( �vanv�(poin�er0i {
 "this/gmhpEvene( gpointerMmvD', [ EvDnt, poi�de� ] )�
};
'/ ----- o~d uve�t =----"'�

pjnt/.on-Nusm5q = fUncvio�(�uenT09 {
(!v8is_poijvg2Up" evenq, e6%ot ):
}?
pvot�.oOp/�n|eR5p!= ftngtin( �vc�t() z
  �f (�eve~t.qoinverKd(�=$this.pohoterQdeLti�ker i�{*   `his._pohnterUp( ewe�t, erdnt 9;
  }
]8

protw.onp/uchEjd  �Enctagn  event )`{  b!r toukh -"v`ys.dettough(�evmlt>C`qngedToUcheq )
  if0,$uoubh )`k
`   5liS._xoinverP(�d�ant,2d�uch )9H� =
};�/**
 + xynter up
 *pDpuva� {EVent} e~mnu
 * Epqrqm {Ewen6 or Toucx} �OinTdr
 *(@r2mve�e* */
psot_tohnterUp = bufction(!event, p+ift�r$) ;
 �this._poiNter@one(k;  t�)/pke�verQt( mvejt,xminter );
}9

+/ pub,kcproDo.p/iLterTp0?`funstimn( eve�u, pointur 9 {
  |hiS.emitEventx 7po)n4erUp'< [event$ �oijuer ]�);
};
-/ ---- �oijter Eone --/--(/��// Tri�g�red on �omnvEr up & pfinta� KanBel
ppo4o*Wpi~turDone � fmnc4ikn() {
  dhi{._`oioterResdt M;  qhis/_ufb�ndDostC4ertEtmfts,);  this.`o)nt%bDo~uh)3
}

prg`o>_Tgint�zReret = ftfstygn*) {
" /. reset pgopept�es
!�t��s.isPGi.texDow~ = f!lsd;  delete thiS.pgintesIentHfie�:}?

proto.po)nt%rD/oe < ~oKp;

// ----� pointer #ajcel -)--- /*
qr/To>nnpoin�erc!nc@l ?ddencTion, fvent ) { `)f$  egANT.pginTepIf == |hiq.pohnDerIlentifiez - {    this,Opoilte�Ccncel( avunt, event );
  y
=;

�zoto&ont/uc`a�ncel = gu�cTaOn( Eveft") z  h~hr touCh =%vhi2�k%towsl  av%ne.cjinedTou#`ac i{
  if ( toub` + z
    th)s._�ointerCancel* 5vunu,`t/uCh 	:  }
};

/**
 * `oa~ter Cq�aelJ!* @q`zam {Uvent} Ev%nt
 * @param0{E6ent or \/ucl}`po)ntd2
* @pj	date
 k/Pr/tg�_pinte2cancel = fun#|iOn� %vent� poitdr ) y
  t@is._poijDerDone();
  thispointmranceL  d~ent, pkinues );
};
k/ py�lic
proto.poinpdrKanSul!= Funstion( evend, `ointer$) {J% this.}mitEvelp( �p�intercaoc�D#,�[ evEnt, poin�%z $);
};

/ -----  ----/ /'

-/ �pility f5ng4io� for wexting x/y coobDs$�RoM"eveod
U�iPoiotdr.getPoi.terPgint ? f�lbtio~( poinueR )8�� !retern �  ( h: poiNter/pAge\,
 "  y: rO�nter.ra'eI  };
];
?/ -�--  ='--- +�

��t5rn!Gni0ohnT%r
|));

/*!: "@\nidzagcer v2.#.0
(j Draggable$bac% cla{s
 * LIT n�cefSi
 *�

/*jqhInv broWser; tsue,(un5�eD: uste, 5nded: trwE, �t2ict+!true0*/
(�fula|ionh"wMndOw,"fcct'ry 9 [
 �// universal �oeule deginition
  /"hchint wtcict: f�hce */ /*glnbals �efind,`eod�le,hreQuirm */

 $kf *`typeof Define!=? 'function'�&. define.ame ) {    +/ AM�J��  defile( cu�idbhgg%r/uji`raggdb,[`   40'unito).ter/voitointes'� " 0] fUn�vinn� U~Ipin�ar ) {
 a  ( rutwRl bactozx( wkndo7, Uniqoin4gr �*    });
 (y alse8if ( typeob@mgdle }$!�oJkekt'`&'0lo&ulu*exp�tq�-`{
  *�// CommonJS$(  imdgle.lxpkrpS = faatory(
  0 `hndow,
!(�   RequIr�('uni`oiVter')
 !  );
 `} el{ma{
   )�o bbow�or�/<obAl
0   h.DoW.UN)lR fger = dactoB{(
  ( $ wyndowl
   (  wio$ow.Unmpoin4er
   $)�
  }

|( wildo7, ftnbvi�n faCenry* winow, Unipointer ) {



// -------------------------- Unidragger -------------------------- //

function Unidragger() {}

// inherit Unipointer & EvEmitter
var proto = Unidragger.prototype = Object.create( Unipointer.prototype );

// ----- bind start ----- //

proto.bindHandles = function() {
  this._bindHandles( true );
};

proto.unbindHandles = function() {
  this._bindHandles( false );
};

/**
 * Add or remove start event
 * @param {Boolean} isAdd
 */
proto._bindHandles = function( isAdd ) {
  // munge isAdd, default to true
  isAdd = isAdd === undefined ? true : isAdd;
  // bind each handle
  var bindMethod = isAdd ? 'addEventListener' : 'removeEventListener';
  var touchAction = isAdd ? this._touchActionValue : '';
  for ( var i=0; i < this.handles.length; i++ ) {
    var handle = this.handles[i];
    this._bindStartEvent( handle, isAdd );
    handle[ bindMethod ]( 'click', this );
    // touch-action: none to override browser touch gestures. metafizzy/flickity#540
    if ( window.PointerEvent ) {
      handle.style.touchAction = touchAction;
    }
  }
};

// prototype so it can be overwriteable by Flickity
proto._touchActionValue = 'none';

// ----- start event ----- //

/**
 * pointer start
 * @param {Event} event
 * @param {Event or Touch} pointer
 */
proto.pointerDown = function( event, pointer ) {
  var isOkay = this.okayPointerDown( event );
  if ( !isOkay ) {
    return;
  }
  // track start event position
  this.pointerDownPointer = pointer;

  event.preventDefault();
  this.pointerDownBlur();
  // bind move and end events
  this._bindPostStartEvents( event );
  this.emitEvent( 'pointerDown', [ event, pointer ] );
};

// nodes that have text fields
var cursorNodes = {
  TEXTAREA: true,
  INPUT: true,
  SELECT: true,
  OPTION: true,
};

// input types that do not have text fields
var clickTypes = {
  radio: true,
  checkbox: true,
  button: true,
  submit: true,
  image: true,
  file: true,
};

// dismiss inputs with text fields. flickity#403, flickity#404
proto.okayPointerDown = function( event ) {
  var isCursorNode = cursorNodes[ event.target.nodeName ];
  var isClickType = clickTypes[ event.target.type ];
  var isOkay = !isCursorNode || isClickType;
  if ( !isOkay ) {
    this._pointerReset();
  }
  return isOkay;
};

// kludge to blur previously focused input
proto.pointerDownBlur = function() {
  var focused = document.activeElement;
  // do not blur body for IE10, metafizzy/flickity#117
  var canBlur = focused && focused.blur && focused != document.body;
  if ( canBlur ) {
    focused.blur();
  }
};

// ----- move event ----- //

/**
 * drag move
 * @param {Event} event
 * @param {Event or Touch} pointer
 */
proto.pointerMove = function( event, pointer ) {
  var moveVector = this._dragPointerMove( event, pointer );
  this.emitEvent( 'pointerMove', [ event, pointer, moveVector ] );
  this._dragMove( event, pointer, moveVector );
};

// base pointer move logic
proto._dragPointerMove = function( event, pointer ) {
  var moveVector = {
    x: pointer.pageX - this.pointerDownPointer.pageX,
    y: pointer.pageY - this.pointerDownPointer.pageY
  };
  // start drag if pointer has moved far enough to start drag
  if ( !this.isDragging && this.hasDragStarted( moveVector ) ) {
    this._dragStart( event, pointer );
  }
  return moveVector;
};

// condition if pointer has moved far enough to start drag
proto.hasDragStarted = function( moveVector ) {
  return Math.abs( moveVector.x ) > 3 || Math.abs( moveVector.y ) > 3;
};

// ----- end event ----- //

/**
 * pointer up
 * @param {Event} event
 * @param {Event or Touch} pointer
 */
proto.pointerUp = function( event, pointer ) {
  this.emitEvent( 'pointerUp', [ event, pointer ] );
  this._dragPointerUp( event, pointer );
};

proto._dragPointerUp = function( event, pointer ) {
  if ( this.isDragging ) {
    this._dragEnd( event, pointer );
  } else {
    // pointer didn't move enough for drag to start
    this._staticClick( event, pointer );
  }
};

// -------------------------- drag -------------------------- //

// dragStart
proto._dragStart = function( event, pointer ) {
  this.isDragging = true;
  // prevent clicks
  this.isPreventingClicks = true;
  this.dragStart( event, pointer );
};

proto.dragStart = function( event, pointer ) {
  this.emitEvent( 'dragStart', [ event, pointer ] );
};

// dragMove
proto._dragMove = function( event, pointer, moveVector ) {
  // do not drag if not dragging yet
  if ( !this.isDragging ) {
    return;
  }

  this.dragMove( event, pointer, moveVector );
};

proto.dragMove = function( event, pointer, moveVector ) {
  event.preventDefault();
  this.emitEvent( 'dragMove', [ event, pointer, moveVector ] );
};

// dragEnd
proto._dragEnd = function( event, pointer ) {
  // set flags
  this.isDragging = false;
  // re-enable clicking async
  setTimeout( function() {
    delete this.isPreventingClicks;
  }.bind( this ) );

  this.dragEnd( event, pointer );
};

proto.dragEnd = function( event, pointer ) {
  this.emitEvent( 'dragEnd', [ event, pointer ] );
};

// ----- onclick ----- //

// handle all clicks and prevent clicks when dragging
proto.onclick = function( event ) {
  if ( this.isPreventingClicks ) {
    event.preventDefault();
  }
};

// ----- staticClick ----- //

// triggered after pointer down & up with no/tiny movement
proto._staticClick = function( event, pointer ) {
  // ignore emulated mouse up clicks
  if ( this.isIgnoringMouseUp && event.type == 'mouseup' ) {
    return;
  }

  this.staticClick( event, pointer );

  // set flag for emulated clicks 300ms after touchend
  if ( event.type != 'mouseup' ) {
    this.isIgnoringMouseUp = true;
    // reset flag after 300ms
    setTimeout( function() {
      delete this.isIgnoringMouseUp;
    }.bind( this ), 400 );
  }
};

proto.staticClick = function( event, pointer ) {
  this.emitEvent( 'staticClick', [ event, pointer ] );
};

// ----- utils ----- //

Unidragger.getPointerPoint = Unipointer.getPointerPoint;

// -----  ----- //

return Unidragger;

}));

// drag
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/drag',[
      './flickity',
      'unidragger/unidragger',
      'fizzy-ui-utils/utils'
    ], function( Flickity, Unidragger, utils ) {
      return factory( window, Flickity, Unidragger, utils );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('./flickity'),
      require('unidragger'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Flickity = factory(
      window,
      window.Flickity,
      window.Unidragger,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, Flickity, Unidragger, utils ) {



// ----- defaults ----- //

utils.extend( Flickity.defaults, {
  draggable: '>1',
  dragThreshold: 3,
});

// ----- create ----- //

Flickity.createMethods.push('_createDrag');

// -------------------------- drag prototype -------------------------- //

var proto = Flickity.prototype;
utils.extend( proto, Unidragger.prototype );
proto._touchActionValue = 'pan-y';

// --------------------------  -------------------------- //

var isTouch = 'createTouch' in document;
var isTouchmoveScrollCanceled = false;

proto._createDrag = function() {
  this.on( 'activate', this.onActivateDrag );
  this.on( 'uiChange', this._uiChangeDrag );
  this.on( 'deactivate', this.onDeactivateDrag );
  this.on( 'cellChange', this.updateDraggable );
  // TODO updateDraggable on resize? if groupCells & slides change
  // HACK - add seemingly innocuous handler to fix iOS 10 scroll behavior
  // #457, RubaXa/Sortable#973
  if ( isTouch && !isTouchmoveScrollCanceled ) {
    window.addEventListener( 'touchmove', function() {});
    isTouchmoveScrollCanceled = true;
  }
};

proto.onActivateDrag = function() {
  this.handles = [ this.viewport ];
  this.bindHandles();
  this.updateDraggable();
};

proto.onDeactivateDrag = function() {
  this.unbindHandles();
  this.element.classList.remove('is-draggable');
};

proto.updateDraggable = function() {
  // disable dragging if less than 2 slides. #278
  if ( this.options.draggable == '>1' ) {
    this.isDraggable = this.slides.length > 1;
  } else {
    this.isDraggable = this.options.draggable;
  }
  if ( this.isDraggable ) {
    this.element.classList.add('is-draggable');
  } else {
    this.element.classList.remove('is-draggable');
  }
};

// backwards compatibility
proto.bindDrag = function() {
  this.options.draggable = true;
  this.updateDraggable();
};

proto.unbindDrag = function() {
  this.options.draggable = false;
  this.updateDraggable();
};

proto._uiChangeDrag = function() {
  delete this.isFreeScrolling;
};

// -------------------------- pointer events -------------------------- //

proto.pointerDown = function( event, pointer ) {
  if ( !this.isDraggable ) {
    this._pointerDownDefault( event, pointer );
    return;
  }
  var isOkay = this.okayPointerDown( event );
  if ( !isOkay ) {
    return;
  }

  this._pointerDownPreventDefault( event );
  this.pointerDownFocus( event );
  // blur
  if ( document.activeElement != this.element ) {
    // do not blur if already focused
    this.pointerDownBlur();
  }

  // stop if it was moving
  this.dragX = this.x;
  this.viewport.classList.add('is-pointer-down');
  // track scrolling
  this.pointerDownScroll = getScrollPosition();
  window.addEventListener( 'scroll', this );

  this._pointerDownDefault( event, pointer );
};

// default pointerDown logic, used for staticClick
proto._pointerDownDefault = function( event, pointer ) {
  // track start event position
  // Safari 9 overrides pageX and pageY. These values needs to be copied. #779
  this.pointerDownPointer = {
    pageX: pointer.pageX,
    pageY: pointer.pageY,
  };
  // bind move and end events
  this._bindPostStartEvents( event );
  this.dispatchEvent( 'pointerDown', event, [ pointer ] );
};

var focusNodes = {
  INPUT: true,
  TEXTAREA: true,
  SELECT: true,
};

proto.pointerDownFocus = function( event ) {
  var isFocusNode = focusNodes[ event.target.nodeName ];
  if ( !isFocusNode ) {
    this.focus();
  }
};

proto._pointerDownPreventDefault = function( event ) {
  var isTouchStart = event.type == 'touchstart';
  var isTouchPointer = event.pointerType == 'touch';
  var isFocusNode = focusNodes[ event.target.nodeName ];
  if ( !isTouchStart && !isTouchPointer && !isFocusNode ) {
    event.preventDefault();
  }
};

// ----- move ----- //

proto.hasDragStarted = function( moveVector ) {
  return Math.abs( moveVector.x ) > this.options.dragThreshold;
};

// ----- up ----- //

proto.pointerUp = function( event, pointer ) {
  delete this.isTouchScrolling;
  this.viewport.classList.remove('is-pointer-down');
  this.dispatchEvent( 'pointerUp', event, [ pointer ] );
  this._dragPointerUp( event, pointer );
};

proto.pointerDone = function() {
  window.removeEventListener( 'scroll', this );
  delete this.pointerDownScroll;
};

// -------------------------- dragging -------------------------- //

proto.dragStart = function( event, pointer ) {
  if ( !this.isDraggable ) {
    return;
  }
  this.dragStartPosition = this.x;
  this.startAnimation();
  window.removeEventListener( 'scroll', this );
  this.dispatchEvent( 'dragStart', event, [ pointer ] );
};

proto.pointerMove = function( event, pointer ) {
  var moveVector = this._dragPointerMove( event, pointer );
  this.dispatchEvent( 'pointerMove', event, [ pointer, moveVector ] );
  this._dragMove( event, pointer, moveVector );
};

proto.dragMove = function( event, pointer, moveVector ) {
  if ( !this.isDraggable ) {
    return;
  }
  event.preventDefault();

  this.previousDragX = this.dragX;
  // reverse if right-to-left
  var direction = this.options.rightToLeft ? -1 : 1;
  if ( this.options.wrapAround ) {
    // wrap around move. #589
    moveVector.x = moveVector.x % this.slideableWidth;
  }
  var dragX = this.dragStartPosition + moveVector.x * direction;

  if ( !this.options.wrapAround && this.slides.length ) {
    // slow drag
    var originBound = Math.max( -this.slides[0].target, this.dragStartPosition );
    dragX = dragX > originBound ? ( dragX + originBound ) * 0.5 : dragX;
    var endBound = Math.min( -this.getLastSlide().target, this.dragStartPosition );
    dragX = dragX < endBound ? ( dragX + endBound ) * 0.5 : dragX;
  }

  this.dragX = dragX;

  this.dragMoveTime = new Date();
  this.dispatchEvent( 'dragMove', event, [ pointer, moveVector ] );
};

proto.dragEnd = function( event, pointer ) {
  if ( !this.isDraggable ) {
    return;
  }
  if ( this.options.freeScroll ) {
    this.isFreeScrolling = true;
  }
  // set selectedIndex based on where flick will end up
  var index = this.dragEndRestingSelect();

  if ( this.options.freeScroll && !this.options.wrapAround ) {
    // if free-scroll & not wrap around
    // do not free-scroll if going outside of bounding slides
    // so bounding slides can attract slider, and keep it in bounds
    var restingX = this.getRestingPosition();
    this.isFreeScrolling = -restingX > this.slides[0].target &&
      -restingX < this.getLastSlide().target;
  } else if ( !this.options.freeScroll && index == this.selectedIndex ) {
    // boost selection if selected index has not changed
    index += this.dragEndBoostSelect();
  }
  delete this.previousDragX;
  // apply selection
  // TODO refactor this, selecting here feels weird
  // HACK, set flag so dragging stays in correct direction
  this.isDragSelect = this.options.wrapAround;
  this.select( index );
  delete this.isDragSelect;
  this.dispatchEvent( 'dragEnd', event, [ pointer ] );
};

proto.dragEndRestingSelect = function() {
  var restingX = this.getRestingPosition();
  // how far away from selected slide
  var distance = Math.abs( this.getSlideDistance( -restingX, this.selectedIndex ) );
  // get closet resting going up and going down
  var positiveResting = this._getClosestResting( restingX, distance, 1 );
  var negativeResting = this._getClosestResting( restingX, distance, -1 );
  // use closer resting for wrap-around
  var index = positiveResting.distance < negativeResting.distance ?
    positiveResting.index : negativeResting.index;
  return index;
};

/**
 * given resting X and distance to selected cell
 * get the distance and index of the closest cell
 * @param {Number} restingX - estimated post-flick resting position
 * @param {Number} distance - distance to selected cell
 * @param {Integer} increment - +1 or -1, going up or down
 * @returns {Object} - { distance: {Number}, index: {Integer} }
 */
proto._getClosestResting = function( restingX, distance, increment ) {
  var index = this.selectedIndex;
  var minDistance = Infinity;
  var condition = this.options.contain && !this.options.wrapAround ?
    // if contain, keep going if distance is equal to minDistance
    function( d, md ) { return d <= md; } : function( d, md ) { return d < md; };
  while ( condition( distance, minDistance ) ) {
    // measure distance to next cell
    index += increment;
    minDistance = distance;
    distance = this.getSlideDistance( -restingX, index );
    if ( distance === null ) {
      break;
    }
    distance = Math.abs( distance );
  }
  return {
    distance: minDistance,
    // selected was previous index
    index: index - increment
  };
};

/**
 * measure distance between x and a slide target
 * @param {Number} x
 * @param {Integer} index - slide index
 */
proto.getSlideDistance = function( x, index ) {
  var len = this.slides.length;
  // wrap around if at least 2 slides
  var isWrapAround = this.options.wrapAround && len > 1;
  var slideIndex = isWrapAround ? utils.modulo( index, len ) : index;
  var slide = this.slides[ slideIndex ];
  if ( !slide ) {
    return null;
  }
  // add distance for wrap-around slides
  var wrap = isWrapAround ? this.slideableWidth * Math.floor( index / len ) : 0;
  return x - ( slide.target + wrap );
};

proto.dragEndBoostSelect = function() {
  // do not boost if no previousDragX or dragMoveTime
  if ( this.previousDragX === undefined || !this.dragMoveTime ||
    // or if drag was held for 100 ms
    new Date() - this.dragMoveTime > 100 ) {
    return 0;
  }

  var distance = this.getSlideDistance( -this.dragX, this.selectedIndex );
  var delta = this.previousDragX - this.dragX;
  if ( distance > 0 && delta > 0 ) {
    // boost to next if moving towards the right, and positive velocity
    return 1;
  } else if ( distance < 0 && delta < 0 ) {
    // boost to previous if moving towards the left, and negative velocity
    return -1;
  }
  return 0;
};

// ----- staticClick ----- //

proto.staticClick = function( event, pointer ) {
  // get clickedCell, if cell was clicked
  var clickedCell = this.getParentCell( event.target );
  var cellElem = clickedCell && clickedCell.element;
  var cellIndex = clickedCell && this.cells.indexOf( clickedCell );
  this.dispatchEvent( 'staticClick', event, [ pointer, cellElem, cellIndex ] );
};

// ----- scroll ----- //

proto.onscroll = function() {
  var scroll = getScrollPosition();
  var scrollMoveX = this.pointerDownScroll.x - scroll.x;
  var scrollMoveY = this.pointerDownScroll.y - scroll.y;
  // cancel click/tap if scroll is too much
  if ( Math.abs( scrollMoveX ) > 3 || Math.abs( scrollMoveY ) > 3 ) {
    this._pointerDone();
  }
};

// ----- utils ----- //

function getScrollPosition() {
  return {
    x: window.pageXOffset,
    y: window.pageYOffset
  };
}

// -----  ----- //

return Flickity;

}));

// prev/next buttons
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/prev-next-button',[
      './flickity',
      'unipointer/unipointer',
      'fizzy-ui-utils/utils'
    ], function( Flickity, Unipointer, utils ) {
      return factory( window, Flickity, Unipointer, utils );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('./flickity'),
      require('unipointer'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    factory(
      window,
      window.Flickity,
      window.Unipointer,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, Flickity, Unipointer, utils ) {
'use strict';

var svgURI = 'http://www.w3.org/2000/svg';

// -------------------------- PrevNextButton -------------------------- //

function PrevNextButton( direction, parent ) {
  this.direction = direction;
  this.parent = parent;
  this._create();
}

PrevNextButton.prototype = Object.create( Unipointer.prototype );

PrevNextButton.prototype._create = function() {
  // properties
  this.isEnabled = true;
  this.isPrevious = this.direction == -1;
  var leftDirection = this.parent.options.rightToLeft ? 1 : -1;
  this.isLeft = this.direction == leftDirection;

  var element = this.element = document.createElement('button');
  element.className = 'flickity-button flickity-prev-next-button';
  element.className += this.isPrevious ? ' previous' : ' next';
  // prevent button from submitting form http://stackoverflow.com/a/10836076/182183
  element.setAttribute( 'type', 'button' );
  // init as disabled
  this.disable();

  element.setAttribute( 'aria-label', this.isPrevious ? 'Previous' : 'Next' );

  // create arrow
  var svg = this.createSVG();
  element.appendChild( svg );
  // events
  this.parent.on( 'select', this.update.bind( this ) );
  this.on( 'pointerDown', this.parent.childUIPointerDown.bind( this.parent ) );
};

PrevNextButton.prototype.activate = function() {
  this.bindStartEvent( this.element );
  this.element.addEventListener( 'click', this );
  // add to DOM
  this.parent.element.appendChild( this.element );
};

PrevNextButton.prototype.deactivate = function() {
  // remove from DOM
  this.parent.element.removeChild( this.element );
  // click events
  this.unbindStartEvent( this.element );
  this.element.removeEventListener( 'click', this );
};

PrevNextButton.prototype.createSVG = function() {
  var svg = document.createElementNS( svgURI, 'svg');
  svg.setAttribute( 'class', 'flickity-button-icon' );
  svg.setAttribute( 'viewBox', '0 0 100 100' );
  var path = document.createElementNS( svgURI, 'path');
  var pathMovements = getArrowMovements( this.parent.options.arrowShape );
  path.setAttribute( 'd', pathMovements );
  path.setAttribute( 'class', 'arrow' );
  // rotate arrow
  if ( !this.isLeft ) {
    path.setAttribute( 'transform', 'translate(100, 100) rotate(180) ' );
  }
  svg.appendChild( path );
  return svg;
};

// get SVG path movmement
function getArrowMovements( shape ) {
  // use shape as movement if string
  if ( typeof shape == 'string' ) {
    return shape;
  }
  // create movement string
  return 'M ' + shape.x0 + ',50' +
    ' L ' + shape.x1 + ',' + ( shape.y1 + 50 ) +
    ' L ' + shape.x2 + ',' + ( shape.y2 + 50 ) +
    ' L ' + shape.x3 + ',50 ' +
    ' L ' + shape.x2 + ',' + ( 50 - shape.y2 ) +
    ' L ' + shape.x1 + ',' + ( 50 - shape.y1 ) +
    ' Z';
}

PrevNextButton.prototype.handleEvent = utils.handleEvent;

PrevNextButton.prototype.onclick = function() {
  if ( !this.isEnabled ) {
    return;
  }
  this.parent.uiChange();
  var method = this.isPrevious ? 'previous' : 'next';
  this.parent[ method ]();
};

// -----  ----- //

PrevNextButton.prototype.enable = function() {
  if ( this.isEnabled ) {
    return;
  }
  this.element.disabled = false;
  this.isEnabled = true;
};

PrevNextButton.prototype.disable = function() {
  if ( !this.isEnabled ) {
    return;
  }
  this.element.disabled = true;
  this.isEnabled = false;
};

PrevNextButton.prototype.update = function() {
  // index of first or last slide, if previous or next
  var slides = this.parent.slides;
  // enable is wrapAround and at least 2 slides
  if ( this.parent.options.wrapAround && slides.length > 1 ) {
    this.enable();
    return;
  }
  var lastIndex = slides.length ? slides.length - 1 : 0;
  var boundIndex = this.isPrevious ? 0 : lastIndex;
  var method = this.parent.selectedIndex == boundIndex ? 'disable' : 'enable';
  this[ method ]();
};

PrevNextButton.prototype.destroy = function() {
  this.deactivate();
  this.allOff();
};

// -------------------------- Flickity prototype -------------------------- //

utils.extend( Flickity.defaults, {
  prevNextButtons: true,
  arrowShape: {
    x0: 10,
    x1: 60, y1: 50,
    x2: 70, y2: 40,
    x3: 30
  }
});

Flickity.createMethods.push('_createPrevNextButtons');
var proto = Flickity.prototype;

proto._createPrevNextButtons = function() {
  if ( !this.options.prevNextButtons ) {
    return;
  }

  this.prevButton = new PrevNextButton( -1, this );
  this.nextButton = new PrevNextButton( 1, this );

  this.on( 'activate', this.activatePrevNextButtons );
};

proto.activatePrevNextButtons = function() {
  this.prevButton.activate();
  this.nextButton.activate();
  this.on( 'deactivate', this.deactivatePrevNextButtons );
};

proto.deactivatePrevNextButtons = function() {
  this.prevButton.deactivate();
  this.nextButton.deactivate();
  this.off( 'deactivate', this.deactivatePrevNextButtons );
};

// --------------------------  -------------------------- //

Flickity.PrevNextButton = PrevNextButton;

return Flickity;

}));

// page dots
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/page-dots',[
      './flickity',
      'unipointer/unipointer',
      'fizzy-ui-utils/utils'
    ], function( Flickity, Unipointer, utils ) {
      return factory( window, Flickity, Unipointer, utils );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('./flickity'),
      require('unipointer'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    factory(
      window,
      window.Flickity,
      window.Unipointer,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, Flickity, Unipointer, utils ) {

// -------------------------- PageDots -------------------------- //



function PageDots( parent ) {
  this.parent = parent;
  this._create();
}

PageDots.prototype = Object.create( Unipointer.prototype );

PageDots.prototype._create = function() {
  // create holder element
  this.holder = document.createElement('ol');
  this.holder.className = 'flickity-page-dots';
  // create dots, array of elements
  this.dots = [];
  // events
  this.handleClick = this.onClick.bind( this );
  this.on( 'pointerDown', this.parent.childUIPointerDown.bind( this.parent ) );
};

PageDots.prototype.activate = function() {
  this.setDots();
  this.holder.addEventListener( 'click', this.handleClick );
  this.bindStartEvent( this.holder );
  // add to DOM
  this.parent.element.appendChild( this.holder );
};

PageDots.prototype.deactivate = function() {
  this.holder.removeEventListener( 'click', this.handleClick );
  this.unbindStartEvent( this.holder );
  // remove from DOM
  this.parent.element.removeChild( this.holder );
};

PageDots.prototype.setDots = function() {
  // get difference between number of slides and number of dots
  var delta = this.parent.slides.length - this.dots.length;
  if ( delta > 0 ) {
    this.addDots( delta );
  } else if ( delta < 0 ) {
    this.removeDots( -delta );
  }
};

PageDots.prototype.addDots = function( count ) {
  var fragment = document.createDocumentFragment();
  var newDots = [];
  var length = this.dots.length;
  var max = length + count;

  for ( var i = length; i < max; i++ ) {
    var dot = document.createElement('li');
    dot.className = 'dot';
    dot.setAttribute( 'aria-label', 'Page dot ' + ( i + 1 ) );
    fragment.appendChild( dot );
    newDots.push( dot );
  }

  this.holder.appendChild( fragment );
  this.dots = this.dots.concat( newDots );
};

PageDots.prototype.removeDots = function( count ) {
  // remove from this.dots collection
  var removeDots = this.dots.splice( this.dots.length - count, count );
  // remove from DOM
  removeDots.forEach( function( dot ) {
    this.holder.removeChild( dot );
  }, this );
};

PageDots.prototype.updateSelected = function() {
  // remove selected class on previous
  if ( this.selectedDot ) {
    this.selectedDot.className = 'dot';
    this.selectedDot.removeAttribute('aria-current');
  }
  // don't proceed if no dots
  if ( !this.dots.length ) {
    return;
  }
  this.selectedDot = this.dots[ this.parent.selectedIndex ];
  this.selectedDot.className = 'dot is-selected';
  this.selectedDot.setAttribute( 'aria-current', 'step' );
};

PageDots.prototype.onTap = // old method name, backwards-compatible
PageDots.prototype.onClick = function( event ) {
  var target = event.target;
  // only care about dot clicks
  if ( target.nodeName != 'LI' ) {
    return;
  }

  this.parent.uiChange();
  var index = this.dots.indexOf( target );
  this.parent.select( index );
};

PageDots.prototype.destroy = function() {
  this.deactivate();
  this.allOff();
};

Flickity.PageDots = PageDots;

// -------------------------- Flickity -------------------------- //

utils.extend( Flickity.defaults, {
  pageDots: true
});

Flickity.createMethods.push('_createPageDots');

var proto = Flickity.prototype;

proto._createPageDots = function() {
  if ( !this.options.pageDots ) {
    return;
  }
  this.pageDots = new PageDots( this );
  // events
  this.on( 'activate', this.activatePageDots );
  this.on( 'select', this.updateSelectedPageDots );
  this.on( 'cellChange', this.updatePageDots );
  this.on( 'resize', this.updatePageDots );
  this.on( 'deactivate', this.deactivatePageDots );
};

proto.activatePageDots = function() {
  this.pageDots.activate();
};

proto.updateSelectedPageDots = function() {
  this.pageDots.updateSelected();
};

proto.updatePageDots = function() {
  this.pageDots.setDots();
};

proto.deactivatePageDots = function() {
  this.pageDots.deactivate();
};

// -----  ----- //

Flickity.PageDots = PageDots;

return Flickity;

}));

// player & autoPlay
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/player',[
      'ev-emitter/ev-emitter',
      'fizzy-ui-utils/utils',
      './flickity'
    ], function( EvEmitter, utils, Flickity ) {
      return factory( EvEmitter, utils, Flickity );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      require('ev-emitter'),
      require('fizzy-ui-utils'),
      require('./flickity')
    );
  } else {
    // browser global
    factory(
      window.EvEmitter,
      window.fizzyUIUtils,
      window.Flickity
    );
  }

}( window, function factory( EvEmitter, utils, Flickity ) {



// -------------------------- Player -------------------------- //

function Player( parent ) {
  this.parent = parent;
  this.state = 'stopped';
  // visibility change event handler
  this.onVisibilityChange = this.visibilityChange.bind( this );
  this.onVisibilityPlay = this.visibilityPlay.bind( this );
}

Player.prototype = Object.create( EvEmitter.prototype );

// start play
Player.prototype.play = function() {
  if ( this.state == 'playing' ) {
    return;
  }
  // do not play if page is hidden, start playing when page is visible
  var isPageHidden = document.hidden;
  if ( isPageHidden ) {
    document.addEventListener( 'visibilitychange', this.onVisibilityPlay );
    return;
  }

  this.state = 'playing';
  // listen to visibility change
  document.addEventListener( 'visibilitychange', this.onVisibilityChange );
  // start ticking
  this.tick();
};

Player.prototype.tick = function() {
  // do not tick if not playing
  if ( this.state != 'playing' ) {
    return;
  }

  var time = this.parent.options.autoPlay;
  // default to 3 seconds
  time = typeof time == 'number' ? time : 3000;
  var _this = this;
  // HACK: reset ticks if stopped and started within interval
  this.clear();
  this.timeout = setTimeout( function() {
    _this.parent.next( true );
    _this.tick();
  }, time );
};

Player.prototype.stop = function() {
  this.state = 'stopped';
  this.clear();
  // remove visibility change event
  document.removeEventListener( 'visibilitychange', this.onVisibilityChange );
};

Player.prototype.clear = function() {
  clearTimeout( this.timeout );
};

Player.prototype.pause = function() {
  if ( this.state == 'playing' ) {
    this.state = 'paused';
    this.clear();
  }
};

Player.prototype.unpause = function() {
  // re-start play if paused
  if ( this.state == 'paused' ) {
    this.play();
  }
};

// pause if page visibility is hidden, unpause if visible
Player.prototype.visibilityChange = function() {
  var isPageHidden = document.hidden;
  this[ isPageHidden ? 'pause' : 'unpause' ]();
};

Player.prototype.visibilityPlay = function() {
  this.play();
  document.removeEventListener( 'visibilitychange', this.onVisibilityPlay );
};

// -------------------------- Flickity -------------------------- //

utils.extend( Flickity.defaults, {
  pauseAutoPlayOnHover: true
});

Flickity.createMethods.push('_createPlayer');
var proto = Flickity.prototype;

proto._createPlayer = function() {
  this.player = new Player( this );

  this.on( 'activate', this.activatePlayer );
  this.on( 'uiChange', this.stopPlayer );
  this.on( 'pointerDown', this.stopPlayer );
  this.on( 'deactivate', this.deactivatePlayer );
};

proto.activatePlayer = function() {
  if ( !this.options.autoPlay ) {
    return;
  }
  this.player.play();
  this.element.addEventListener( 'mouseenter', this );
};

// Player API, don't hate the ... thanks I know where the door is

proto.playPlayer = function() {
  this.player.play();
};

proto.stopPlayer = function() {
  this.player.stop();
};

proto.pausePlayer = function() {
  this.player.pause();
};

proto.unpausePlayer = function() {
  this.player.unpause();
};

proto.deactivatePlayer = function() {
  this.player.stop();
  this.element.removeEventListener( 'mouseenter', this );
};

// ----- mouseenter/leave ----- //

// pause auto-play on hover
proto.onmouseenter = function() {
  if ( !this.options.pauseAutoPlayOnHover ) {
    return;
  }
  this.player.pause();
  this.element.addEventListener( 'mouseleave', this );
};

// resume auto-play on hover off
proto.onmouseleave = function() {
  this.player.unpause();
  this.element.removeEventListener( 'mouseleave', this );
};

// -----  ----- //

Flickity.Player = Player;

return Flickity;

}));

// add, remove cell
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/add-remove-cell',[
      './flickity',
      'fizzy-ui-utils/utils'
    ], function( Flickity, utils ) {
      return factory( window, Flickity, utils );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('./flickity'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    factory(
      window,
      window.Flickity,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, Flickity, utils ) {



// append cells to a document fragment
function getCellsFragment( cells ) {
  var fragment = document.createDocumentFragment();
  cells.forEach( function( cell ) {
    fragment.appendChild( cell.element );
  });
  return fragment;
}

// -------------------------- add/remove cell prototype -------------------------- //

var proto = Flickity.prototype;

/**
 * Insert, prepend, or append cells
 * @param {Element, Array, NodeList} elems
 * @param {Integer} index
 */
proto.insert = function( elems, index ) {
  var cells = this._makeCells( elems );
  if ( !cells || !cells.length ) {
    return;
  }
  var len = this.cells.length;
  // default to append
  index = index === undefined ? len : index;
  // add cells with document fragment
  var fragment = getCellsFragment( cells );
  // append to slider
  var isAppend = index == len;
  if ( isAppend ) {
    this.slider.appendChild( fragment );
  } else {
    var insertCellElement = this.cells[ index ].element;
    this.slider.insertBefore( fragment, insertCellElement );
  }
  // add to this.cells
  if ( index === 0 ) {
    // prepend, add to start
    this.cells = cells.concat( this.cells );
  } else if ( isAppend ) {
    // append, add to end
    this.cells = this.cells.concat( cells );
  } else {
    // insert in this.cells
    var endCells = this.cells.splice( index, len - index );
    this.cells = this.cells.concat( cells ).concat( endCells );
  }

  this._sizeCells( cells );
  this.cellChange( index, true );
};

proto.append = function( elems ) {
  this.insert( elems, this.cells.length );
};

proto.prepend = function( elems ) {
  this.insert( elems, 0 );
};

/**
 * Remove cells
 * @param {Element, Array, NodeList} elems
 */
proto.remove = function( elems ) {
  var cells = this.getCells( elems );
  if ( !cells || !cells.length ) {
    return;
  }

  var minCellIndex = this.cells.length - 1;
  // remove cells from collection & DOM
  cells.forEach( function( cell ) {
    cell.remove();
    var index = this.cells.indexOf( cell );
    minCellIndex = Math.min( index, minCellIndex );
    utils.removeFrom( this.cells, cell );
  }, this );

  this.cellChange( minCellIndex, true );
};

/**
 * logic to be run after a cell's size changes
 * @param {Element} elem - cell's element
 */
proto.cellSizeChange = function( elem ) {
  var cell = this.getCell( elem );
  if ( !cell ) {
    return;
  }
  cell.getSize();

  var index = this.cells.indexOf( cell );
  this.cellChange( index );
};

/**
 * logic any time a cell is changed: added, removed, or size changed
 * @param {Integer} changedCellIndex - index of the changed cell, optional
 */
proto.cellChange = function( changedCellIndex, isPositioningSlider ) {
  var prevSelectedElem = this.selectedElement;
  this._positionCells( changedCellIndex );
  this._getWrapShiftCells();
  this.setGallerySize();
  // update selectedIndex
  // try to maintain position & select previous selected element
  var cell = this.getCell( prevSelectedElem );
  if ( cell ) {
    this.selectedIndex = this.getCellSlideIndex( cell );
  }
  this.selectedIndex = Math.min( this.slides.length - 1, this.selectedIndex );

  this.emitEvent( 'cellChange', [ changedCellIndex ] );
  // position slider
  this.select( this.selectedIndex );
  // do not position slider after lazy load
  if ( isPositioningSlider ) {
    this.positionSliderAtSelected();
  }
};

// -----  ----- //

return Flickity;

}));

// lazyload
( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/lazyload',[
      './flickity',
      'fizzy-ui-utils/utils'
    ], function( Flickity, utils ) {
      return factory( window, Flickity, utils );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('./flickity'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    factory(
      window,
      window.Flickity,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, Flickity, utils ) {
'use strict';

Flickity.createMethods.push('_createLazyload');
var proto = Flickity.prototype;

proto._createLazyload = function() {
  this.on( 'select', this.lazyLoad );
};

proto.lazyLoad = function() {
  var lazyLoad = this.options.lazyLoad;
  if ( !lazyLoad ) {
    return;
  }
  // get adjacent cells, use lazyLoad option for adjacent count
  var adjCount = typeof lazyLoad == 'number' ? lazyLoad : 0;
  var cellElems = this.getAdjacentCellElements( adjCount );
  // get lazy images in those cells
  var lazyImages = [];
  cellElems.forEach( function( cellElem ) {
    var lazyCellImages = getCellLazyImages( cellElem );
    lazyImages = lazyImages.concat( lazyCellImages );
  });
  // load lazy images
  lazyImages.forEach( function( img ) {
    new LazyLoader( img, this );
  }, this );
};

function getCellLazyImages( cellElem ) {
  // check if cell element is lazy image
  if ( cellElem.nodeName == 'IMG' ) {
    var lazyloadAttr = cellElem.getAttribute('data-flickity-lazyload');
    var srcAttr = cellElem.getAttribute('data-flickity-lazyload-src');
    var srcsetAttr = cellElem.getAttribute('data-flickity-lazyload-srcset');
    if ( lazyloadAttr || srcAttr || srcsetAttr ) {
      return [ cellElem ];
    }
  }
  // select lazy images in cell
  var lazySelector = 'img[data-flickity-lazyload], ' +
    'img[data-flickity-lazyload-src], img[data-flickity-lazyload-srcset]';
  var imgs = cellElem.querySelectorAll( lazySelector );
  return utils.makeArray( imgs );
}

// -------------------------- LazyLoader -------------------------- //

/**
 * class to handle loading images
 */
function LazyLoader( img, flickity ) {
  this.img = img;
  this.flickity = flickity;
  this.load();
}

LazyLoader.prototype.handleEvent = utils.handleEvent;

LazyLoader.prototype.load = function() {
  this.img.addEventListener( 'load', this );
  this.img.addEventListener( 'error', this );
  // get src & srcset
  var src = this.img.getAttribute('data-flickity-lazyload') ||
    this.img.getAttribute('data-flickity-lazyload-src');
  var srcset = this.img.getAttribute('data-flickity-lazyload-srcset');
  // set src & serset
  this.img.src = src;
  if ( srcset ) {
    this.img.setAttribute( 'srcset', srcset );
  }
  // remove attr
  this.img.removeAttribute('data-flickity-lazyload');
  this.img.removeAttribute('data-flickity-lazyload-src');
  this.img.removeAttribute('data-flickity-lazyload-srcset');
};

LazyLoader.prototype.onload = function( event ) {
  this.complete( event, 'flickity-lazyloaded' );
};

LazyLoader.prototype.onerror = function( event ) {
  this.complete( event, 'flickity-lazyerror' );
};

LazyLoader.prototype.complete = function( event, className ) {
  // unbind events
  this.img.removeEventListener( 'load', this );
  this.img.removeEventListener( 'error', this );

  var cell = this.flickity.getParentCell( this.img );
  var cellElem = cell && cell.element;
  this.flickity.cellSizeChange( cellElem );

  this.img.classList.add( className );
  this.flickity.dispatchEvent( 'lazyLoad', event, cellElem );
};

// -----  ----- //

Flickity.LazyLoader = LazyLoader;

return Flickity;

}));

/*!
 * Flickity v2.2.1
 * Touch, responsive, flickable carousels
 *
 * Licensed GPLv3 for open source use
 * or Flickity Commercial License for commercial use
 *
 * https://flickity.metafizzy.co
 * Copyright 2015-2019 Metafizzy
 */

( function( window, factory ) {
  // universal module definition
  /* jshint strict: false */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity/js/index',[
      './flickity',
      './drag',
      './prev-next-button',
      './page-dots',
      './player',
      './add-remove-cell',
      './lazyload'
    ], factory );
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      require('./flickity'),
      require('./drag'),
      require('./prev-next-button'),
      require('./page-dots'),
      require('./player'),
      require('./add-remove-cell'),
      require('./lazyload')
    );
  }

})( window, function factory( Flickity ) {
  /*jshint strict: false*/
  return Flickity;
});

/*!
 * Flickity asNavFor v2.0.2
 * enable asNavFor for Flickity
 */

/*jshint browser: true, undef: true, unused: true, strict: true*/

( function( window, factory ) {
  // universal module definition
  /*jshint strict: false */ /*globals define, module, require */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'flickity-as-nav-for/as-nav-for',[
      'flickity/js/index',
      'fizzy-ui-utils/utils'
    ], factory );
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      require('flickity'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Flickity = factory(
      window.Flickity,
      window.fizzyUIUtils
    );
  }

}( window, function factory( Flickity, utils ) {



// -------------------------- asNavFor prototype -------------------------- //

// Flickity.defaults.asNavFor = null;

Flickity.createMethods.push('_createAsNavFor');

var proto = Flickity.prototype;

proto._createAsNavFor = function() {
  this.on( 'activate', this.activateAsNavFor );
  this.on( 'deactivate', this.deactivateAsNavFor );
  this.on( 'destroy', this.destroyAsNavFor );

  var asNavForOption = this.options.asNavFor;
  if ( !asNavForOption ) {
    return;
  }
  // HACK do async, give time for other flickity to be initalized
  var _this = this;
  setTimeout( function initNavCompanion() {
    _this.setNavCompanion( asNavForOption );
  });
};

proto.setNavCompanion = function( elem ) {
  elem = utils.getQueryElement( elem );
  var companion = Flickity.data( elem );
  // stop if no companion or companion is self
  if ( !companion || companion == this ) {
    return;
  }

  this.navCompanion = companion;
  // companion select
  var _this = this;
  this.onNavCompanionSelect = function() {
    _this.navCompanionSelect();
  };
  companion.on( 'select', this.onNavCompanionSelect );
  // click
  this.on( 'staticClick', this.onNavStaticClick );

  this.navCompanionSelect( true );
};

proto.navCompanionSelect = function( isInstant ) {
  // wait for companion & selectedCells first. #8
  var companionCells = this.navCompanion && this.navCompanion.selectedCells;
  if ( !companionCells ) {
    return;
  }
  // select slide that matches first cell of slide
  var selectedCell = companionCells[0];
  var firstIndex = this.navCompanion.cells.indexOf( selectedCell );
  var lastIndex = firstIndex + companionCells.length - 1;
  var selectIndex = Math.floor( lerp( firstIndex, lastIndex,
    this.navCompanion.cellAlign ) );
  this.selectCell( selectIndex, false, isInstant );
  // set nav selected class
  this.removeNavSelectedElements();
  // stop if companion has more cells than this one
  if ( selectIndex >= this.cells.length ) {
    return;
  }

  var selectedCells = this.cells.slice( firstIndex, lastIndex + 1 );
  this.navSelectedElements = selectedCells.map( function( cell ) {
    return cell.element;
  });
  this.changeNavSelectedClass('add');
};

function lerp( a, b, t ) {
  return ( b - a ) * t + a;
}

proto.changeNavSelectedClass = function( method ) {
  this.navSelectedElements.forEach( function( navElem ) {
    navElem.classList[ method ]('is-nav-selected');
  });
};

proto.activateAsNavFor = function() {
  this.navCompanionSelect( true );
};

proto.removeNavSelectedElements = function() {
  if ( !this.navSelectedElements ) {
    return;
  }
  this.changeNavSelectedClass('remove');
  delete this.navSelectedElements;
};

proto.onNavStaticClick = function( event, pointer, cellElement, cellIndex ) {
  if ( typeof cellIndex == 'number' ) {
    this.navCompanion.selectCell( cellIndex );
  }
};

proto.deactivateAsNavFor = function() {
  this.removeNavSelectedElements();
};

proto.destroyAsNavFor = function() {
  if ( !this.navCompanion ) {
    return;
  }
  this.navCompanion.off( 'select', this.onNavCompanionSelect );
  this.off( 'staticClick', this.onNavStaticClick );
  delete this.navCompanion;
};

// -----  ----- //

return Flickity;

}));

/*!
 * imagesLoaded v4.1.4
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

( function( window, factory ) { 'use strict';
  // universal module definition

  /*global define: false, module: false, require: false */

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'imagesloaded/imagesloaded',[
      'ev-emitter/ev-emitter'
    ], function( EvEmitter ) {
      return factory( window, EvEmitter );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('ev-emitter')
    );
  } else {
    // browser global
    window.imagesLoaded = factory(
      window,
      window.EvEmitter
    );
  }

})( typeof window !== 'undefined' ? window : this,

// --------------------------  factory -------------------------- //

function factory( window, EvEmitter ) {



var $ = window.jQuery;
var console = window.console;

// -------------------------- helpers -------------------------- //

// extend objects
function extend( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
}

var arraySlice = Array.prototype.slice;

// turn element or nodeList into an array
function makeArray( obj ) {
  if ( Array.isArray( obj ) ) {
    // use object if already an array
    return obj;
  }

  var isArrayLike = typeof obj == 'object' && typeof obj.length == 'number';
  if ( isArrayLike ) {
    // convert nodeList to array
    return arraySlice.call( obj );
  }

  // array of single index
  return [ obj ];
}

// -------------------------- imagesLoaded -------------------------- //

/**
 * @param {Array, Element, NodeList, String} elem
 * @param {Object or Function} options - if function, use as callback
 * @param {Function} onAlways - callback function
 */
function ImagesLoaded( elem, options, onAlways ) {
  // coerce ImagesLoaded() without new, to be new ImagesLoaded()
  if ( !( this instanceof ImagesLoaded ) ) {
    return new ImagesLoaded( elem, options, onAlways );
  }
  // use elem as selector string
  var queryElem = elem;
  if ( typeof elem == 'string' ) {
    queryElem = document.querySelectorAll( elem );
  }
  // bail if bad element
  if ( !queryElem ) {
    console.error( 'Bad element for imagesLoaded ' + ( queryElem || elem ) );
    return;
  }

  this.elements = makeArray( queryElem );
  this.options = extend( {}, this.options );
  // shift arguments if no options set
  if ( typeof options == 'function' ) {
    onAlways = options;
  } else {
    extend( this.options, options );
  }

  if ( onAlways ) {
    this.on( 'always', onAlways );
  }

  this.getImages();

  if ( $ ) {
    // add jQuery Deferred object
    this.jqDeferred = new $.Deferred();
  }

  // HACK check async to allow time to bind listeners
  setTimeout( this.check.bind( this ) );
}

ImagesLoaded.prototype = Object.create( EvEmitter.prototype );

ImagesLoaded.prototype.options = {};

ImagesLoaded.prototype.getImages = function() {
  this.images = [];

  // filter & find items if we have an item selector
  this.elements.forEach( this.addElementImages, this );
};

/**
 * @param {Node} element
 */
ImagesLoaded.prototype.addElementImages = function( elem ) {
  // filter siblings
  if ( elem.nodeName == 'IMG' ) {
    this.addImage( elem );
  }
  // get background image on element
  if ( this.options.background === true ) {
    this.addElementBackgroundImages( elem );
  }

  // find children
  // no non-element nodes, #143
  var nodeType = elem.nodeType;
  if ( !nodeType || !elementNodeTypes[ nodeType ] ) {
    return;
  }
  var childImgs = elem.querySelectorAll('img');
  // concat childElems to filterFound array
  for ( var i=0; i < childImgs.length; i++ ) {
    var img = childImgs[i];
    this.addImage( img );
  }

  // get child background images
  if ( typeof this.options.background == 'string' ) {
    var children = elem.querySelectorAll( this.options.background );
    for ( i=0; i < children.length; i++ ) {
      var child = children[i];
      this.addElementBackgroundImages( child );
    }
  }
};

var elementNodeTypes = {
  1: true,
  9: true,
  11: true
};

ImagesLoaded.prototype.addElementBackgroundImages = function( elem ) {
  var style = getComputedStyle( elem );
  if ( !style ) {
    // Firefox returns null if in a hidden iframe https://bugzil.la/548397
    return;
  }
  // get url inside url("...")
  var reURL = /url\((['"])?(.*?)\1\)/gi;
  var matches = reURL.exec( style.backgroundImage );
  while ( matches !== null ) {
    var url = matches && matches[2];
    if ( url ) {
      this.addBackground( url, elem );
    }
    matches = reURL.exec( style.backgroundImage );
  }
};

/**
 * @param {Image} img
 */
ImagesLoaded.prototype.addImage = function( img ) {
  var loadingImage = new LoadingImage( img );
  this.images.push( loadingImage );
};

ImagesLoaded.prototype.addBackground = function( url, elem ) {
  var background = new Background( url, elem );
  this.images.push( background );
};

ImagesLoaded.prototype.check = function() {
  var _this = this;
  this.progressedCount = 0;
  this.hasAnyBroken = false;
  // complete if no images
  if ( !this.images.length ) {
    this.complete();
    return;
  }

  function onProgress( image, elem, message ) {
    // HACK - Chrome triggers event before object properties have changed. #83
    setTimeout( function() {
      _this.progress( image, elem, message );
    });
  }

  this.images.forEach( function( loadingImage ) {
    loadingImage.once( 'progress', onProgress );
    loadingImage.check();
  });
};

ImagesLoaded.prototype.progress = function( image, elem, message ) {
  this.progressedCount++;
  this.hasAnyBroken = this.hasAnyBroken || !image.isLoaded;
  // progress event
  this.emitEvent( 'progress', [ this, image, elem ] );
  if ( this.jqDeferred && this.jqDeferred.notify ) {
    this.jqDeferred.notify( this, image );
  }
  // check if completed
  if ( this.progressedCount == this.images.length ) {
    this.complete();
  }

  if ( this.options.debug && console ) {
    console.log( 'progress: ' + message, image, elem );
  }
};

ImagesLoaded.prototype.complete = function() {
  var eventName = this.hasAnyBroken ? 'fail' : 'done';
  this.isComplete = true;
  this.emitEvent( eventName, [ this ] );
  this.emitEvent( 'always', [ this ] );
  if ( this.jqDeferred ) {
    var jqMethod = this.hasAnyBroken ? 'reject' : 'resolve';
    this.jqDeferred[ jqMethod ]( this );
  }
};

// --------------------------  -------------------------- //

function LoadingImage( img ) {
  this.img = img;
}

LoadingImage.prototype = Object.create( EvEmitter.prototype );

LoadingImage.prototype.check = function() {
  // If complete is true and browser supports natural sizes,
  // try to check for image status manually.
  var isComplete = this.getIsImageComplete();
  if ( isComplete ) {
    // report based on naturalWidth
    this.confirm( this.img.naturalWidth !== 0, 'naturalWidth' );
    return;
  }

  // If none of the checks above matched, simulate loading on detached element.
  this.proxyImage = new Image();
  this.proxyImage.addEventListener( 'load', this );
  this.proxyImage.addEventListener( 'error', this );
  // bind to image as well for Firefox. #191
  this.img.addEventListener( 'load', this );
  this.img.addEventListener( 'error', this );
  this.proxyImage.src = this.img.src;
};

LoadingImage.prototype.getIsImageComplete = function() {
  // check for non-zero, non-undefined naturalWidth
  // fixes Safari+InfiniteScroll+Masonry bug infinite-scroll#671
  return this.img.complete && this.img.naturalWidth;
};

LoadingImage.prototype.confirm = function( isLoaded, message ) {
  this.isLoaded = isLoaded;
  this.emitEvent( 'progress', [ this, this.img, message ] );
};

// ----- events ----- //

// trigger specified handler for event type
LoadingImage.prototype.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

LoadingImage.prototype.onload = function() {
  this.confirm( true, 'onload' );
  this.unbindEvents();
};

LoadingImage.prototype.onerror = function() {
  this.confirm( false, 'onerror' );
  this.unbindEvents();
};

LoadingImage.prototype.unbindEvents = function() {
  this.proxyImage.removeEventListener( 'load', this );
  this.proxyImage.removeEventListener( 'error', this );
  this.img.removeEventListener( 'load', this );
  this.img.removeEventListener( 'error', this );
};

// -------------------------- Background -------------------------- //

function Background( url, element ) {
  this.url = url;
  this.element = element;
  this.img = new Image();
}

// inherit LoadingImage prototype
Background.prototype = Object.create( LoadingImage.prototype );

Background.prototype.check = function() {
  this.img.addEventListener( 'load', this );
  this.img.addEventListener( 'error', this );
  this.img.src = this.url;
  // check if image is already complete
  var isComplete = this.getIsImageComplete();
  if ( isComplete ) {
    this.confirm( this.img.naturalWidth !== 0, 'naturalWidth' );
    this.unbindEvents();
  }
};

Background.prototype.unbindEvents = function() {
  this.img.removeEventListener( 'load', this );
  this.img.removeEventListener( 'error', this );
};

Background.prototype.confirm = function( isLoaded, message ) {
  this.isLoaded = isLoaded;
  this.emitEvent( 'progress', [ this, this.element, message ] );
};

// -------------------------- jQuery -------------------------- //

ImagesLoaded.makeJQueryPlugin = function( jQuery ) {
  jQuery = jQuery || window.jQuery;
  if ( !jQuery ) {
    return;
  }
  // set local variable
  $ = jQuery;
  // $().imagesLoaded()
  $.fn.imagesLoaded = function( options, callback ) {
    var instance = new ImagesLoaded( this, options, callback );
    return instance.jqDeferred.promise( $(this) );
  };
};
// try making plugin
ImagesLoaded.makeJQueryPlugin();

// --------------------------  -------------------------- //

return ImagesLoaded;

});

/*!
 * Flickity imagesLoaded v2.0.0
 * enables imagesLoaded option for Flickity
 */

/*jshint browser: true, strict: true, undef: true, unused: true */

( function( window, factory ) {
  // universal module definition
  /*jshint strict: false */ /*globals define, module, require */
  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( [
      'flickity/js/index',
      'imagesloaded/imagesloaded'
    ], function( Flickity, imagesLoaded ) {
      return factory( window, Flickity, imagesLoaded );
    });
  } else if ( typeof module == 'object' && module.exports ) {
    // CommonJS
    module.exports = factory(
      window,
      require('flickity'),
      require('imagesloaded')
    );
  } else {
    // browser global
    window.Flickity = factory(
      window,
      window.Flickity,
      window.imagesLoaded
    );
  }

}( window, function factory( window, Flickity, imagesLoaded ) {
'use strict';

Flickity.createMethods.push('_createImagesLoaded');

var proto = Flickity.prototype;

proto._createImagesLoaded = function() {
  this.on( 'activate', this.imagesLoaded );
};

proto.imagesLoaded = function() {
  if ( !this.options.imagesLoaded ) {
    return;
  }
  var _this = this;
  function onImagesLoadedProgress( instance, image ) {
    var cell = _this.getParentCell( image.img );
    _this.cellSizeChange( cell && cell.element );
    if ( !_this.options.freeScroll ) {
      _this.positionSliderAtSelected();
    }
  }
  imagesLoaded( this.slider ).on( 'progress', onImagesLoadedProgress );
};

return Flickity;

}));

